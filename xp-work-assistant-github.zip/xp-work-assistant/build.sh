#!/bin/sh
# 构建 opencode desktop（Windows XP 32 位 GUI）
set -e
cd "$(dirname "$0")"
mkdir -p bin build

pick() { for c in "$@"; do command -v "$c" >/dev/null 2>&1 && { echo "$c"; return 0; }; done; return 1; }

CC="${CC:-$(pick i686-w64-mingw32-gcc i686-w64-mingw32-gcc-posix i686-w64-mingw32-gcc-win32)}"
MBEDTLS_DIR="${MBEDTLS_DIR:-../.tls/mbedtls-2.28.8}"
RC="${RC:-$(pick i686-w64-mingw32-windres)}"

echo "==> resources"
"$RC" --preprocessor "$CC" --preprocessor-arg "-E" --preprocessor-arg "-x" --preprocessor-arg "c" -I res -i src/xpwork.rc -o build/opencode_rc.o

# 用 mingw 自带的 ANSI stdio，避开 XP 的 msvcrt 里没有的 _vsnprintf_s
STDIO_DEF="-D__USE_MINGW_ANSI_STDIO=1"

echo "==> mbedTLS (自带 TLS)"
# XP 兼容补丁：mingw 的 _TRUNCATE 会让 mbedTLS 调 vsnprintf_s（Vista+ 才有），
# 改成走可移植分支
PLATFORM_C="$MBEDTLS_DIR/library/platform.c"
if [ -f "$PLATFORM_C" ] && ! grep -q "__MINGW32__" "$PLATFORM_C"; then
    sed -i 's/^#if defined(_TRUNCATE)$/#if defined(_TRUNCATE) \&\& !defined(__MINGW32__)/' "$PLATFORM_C"
fi
if [ ! -d "$MBEDTLS_DIR" ]; then
    echo "找不到 mbedTLS 源码目录：$MBEDTLS_DIR" >&2
    echo "下载 https://github.com/Mbed-TLS/mbedtls/archive/refs/tags/v2.28.8.tar.gz" >&2
    echo "解压后设置 MBEDTLS_DIR 指向它，例如：MBEDTLS_DIR=/path/mbedtls-2.28.8 ./build.sh" >&2
    exit 1
fi
if [ ! -f "$MBEDTLS_DIR/build/libmbedtls.a" ]; then
    mkdir -p "$MBEDTLS_DIR/build"
    ( cd "$MBEDTLS_DIR/build" && "$CC" -O2 $STDIO_DEF -I../include -c ../library/*.c && ar rcs libmbedtls.a *.o )
fi
EXTRA_INC="-I$MBEDTLS_DIR/include"

echo "==> opencode.exe"
"$CC" -O2 -Wall -Wextra -Wno-unused-parameter -Wno-stringop-truncation \
    -mwindows -fexec-charset=GBK $EXTRA_INC $STDIO_DEF -o "bin/xp work Assistant.exe" \
    src/ui.c src/gfx_win32.c src/main_win32.c src/net.c src/settings.c src/tls_http.c src/agent.c src/exec.c src/json.c src/imgview.c \
    build/opencode_rc.o \
    -L"$MBEDTLS_DIR/build" -lmbedtls \
    -lgdi32 -luser32 -lkernel32 -lwininet -limm32 -lcomdlg32 -lshell32 \
    -lws2_32 -ladvapi32 -lcrypt32 -lgdiplus

echo "==> 本机预览（headless -> SVG）"
cc -O2 -o build/headless src/ui.c src/gfx_svg.c src/main_headless.c

echo
file "bin/xp work Assistant.exe" 2>/dev/null || true
echo "bin/xp work Assistant.exe built."
