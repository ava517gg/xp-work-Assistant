#!/usr/bin/env python3
"""make_manual.py -- 生成《使用说明》docx + txt"""
import os
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOT = os.path.join(HERE, "screenshots", "working.png")
ATTACH_SHOT = os.path.join(HERE, "screenshots", "attach.png")


def cjk(style, east="宋体", ascii_="Arial"):
    rpr = style.element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = OxmlElement("w:rFonts")
        rpr.append(rf)
    rf.set(qn("w:eastAsia"), east)
    rf.set(qn("w:ascii"), ascii_)
    rf.set(qn("w:hAnsi"), ascii_)


def bullet(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.28)
    p.paragraph_format.space_after = Pt(2)
    p.add_run("• " + text)


def numbered(doc, n, text):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.28)
    p.paragraph_format.space_after = Pt(2)
    p.add_run("%d. " % n + text)


def table(doc, rows, widths=None):
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    t.style = "Table Grid"
    for i, row in enumerate(rows):
        for j, cell in enumerate(row):
            c = t.cell(i, j)
            c.text = ""
            p = c.paragraphs[0]
            run = p.add_run(str(cell))
            run.font.size = Pt(9.5)
            if i == 0:
                run.bold = True
    return t


def build():
    doc = Document()

    cjk(doc.styles["Normal"], "宋体", "Arial")
    doc.styles["Normal"].font.size = Pt(10.5)
    for name in ("Heading 1", "Heading 2", "Heading 3", "Title"):
        try:
            cjk(doc.styles[name], "黑体", "Arial")
        except KeyError:
            pass

    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Inches(0.9)
    sec.top_margin = sec.bottom_margin = Inches(0.8)

    t = doc.add_heading("xp work Assistant 桌面版 使用说明", level=0)
    t.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p = doc.add_paragraph("Windows XP 及以上的 32 位桌面程序 · 中文界面 · 可接 DeepSeek")
    p.runs[0].font.size = Pt(10.5)
    p.runs[0].font.color.rgb = RGBColor(0x60, 0x60, 0x60)

    # 一
    doc.add_heading("一、这是什么", level=1)
    doc.add_paragraph(
        "xp work Assistant 桌面版是一个 Windows 窗口程序（32 位，单个 exe，约 300 KB）。"
        "界面是一个对话式编程助手：左边是会话列表，中间是对话，下面是输入框。"
    )
    doc.add_paragraph(
        "不装 .NET、不装 VC++ 运行库、不写注册表。"
        "不填 API Key 时是「离线演示」，回复是写好的剧本，用来熟悉界面；"
        "填了 DeepSeek 的 Key 之后，每条消息都会真的发给模型。"
    )

    # 二
    doc.add_heading("二、系统要求", level=1)
    table(doc, [
        ["项目", "要求"],
        ["操作系统", "Windows XP SP3 及以上（32 位、64 位系统都能跑）"],
        ["磁盘", "约 1 MB（程序 + 配置文件）"],
        ["运行库", "无"],
        ["网络", "接 DeepSeek 时需要；纯离线演示不需要"],
        ["显示", "窗口默认 760×560，最小 480×360"],
    ])

    # 三
    doc.add_heading("三、第一次运行", level=1)
    bullet(doc, "双击「xp work Assistant.exe」即可。窗口可以拖动、缩放、最小化。")
    bullet(doc, "没有填 Key 时，状态栏右下角显示「离线演示」。这时输入「修一下清除按钮」"
                "「跑一下测试」「讲讲 store.js」会看到预设的演示对话。")
    bullet(doc, "程序不会自动联网，也不会在后台驻留。")

    # 四
    doc.add_heading("四、界面说明", level=1)
    if os.path.exists(SHOT):
        doc.add_picture(SHOT, width=Inches(5.9))
        cap = doc.add_paragraph("图 1  主窗口（不含系统标题栏和菜单栏）")
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cap.runs[0].font.size = Pt(9)
        cap.runs[0].font.color.rgb = RGBColor(0x70, 0x70, 0x70)

    table(doc, [
        ["区域", "作用"],
        ["左侧栏", "会话列表（可点选）、当前模型、版本号"],
        ["对话区", "用户消息（> 开头）、工具调用、代码 diff、回复"],
        ["输入条", "输入框 + 「发送 / 停止」按钮"],
        ["状态栏", "模型名、token、花费、就绪 / 生成中 / 在线 / 离线演示"],
        ["菜单栏", "文件、编辑、会话、设置、帮助"],
    ])

    doc.add_paragraph("菜单里常用的几项：")
    table(doc, [
        ["菜单", "功能"],
        ["文件 → 新建会话", "清空对话，重新开始"],
        ["编辑 → 复制对话", "把整段对话复制到剪贴板（纯文本）"],
        ["编辑 → 清空", "清空对话区"],
        ["会话", "切换模型（离线演示时只是改显示；在线时以设置为准）"],
        ["设置 → API Key 与模型", "填 DeepSeek 的 Key、接口地址、模型"],
        ["设置 → 检测连接与 TLS", "测一次网络和 TLS，报告 HTTP 状态或错误码"],
        ["帮助 → 快捷键 / 关于", "快捷键列表、版本信息"],
    ])

    # 五
    doc.add_heading("五、输入中文", level=1)
    doc.add_paragraph(
        "输入框是 Unicode 控件，系统自带的微软拼音、搜狗、QQ 拼音都能直接用，不需要切换什么。")
    bullet(doc, "有一条规则要记住：输入法开着的时候，回车是留给输入法的（用来选词、上屏），"
                "不会被当成发送。要发送请按 Ctrl+Enter。")
    bullet(doc, "把输入法切到英文状态，或者用纯英文键盘时，直接按回车就会发送。")
    bullet(doc, "输入框下面那一行提示就是：ctrl+enter 发送 / esc 中断 / ↑↓ 历史。")

    # 六
    doc.add_heading("六、发送附件", level=1)
    doc.add_paragraph("三种方式，用哪种都行：")
    numbered(doc, 1, "点输入框左上角的「+ 添加附件」按钮")
    numbered(doc, 2, "菜单 文件 → 添加附件…（快捷键 Ctrl+O）")
    numbered(doc, 3, "直接把文件从资源管理器拖进窗口")

    doc.add_paragraph("")
    if os.path.exists(ATTACH_SHOT):
        doc.add_picture(ATTACH_SHOT, width=Inches(5.9))
        cap = doc.add_paragraph("图 2  附加了一个 app.js 的待发送状态")
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cap.runs[0].font.size = Pt(9)
        cap.runs[0].font.color.rgb = RGBColor(0x70, 0x70, 0x70)

    table(doc, [
        ["规则", "说明"],
        ["数量", "一次最多 6 个"],
        ["大小", "文本 128 KB，图片 32 MB"],
        ["类型", "只支持文本和代码（二进制文件会被拒绝）"],
        ["移除", "点附件标签右边的 x"],
        ["编码", "UTF-8 和 GBK 都能自动识别"],
    ])

    doc.add_paragraph(
        "发送时，附件内容会作为上下文附在消息后面，模型看到的是：你的话 + "
        "[附件：文件名] + 代码块。离线演示时不发网络请求，界面会提示附件不会被真的读取。")

    # 七
    doc.add_heading("七、接 DeepSeek", level=1)
    doc.add_paragraph("操作步骤：")
    numbered(doc, 1, "菜单 设置 → API Key 与模型")
    numbered(doc, 2, "点「填入 DeepSeek 官方」，地址和模型会自动填好："
                     "https://api.deepseek.com/v1 和 deepseek-flash")
    numbered(doc, 3, "粘贴你的 API Key（sk- 开头），点确定")
    numbered(doc, 4, "状态栏右下角变成「在线」，就可以正常提问了。")

    doc.add_paragraph(
        "配置保存在 exe 同目录的 xpwork.ini 里，Key 是明文存的。"
        "如果 exe 放在 Program Files 这类没有写权限的目录，会退到 %APPDATA%\\xpwork.ini。"
        "想回到离线演示：设置 → 清除 API Key。")

    doc.add_heading("推理强度", level=2)
    doc.add_paragraph(
        "在「设置 → API Key 与模型」窗口里有一个「推理强度」下拉列表"
        "（菜单 设置 → 推理强度 是同一个开关），四档，对应 DeepSeek 的思考模式参数：")
    table(doc, [
        ["选项", "实际请求参数", "说明"],
        ["关闭思考", "thinking.type = disabled", "不输出思维链，最快，适合简单问答"],
        ["低", "reasoning_effort = low", "轻量思考"],
        ["高", "reasoning_effort = high", "默认，和 API 默认一致"],
        ["最高", "reasoning_effort = max", "难题用，更慢也更贵"],
    ])
    doc.add_paragraph(
        "在线时状态栏左侧会显示当前档位，例如「deepseek-flash · 思考高」。"
        "设置保存在 xpwork.ini 里，只在接真模型时生效；离线演示只是记着。")

    doc.add_paragraph(
        "连不上时先点「设置 → 检测连接与 TLS」：它会在后台连一次你填的地址，"
        "把结果写进对话区——TLS 通道正常会显示 HTTP 状态码；"
        "失败会给出原因，比如「TLS 握手失败（12157）」说明 XP 还没装 TLS 1.2 补丁，"
        "「域名解析失败」说明是网络问题。")

    doc.add_heading("XP 上还要装 TLS 补丁吗", level=2)
    doc.add_paragraph(
        "不用了。这一版把 mbedTLS 和一份根证书包直接编进了 exe，"
        "https 请求由程序自己完成 TLS 1.2 握手和证书校验，完全绕开 Windows 的加密栈。")
    doc.add_paragraph("所以下面这些都不需要：")
    bullet(doc, "不需要装 KB4019276 之类的 TLS 补丁")
    bullet(doc, "不需要往系统里导入根证书")
    bullet(doc, "不需要中继，接口地址保持 https://api.deepseek.com/v1")
    doc.add_paragraph(
        "唯一还和系统有关的是「系统时间」——证书有有效期，时间差太多会被判无效。"
        "点「设置 → 检测连接与 TLS」能一次看到握手结果。")
    doc.add_paragraph(
        "包里的 xp-tls 目录留着，是给别的老程序（IE、老工具）补 TLS 用的，xp work Assistant 自己不用。")

    doc.add_heading("让 AI 真的操作本机", level=2)
    doc.add_paragraph(
        "默认是纯聊天。要让模型能执行命令、读写文件：菜单 设置 → "
        "「允许 AI 操作本机（执行命令 / 改文件）」，确认安全提示后生效。")
    doc.add_paragraph("打开后模型可以调用三类工具：")
    table(doc, [
        ["工具", "做什么"],
        ["run_cmd", "用 cmd.exe /c 执行一条命令，返回输出和退出码（XP 只有命令行，没有 bash/PowerShell）"],
        ["read_file", "读取一个文本文件"],
        ["write_file", "把内容写入文件（新建或覆盖）"],
        ["web_search", "联网搜索（Bing），返回标题和链接"],
        ["download", "从 http/https 链接下载文件存到本机"],
        ["run_ps", "用 PowerShell 执行（机器上装了才有用）"],
    ])
    doc.add_paragraph(
        "执行过程会实时显示在对话区：一条工具标题行，加上输出的前十几行。"
        "模型看到完整结果，你看到的是摘要。")
    doc.add_paragraph("安全限制：")
    bullet(doc, "危险命令在本地直接拒绝，不会发给系统执行（format、diskpart、shutdown、rd /s、del /f /s、reg delete 等）")
    bullet(doc, "上下文用到 60% 会自动压缩成摘要（目标、改动、待办），然后接着做")
    bullet(doc, "工具循环没有轮数上限，会一直做到模型给出最终回答；随时可以按「停止」或 ESC 中断")
    bullet(doc, "随时可以用菜单关掉；关掉后模型看不到这些工具")
    doc.add_paragraph(
        "注意：打开后它执行的命令和改动的文件都是真的。建议只在你信任的对话里打开。")

    # 八
    doc.add_heading("九、常见问题", level=1)
    faq = [
        ("发了消息没反应，状态栏一直是「生成中…」",
         "如果填了接口地址，说明在等模型回复，最长等 120 秒；点「停止」可以中断。"
         "如果是离线演示，检查是不是点到了别的窗口。"),
        ("提示 HTTP 401",
         "Key 不对或已失效，重新粘贴一次。注意不要带多余的空格。"),
        ("提示连接失败 / 握手失败",
         "先点「设置 → 检测连接与 TLS」看具体原因。TLS 是程序自带的，"
         "所以握手失败通常是网络不通，或者系统时间差太多导致证书判无效。"),
        ("菜单和按钮是乱码",
         "这个程序是 GBK 编码的，需要中文版 Windows（系统代码页 936）。"),
        ("中文显示成方块",
         "系统里没有宋体。中文版 Windows 都自带。"),
        ("附件发出去说文件太大",
         "文本单个上限 128 KB，图片 32 MB，一次最多 6 个。太大的文本先把无关部分删掉再发。"),
        ("附件是什么格式",
         "文本和代码按文本读取，UTF-8 / GBK 自动识别，单个上限 128 KB；"
         "图片支持 png/jpg/jpeg/gif/bmp/ico，上限 32 MB，但只会把路径和尺寸告诉模型，"
         "像素内容不会上传。压缩包这类二进制仍然会被拒绝。"),
        ("Key 存在哪里",
         "exe 同目录的 xpwork.ini，明文。删掉这个文件就等于清空配置。"),
        ("会不会偷偷联网",
         "只有在你填了接口地址并点发送时才会请求那个地址，其它时候不联网。"),
    ]
    for q, a in faq:
        p = doc.add_paragraph()
        r = p.add_run("问：" + q)
        r.bold = True
        doc.add_paragraph("答：" + a)

    # 九
    doc.add_heading("十、文件清单", level=1)
    table(doc, [
        ["文件", "说明"],
        ["xp work Assistant.exe", "主程序（32 位，直接双击）"],
        ["xpwork.ini", "运行后生成，保存 Key / 地址 / 模型"],
        ["xp-tls/", "TLS 一键修复包：装 KB4019276 + 写注册表 + 自检"],
        ["tools/relay.py", "HTTP→HTTPS 中继，真 XP 连 DeepSeek 用"],
        ["src/", "源码（C，mingw-w64 编译；含自带 TLS 的 tls_http.c 和根证书）"],
        ["build.sh", "重新编译用"],
        ["使用说明.docx / .txt", "本文档"],
        ["README.md", "给开发者看的说明"],
    ])

    # 十
    doc.add_heading("十一、卸载", level=1)
    doc.add_paragraph(
        "删除整个文件夹即可。程序不写注册表、不装服务、不在系统目录留东西，"
        "唯一的外部文件就是同目录（或 %APPDATA%）下的 xpwork.ini。")

    out = os.path.join(HERE, "使用说明.docx")
    doc.save(out)
    return out


TXT = """xp work Assistant 桌面版 使用说明
=====================================
Windows XP 及以上的 32 位桌面程序 · 中文界面 · 可接 DeepSeek

一、这是什么
-------------------------------------
xp work Assistant 桌面版是一个 Windows 窗口程序（32 位，单个 exe，约 300 KB）。
界面是对话式编程助手：左边会话列表，中间对话，下面输入框。

不装 .NET、不装 VC++ 运行库、不写注册表。不填 API Key 时是「离线演示」，
回复是写好的剧本，用来熟悉界面；填了 DeepSeek 的 Key 之后，每条消息都会真的发给模型。

二、系统要求
-------------------------------------
* 操作系统：Windows XP SP3 及以上（32 位、64 位都能跑）
* 磁盘：约 1 MB
* 运行库：无
* 网络：接 DeepSeek 时需要；离线演示不需要
* 窗口：默认 760x560，最小 480x360

三、第一次运行
-------------------------------------
1. 双击 xp work Assistant.exe
2. 没填 Key 时，状态栏右下角显示「离线演示」。
   可以输入「修一下清除按钮」「跑一下测试」「讲讲 store.js」看看演示对话。
3. 程序不会自动联网，也不会在后台驻留。

四、界面说明
-------------------------------------
* 左侧栏：会话列表（可点选）、当前模型、版本号
* 对话区：用户消息（> 开头）、工具调用、代码 diff、回复
* 输入条：输入框 + 「发送 / 停止」按钮
* 状态栏：模型、token、花费、就绪 / 生成中 / 在线 / 离线演示
* 菜单栏：文件 / 编辑 / 会话 / 设置 / 帮助

常用菜单：
* 文件 -> 新建会话：清空对话
* 编辑 -> 复制对话：整段复制到剪贴板
* 编辑 -> 清空：清空对话区
* 会话：切换模型（离线演示时只改显示）
* 设置 -> API Key 与模型：填 Key、接口地址、模型
* 设置 -> 检测连接与 TLS：测网络和 TLS，报告状态码或错误码
* 帮助 -> 快捷键 / 关于

五、输入中文
-------------------------------------
输入框是 Unicode 控件，微软拼音、搜狗、QQ 拼音都能直接用。

重点：输入法开着的时候，回车是留给输入法的（选词、上屏），不会发送。
      要发送请按 Ctrl+Enter。
      输入法切到英文，或用纯英文键盘时，直接按回车就会发送。

输入框下面那行提示：ctrl+enter 发送 / esc 中断 / ↑↓ 历史

六、发送附件
-------------------------------------
三种方式：
  1. 点输入框左上角的「+ 添加附件」
  2. 菜单 文件 -> 添加附件…（Ctrl+O）
  3. 把文件直接拖进窗口

规则：
  * 一次最多 6 个；文本 128 KB，图片 32 MB
  * 只支持文本和代码，二进制文件会被拒绝
  * 点附件标签右边的 x 可以移除
  * UTF-8 和 GBK 都能自动识别

发送时附件内容会附在消息后面（[附件：文件名] + 代码块）。
离线演示时不会发网络请求，界面会提示附件不会被真的读取。

七、接 DeepSeek
-------------------------------------
1. 菜单 设置 -> API Key 与模型
2. 点「填入 DeepSeek 官方」，会自动填好：
     地址 https://api.deepseek.com/v1
     模型 deepseek-flash
3. 粘贴你的 API Key（sk- 开头），点确定
4. 状态栏右下角变成「在线」，就能正常提问了

配置存在 exe 同目录的 xpwork.ini 里，Key 是明文。
目录不可写时会退到 %APPDATA%\\xpwork.ini。
想回到离线演示：设置 -> 清除 API Key。

【让 AI 操作本机】
默认纯聊天。菜单 设置 ->「允许 AI 操作本机（执行命令 / 改文件）」打开后，
模型可以调用：
  run_cmd     用 cmd.exe /c 执行命令，返回输出和退出码
  read_file   读文本文件
  write_file  写文件（新建或覆盖）
  web_search  联网搜索（Bing），返回标题和链接
  download    从 http/https 链接下载文件到本机
  run_ps      用 PowerShell 执行（要装了才行）
执行过程实时显示在对话区。
安全限制：format / diskpart / shutdown / rd /s /del /f /s/reg delete 等
危险命令本地直接拒绝；工具循环不限轮数，随时可按停止/ESC 中断。
注意：打开后命令和文件改动都是真的。

【PowerShell】
run_ps 会用 powershell.exe 执行命令（-NoProfile -ExecutionPolicy Bypass -File）。
XP 默认不带，需要先装 .NET 2.0，再装 Windows PowerShell 2.0。
没装时工具会说明，模型会退回 cmd。关于窗口里能看到是否已安装。

【余额】
显示在「+ 添加附件」右边，点一下刷新，每 60 秒自动刷一次，
对话结束后也会刷。菜单 设置 -> 查询余额 是同一个动作。

【界面】
输入框上方一排：+ 添加附件 | 强度 ▼ | 余额
翻页：PgUp / PgDn，Ctrl+Home 到顶，Ctrl+End 到底，滚轮也行。
回答逐字显示。

【删除对话】
  * 侧边栏会话行，选中那条右边有 ×，点一下删掉
  * 菜单 编辑 -> 删除最后一轮对话（只砍最后一条问答）
  * 菜单 文件 -> 删除当前会话
  * 菜单 编辑 -> 清空全部对话（只清内容）

【会话管理】
选中会话行右侧的 … 打开三段菜单：
  重命名…       改名
  收藏/取消收藏  标题前加 ★
  归档/取消归档  收进侧边栏底部的「归档 N」，点它展开

【关于】
帮助 -> 关于 xp work Assistant 里有一段可以编辑的文字，
写什么都会存进 xpwork.ini，下次打开还在。
余额接口是 DeepSeek 专有的，换成别的服务会查询失败。

【推理强度】
「设置 -> API Key 与模型」窗口里有「推理强度」下拉列表
（菜单 设置 -> 推理强度 是同一个开关），四档：
  关闭思考  thinking.type = disabled   不输出思维链，最快
  低        reasoning_effort = low      轻量思考
  高        reasoning_effort = high     默认，和 API 默认一致
  最高      reasoning_effort = max      难题用，更慢更贵

在线时状态栏会显示当前档位（例如「deepseek-flash · 思考高」）。

连不上时先点「设置 -> 检测连接与 TLS」：
  TLS 正常会显示 HTTP 状态码；
  失败会说明原因，比如「TLS 握手失败（12157）」= XP 还没装 TLS 1.2 补丁。

【XP 上还要装 TLS 补丁吗】
不用。这一版把 mbedTLS 和根证书包编进了 exe，
https 由程序自己做 TLS 1.2 握手和证书校验，绕开 Windows 的加密栈。

所以：
  * 不需要 KB4019276 之类的补丁
  * 不需要导入根证书
  * 不需要中继
只有「系统时间」还会影响证书校验（时间差太多会被判无效）。
包里的 xp-tls 目录是给别的老程序用的，xp work Assistant 自己不用。

八、快捷键
-------------------------------------
Ctrl+Enter   发送（输入法开着时用这个）
Ctrl+O       添加附件
Enter        发送（英文输入状态下）
Esc          中断当前回复
↑ / ↓        翻输入历史
鼠标滚轮     翻看对话

九、常见问题
-------------------------------------
问：发了消息没反应，一直「生成中…」
答：填了接口地址就是在等模型，最长 120 秒；点「停止」可中断。

问：提示 HTTP 401
答：Key 不对或失效，重新粘贴一次，注意别带空格。

问：提示连接失败 / 握手失败
答：先点「设置 -> 检测连接与 TLS」。TLS 是程序自带的，
    握手失败通常是网络不通，或者系统时间差太多。

问：菜单和按钮是乱码
答：程序是 GBK 编码，需要中文版 Windows（代码页 936）。

问：中文显示成方块
答：系统里没有宋体，中文版 Windows 都自带。

问：附件发出去说文件太大
答：文本单个上限 128 KB，图片 32 MB，一次最多 6 个。

问：附件支持什么格式
答：按文本读取，UTF-8 / GBK 自动识别；图片、压缩包会被拒绝。

问：Key 存在哪里
答：exe 同目录的 xpwork.ini，明文。删掉即清空配置。

问：会不会偷偷联网
答：只有填了接口地址并点发送时才请求那个地址。

十、文件清单
-------------------------------------
xp work Assistant.exe  主程序（32 位，双击运行）
xpwork.ini        运行后生成，保存 Key / 地址 / 模型
xp-tls/             TLS 一键修复包（装补丁 + 写注册表 + 自检）
tools/relay.py      HTTP->HTTPS 中继，真 XP 连 DeepSeek 用
src/                源码（C 语言，mingw-w64 编译）
build.sh            重新编译用
使用说明.docx/.txt  本文档
README.md           给开发者看的说明

十一、卸载
-------------------------------------
删除整个文件夹即可。不写注册表、不装服务，
唯一的外部文件就是 xpwork.ini。
"""


if __name__ == "__main__":
    out = build()
    txt = os.path.join(HERE, "使用说明.txt")
    with open(txt, "w", encoding="utf-8-sig") as f:
        f.write(TXT)
    print("wrote", out)
    print("wrote", txt)
