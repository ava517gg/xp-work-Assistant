#!/usr/bin/env python3
"""relay.py -- 给 Windows XP 用的 HTTP -> HTTPS 中继

XP 的 SChannel 只支持到 TLS 1.0，api.deepseek.com 要求 TLS 1.2，
所以 XP 直连一定失败。这台中继跑在任意一台 TLS 正常的机器上：

    http://<中继机器>:8787/v1/chat/completions
        -> https://api.deepseek.com/v1/chat/completions

用法：
    python3 tools/relay.py --port 8787
    python3 tools/relay.py --port 8787 --upstream https://api.deepseek.com
    python3 tools/relay.py --port 8787 --host 127.0.0.1     # 只给本机用

然后把 opencode 里的「接口地址」填成 http://<中继机器>:8787/v1

只用标准库，Python 3.8+ 可跑。
注意：这是个开放代理，Key 由客户端带着走，中继不保存；但它会把
收到的 Authorization 头原样转发，所以别把它暴露到公网。
"""

import argparse
import json
import ssl
import sys
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

UPSTREAM = "https://api.deepseek.com"
TIMEOUT = 120


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "opencode-relay/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("[relay] %s %s\n" % (self.address_string(), fmt % args))

    def _forward(self, method):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else None
        url = self.server.upstream.rstrip("/") + self.path

        req = urllib.request.Request(url, data=body, method=method)
        for h in ("Content-Type", "Authorization", "Accept"):
            v = self.headers.get(h)
            if v:
                req.add_header(h, v)
        req.add_header("User-Agent", "opencode-relay/1.0")

        code = 502
        data = b""
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                code = r.status
                data = r.read()
        except urllib.error.HTTPError as e:
            code = e.code
            data = e.read()
        except Exception as e:  # 网络/证书问题
            data = json.dumps({"error": {"message": "relay: %s" % e}}).encode("utf-8")
            code = 502

        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        self._forward("POST")

    def do_GET(self):
        if self.path in ("/", "/health"):
            msg = b'{"ok":true,"upstream":"' + self.server.upstream.encode() + b'"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(msg)))
            self.end_headers()
            self.wfile.write(msg)
            return
        self._forward("GET")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--upstream", default=UPSTREAM)
    args = ap.parse_args()

    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    srv.upstream = args.upstream

    print("relay  %s:%d  ->  %s" % (args.host, args.port, args.upstream))
    print("在 opencode 里把接口地址填成  http://<这台机器>:%d/v1" % args.port)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")


if __name__ == "__main__":
    main()
