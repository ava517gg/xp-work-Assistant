/* tls_selftest.c -- 在 Linux 上直接跑 tls_http.c（同一份代码）验证握手和请求
 *
 *   cc -I../src -I<mbedtls>/include tls_selftest.c ../src/tls_http.c \
 *      <mbedtls>/build-linux/libmbedtls.a -o tls_selftest && ./tls_selftest
 *
 * 就是它抓到了 io_send 里误调 mbedtls_ssl_write 导致的无限递归。
 */
#include <stdio.h>
#include <string.h>
#include "tls_http.h"

static void run(const char *label, int pad) {
  static char body[20000], out[70000], err[512];
  char *p = body;
  int i;
  p += sprintf(p, "{\"model\":\"deepseek-flash\",\"messages\":[{\"role\":\"user\",\"content\":\"hi");
  for (i = 0; i < pad; i++) p += sprintf(p, " x");
  sprintf(p, "\"}]}");
  printf("== %s  (body %d 字节)\n", label, (int)strlen(body));
  int st = tls_http_post("https://api.deepseek.com/v1/chat/completions",
                         "Content-Type: application/json\r\nAuthorization: Bearer sk-test\r\n",
                         body, out, sizeof out, err, sizeof err);
  printf("   状态: %d   err=%s\n", st, err);
  if (st > 0) printf("   响应: %.70s\n", out);
}

int main(void) {
  run("短消息", 5);
  run("长消息（测缓冲）", 3000);
  return 0;
}
