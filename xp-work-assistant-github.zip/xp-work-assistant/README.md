# xp work Assistant

一个能跑在 **Windows XP** 上的 32 位 AI 编程助手桌面程序。

不用装运行库，单个 exe，界面全部 GDI 自绘，**TLS 也是程序自带**（mbedTLS + 内置根证书），
所以 XP 不需要打 TLS 补丁、不需要导入根证书，也不用中继。

```
>_ xp work Assistant
```

## 功能

- **接 DeepSeek**（OpenAI 兼容接口，Base URL 可改）
- **自带 TLS 1.2**：mbedTLS 2.28 编进 exe，绕过 XP 的 SChannel
- **工具调用**：`run_cmd`（cmd.exe）、`run_ps`（PowerShell）、`read_file`、`write_file`、`web_search`（Bing）、`download`
- **侧边栏预览**：模型读文件时滑出，代码带行号 + VSCode 风格高亮，图片用 GDI+ 渲染
- **选中代码右键**：浮出评论框，发布后把「文件 + 行号 + 代码块 + 你的意见」拼进输入框
- **推理强度**四档（关闭 / 低 / 高 / 最高）
- **余额查询**（60 秒自动刷新）+ **今日消耗**（按 token 估算）
- **API Key 加密存储**：Windows DPAPI，密文绑定当前用户和机器
- 中文界面（GBK）、中文输入法、附件、会话收藏/归档/重命名

## 运行

把 `bin/xp work Assistant.exe` 拷到 Windows XP SP3 上双击即可。

第一次打开：**设置 → API Key 与模型**，填接口地址、模型名、Key，点「填入 DeepSeek 官方」可以一键填好。

## 编译

需要 mingw-w64（i686）和 mbedTLS 2.28 源码：

```sh
sudo apt install gcc-mingw-w64-i686 binutils-mingw-w64-i686
curl -LO https://github.com/Mbed-TLS/mbedtls/archive/refs/tags/v2.28.8.tar.gz
tar xzf v2.28.8.tar.gz
MBEDTLS_DIR=./mbedtls-2.28.8 ./build.sh
```

产出 `bin/xp work Assistant.exe`（PE32 / GUI / 80386 / 子系统 4.0）。

`build.sh` 会自动给 mbedTLS 打一个 XP 兼容补丁（`vsnprintf_s` → `vsnprintf`）。

## 目录

```
src/        C 源码（界面、网络、工具、设置）
res/        图标
tools/      说明书生成、中继、TLS 自测
docs/       使用说明（docx + txt）
xp-tls/     给别的老程序用的 TLS 修复包（本程序不需要）
PowerShell2.0-XP/   XP 上装 PowerShell 2.0 的一键脚本
```

## 已知限制

- 只支持 32 位 Windows（XP SP3 及以上）；界面是 GBK，需要中文版 Windows
- `run_ps` 需要机器上装了 PowerShell 2.0（XP 默认不带）
- 图片预览只显示第一帧，不做 GIF 动画
- 今日消耗是按 token 单价**估算**，不是官方账单

## License

MIT，见 [LICENSE](LICENSE)。
