/* main_win32.c -- 窗口、菜单、输入框 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <imm.h>
#include <commdlg.h>
#include <shellapi.h>

#include "gfx.h"
#include "ui.h"
#include "net.h"
#include "settings.h"
#include "agent.h"
#include "tls_http.h"
#include "json.h"
#include "exec.h"

#define WM_APP_NET (WM_APP + 1)
#define WM_APP_PROBE (WM_APP + 2)
#define WM_APP_TOOL  (WM_APP + 3)
#define WM_APP_AGENT_DONE (WM_APP + 4)
#define WM_APP_BALANCE (WM_APP + 5)

void pick_attachments(void);
static int load_attachment(const char *path);

#define ID_INPUT  101

#define IDM_NEW   201
#define IDM_EXIT  202
#define IDM_COPY  211
#define IDM_CLEAR 212
#define IDM_DEL_LAST 213
#define IDM_DEL_SESS 214
#define IDM_MODEL 220   /* 220..223 */
#define IDM_ATTACH 203
#define IDM_TOOLS 265
#define IDM_BALANCE 266
#define IDC_CMT_EDIT 901
#define IDC_CMT_OK 902
#define IDC_CMT_CANCEL 903
#define IDM_PROBE 260
#define IDM_EFFORT 250   /* 250..253 */
#define IDM_SETTINGS 240
#define IDM_CLEARKEY 241
#define IDM_ABOUT 231
#define IDM_KEYS  232

static HWND  g_hwnd;
static int   g_dragging;   /* 正在拖侧边栏分隔条 */
static HWND  g_edit;
static HDC   g_mem;
static HBITMAP g_bmp;
static HBITMAP g_old_bmp;
static int   g_bw, g_bh;
static WNDPROC g_old_edit;
static HBRUSH g_input_brush;

static char history[16][256];
static int  nhist, hpos;

static void ensure_backbuffer(HDC dc, int w, int h) {
  if (g_mem && g_bw == w && g_bh == h) return;
  if (g_mem) {
    if (g_old_bmp) SelectObject(g_mem, g_old_bmp);
    if (g_bmp) DeleteObject(g_bmp);
    DeleteDC(g_mem);
  }
  g_mem = CreateCompatibleDC(dc);
  g_bmp = CreateCompatibleBitmap(dc, w, h);
  g_old_bmp = (HBITMAP)SelectObject(g_mem, g_bmp);
  g_bw = w;
  g_bh = h;
}

/* ---- 选中代码后弹出的悬浮评论框 ---- */
static HWND g_cmt_label, g_cmt_edit, g_cmt_btn_ok, g_cmt_btn_cancel;

static void comment_create(void) {
  if (g_cmt_edit) return;
  g_cmt_label = CreateWindowExA(0, "STATIC", "添加此更改的上下文",
                                WS_CHILD, 0, 0, 260, 16, g_hwnd, NULL, NULL, NULL);
  g_cmt_edit = CreateWindowExA(WS_EX_CLIENTEDGE, "EDIT", "",
                               WS_CHILD | WS_TABSTOP | WS_VSCROLL |
                               ES_MULTILINE | ES_AUTOVSCROLL | ES_WANTRETURN,
                               0, 0, 264, 52, g_hwnd, (HMENU)IDC_CMT_EDIT, NULL, NULL);
  g_cmt_btn_cancel = CreateWindowExA(0, "BUTTON", "取消", WS_CHILD | WS_TABSTOP,
                                     0, 0, 64, 22, g_hwnd, (HMENU)IDC_CMT_CANCEL, NULL, NULL);
  g_cmt_btn_ok = CreateWindowExA(0, "BUTTON", "发布评论", WS_CHILD | WS_TABSTOP | BS_DEFPUSHBUTTON,
                                 0, 0, 84, 22, g_hwnd, (HMENU)IDC_CMT_OK, NULL, NULL);
}

static void comment_show(int x, int y) {
  HWND kids[4];
  int i;
  RECT rc;
  GetClientRect(g_hwnd, &rc);
  comment_create();
  if (x + 280 > rc.right) x = rc.right - 280;
  if (y + 108 > rc.bottom) y = rc.bottom - 108;
  if (x < 0) x = 0;
  if (y < 0) y = 0;

  MoveWindow(g_cmt_label, x + 8, y + 6, 260, 16, TRUE);
  MoveWindow(g_cmt_edit, x + 8, y + 24, 264, 52, TRUE);
  MoveWindow(g_cmt_btn_cancel, x + 122, y + 80, 64, 22, TRUE);
  MoveWindow(g_cmt_btn_ok, x + 190, y + 80, 84, 22, TRUE);

  kids[0] = g_cmt_label; kids[1] = g_cmt_edit; kids[2] = g_cmt_btn_cancel; kids[3] = g_cmt_btn_ok;
  for (i = 0; i < 4; i++) {
    ShowWindow(kids[i], SW_SHOW);
    SetWindowPos(kids[i], HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
  }
  SetWindowTextA(g_cmt_edit, "");
  SetFocus(g_cmt_edit);
}

static void comment_hide(void) {
  if (!g_cmt_edit) return;
  ShowWindow(g_cmt_label, SW_HIDE);
  ShowWindow(g_cmt_edit, SW_HIDE);
  ShowWindow(g_cmt_btn_cancel, SW_HIDE);
  ShowWindow(g_cmt_btn_ok, SW_HIDE);
  if (g_edit) SetFocus(g_edit);
}

static void layout_edit(void) {
  RECT rc;
  int x, y, w, h;
  GetClientRect(g_hwnd, &rc);
  ui_input_rect(&x, &y, &w, &h);
  MoveWindow(g_edit, x, y, w, h, TRUE);
}

static void hist_add(const char *s) {
  if (nhist < 16) {
    strncpy(history[nhist], s, 255);
    history[nhist][255] = 0;
    nhist++;
  } else {
    memmove(history[0], history[1], sizeof history[0] * 15);
    strncpy(history[15], s, 255);
    history[15][255] = 0;
  }
  hpos = nhist;
}

/* 输入框里是 UTF-16，界面层要 GBK */
static void edit_get_gbk(char *out, int cap) {
  wchar_t w[512];
  out[0] = 0;
  if (!GetWindowTextW(g_edit, w, 512)) return;
  WideCharToMultiByte(CP_ACP, 0, w, -1, out, cap, NULL, NULL);
}

static void edit_set_gbk(const char *gbk) {
  wchar_t w[512];
  MultiByteToWideChar(CP_ACP, 0, gbk, -1, w, 512);
  SetWindowTextW(g_edit, w);
}

/* 输入法是不是正在组词（这时候回车是给输入法的） */
static int ime_composing(HWND h) {
  HIMC imc = ImmGetContext(h);
  LONG n;
  int composing = 0;
  if (!imc) return 0;
  n = ImmGetCompositionStringW(imc, GCS_COMPSTR, NULL, 0);
  if (n > 0) composing = 1;
  ImmReleaseContext(h, imc);
  return composing;
}

/* 回车该不该交给输入法：只要输入法开着就让路，避免抢走选词的回车 */
static int enter_is_for_ime(HWND h) {
  HIMC imc;
  if (!ImmIsIME(GetKeyboardLayout(0))) return 0;
  imc = ImmGetContext(h);
  if (imc) {
    LONG n = ImmGetCompositionStringW(imc, GCS_COMPSTR, NULL, 0);
    ImmReleaseContext(h, imc);
    if (n > 0) return 1;
  }
  return 1;
}

static void send_current(void) {
  char buf[1024];
  if (ui_busy()) return;
  edit_get_gbk(buf, sizeof buf);
  if (!buf[0] && ui_attach_count() == 0) return;
  hist_add(buf);
  ui_send(buf);
  SetWindowTextW(g_edit, L"");
  InvalidateRect(g_hwnd, NULL, FALSE);
}

static void stop_current(void) {
  if (!ui_busy()) return;
  ui_abort();
  InvalidateRect(g_hwnd, NULL, FALSE);
}

static LRESULT CALLBACK EditProc(HWND h, UINT m, WPARAM w, LPARAM l) {
  if (m == WM_MOUSEWHEEL) {
    SendMessage(GetParent(h), WM_MOUSEWHEEL, w, l);
    return 0;
  }
  if (m == WM_CHAR && (w == 13 || w == 27)) return 0;
  if (m == WM_KEYDOWN) {
    if (w == VK_RETURN) {
      /* Ctrl+Enter 一定发送；否则输入法组词中就把回车让给输入法 */
      if (GetKeyState(VK_CONTROL) & 0x8000) { send_current(); return 0; }
      if (enter_is_for_ime(h)) return CallWindowProc(g_old_edit, h, m, w, l);
      send_current();
      return 0;
    }
    if (w == VK_ESCAPE) { stop_current(); return 0; }
    if (w == VK_PRIOR) { ui_scroll_by(10); InvalidateRect(GetParent(h), NULL, FALSE); return 0; }
    if (w == VK_NEXT)  { ui_scroll_by(-10); InvalidateRect(GetParent(h), NULL, FALSE); return 0; }
    if (w == VK_HOME && (GetKeyState(VK_CONTROL) & 0x8000)) {
      ui_scroll_by(100000); InvalidateRect(GetParent(h), NULL, FALSE); return 0;
    }
    if (w == VK_END && (GetKeyState(VK_CONTROL) & 0x8000)) {
      ui_scroll_to_bottom(); InvalidateRect(GetParent(h), NULL, FALSE); return 0;
    }
    if (w == 'O' && (GetKeyState(VK_CONTROL) & 0x8000)) { pick_attachments(); return 0; }
    if (w == VK_UP || w == VK_DOWN) {
      if (ime_composing(h)) return CallWindowProc(g_old_edit, h, m, w, l);
    }
    if (w == VK_UP) {
      if (nhist && hpos > 0) {
        hpos--;
        edit_set_gbk(history[hpos]);
        SendMessageA(h, EM_SETSEL, (WPARAM)-1, (LPARAM)-1);
      }
      return 0;
    }
    if (w == VK_DOWN) {
      if (nhist) {
        if (hpos < nhist - 1) {
          hpos++;
          edit_set_gbk(history[hpos]);
        } else {
          hpos = nhist;
          SetWindowTextW(h, L"");
        }
        SendMessageA(h, EM_SETSEL, (WPARAM)-1, (LPARAM)-1);
      }
      return 0;
    }
  }
  return CallWindowProc(g_old_edit, h, m, w, l);
}

static void copy_transcript(void) {
  static char big[64 * 1024];
  int n = ui_transcript(big, sizeof big);
  HGLOBAL mem;
  if (!n) return;
  if (!OpenClipboard(g_hwnd)) return;
  EmptyClipboard();
  mem = GlobalAlloc(GMEM_MOVEABLE, (SIZE_T)n + 1);
  if (mem) {
    void *p = GlobalLock(mem);
    if (p) {
      memcpy(p, big, (size_t)n);
      ((char *)p)[n] = 0;
      GlobalUnlock(mem);
      SetClipboardData(CF_TEXT, mem);
    }
  }
  CloseClipboard();
}

static void sync_model_menu(HMENU bar) {
  HMENU m = GetSubMenu(bar, 2);
  int i;
  if (!m) return;
  for (i = 0; i < 4; i++)
    CheckMenuItem(m, IDM_MODEL + i, (i == ui_model()) ? MF_CHECKED : MF_UNCHECKED);
}

static void sync_effort_menu(HMENU bar) {
  HMENU cfg, eff;
  const char *e;
  int idx = 2;
  if (!bar) return;
  cfg = GetSubMenu(bar, 3);          /* 文件 编辑 会话 设置 帮助 */
  if (!cfg) return;
  eff = GetSubMenu(cfg, 2);          /* 设置 -> 推理强度 */
  if (!eff) return;
  e = settings_effort();
  if (!strcmp(e, "off")) idx = 0;
  else if (!strcmp(e, "low")) idx = 1;
  else if (!strcmp(e, "max")) idx = 3;
  CheckMenuRadioItem(eff, IDM_EFFORT, IDM_EFFORT + 3, IDM_EFFORT + idx, MF_BYCOMMAND);
}

static void sync_tools_menu(HMENU bar) {
  HMENU cfg;
  if (!bar) return;
  cfg = GetSubMenu(bar, 3);
  if (!cfg) return;
  CheckMenuItem(cfg, IDM_TOOLS, settings_tools_enabled() ? MF_CHECKED : MF_UNCHECKED);
}

static DWORD WINAPI balance_thread(LPVOID param);
static int balance_pending;
static int balance_tick;
static int balance_force = 1;

static void start_balance(void) {
  HANDLE th;
  if (!settings_ready() || balance_pending) return;
  balance_pending = 1;
  th = CreateThread(NULL, 0, balance_thread, NULL, 0, NULL);
  if (th) CloseHandle(th);
  else balance_pending = 0;
}

static HMENU build_menu(void) {
  HMENU bar = CreateMenu();
  HMENU file = CreatePopupMenu();
  HMENU edit = CreatePopupMenu();
  HMENU sess = CreatePopupMenu();
  HMENU cfg = CreatePopupMenu();
  HMENU eff = CreatePopupMenu();
  HMENU help = CreatePopupMenu();

  AppendMenuA(file, MF_STRING, IDM_NEW, "新建会话(&N)");
  AppendMenuA(file, MF_STRING, IDM_DEL_SESS, "删除当前会话(&D)");
  AppendMenuA(file, MF_STRING, IDM_ATTACH, "添加附件(&A)…\tCtrl+O");
  AppendMenuA(file, MF_SEPARATOR, 0, NULL);
  AppendMenuA(file, MF_STRING, IDM_EXIT, "退出(&X)");

  AppendMenuA(eff, MF_STRING, IDM_EFFORT + 0, "关闭思考(&F)");
  AppendMenuA(eff, MF_STRING, IDM_EFFORT + 1, "低(&L)");
  AppendMenuA(eff, MF_STRING, IDM_EFFORT + 2, "高(&H)");
  AppendMenuA(eff, MF_STRING, IDM_EFFORT + 3, "最高(&M)");

  AppendMenuA(edit, MF_STRING, IDM_COPY, "复制对话(&C)");
  AppendMenuA(edit, MF_STRING, IDM_DEL_LAST, "删除最后一轮对话(&D)");
  AppendMenuA(edit, MF_STRING, IDM_CLEAR, "清空全部对话(&L)");

  AppendMenuA(sess, MF_STRING, IDM_MODEL + 0, "claude-sonnet-4");
  AppendMenuA(sess, MF_STRING, IDM_MODEL + 1, "gpt-5-codex");
  AppendMenuA(sess, MF_STRING, IDM_MODEL + 2, "qwen3-coder");
  AppendMenuA(sess, MF_STRING, IDM_MODEL + 3, "claude-opus-4.5");

  AppendMenuA(cfg, MF_STRING, IDM_SETTINGS, "API Key 与模型(&K)…");
  AppendMenuA(cfg, MF_STRING, IDM_BALANCE, "查询余额(&B)");
  AppendMenuA(cfg, MF_SEPARATOR, 0, NULL);
  AppendMenuA(cfg, MF_POPUP, (UINT_PTR)eff, "推理强度(&E)");
  AppendMenuA(cfg, MF_SEPARATOR, 0, NULL);
  AppendMenuA(cfg, MF_STRING, IDM_TOOLS, "允许 AI 操作本机（执行命令 / 改文件）(&A)");
  AppendMenuA(cfg, MF_STRING, IDM_PROBE, "检测连接与 TLS(&T)…");
  AppendMenuA(cfg, MF_SEPARATOR, 0, NULL);
  AppendMenuA(cfg, MF_STRING, IDM_CLEARKEY, "清除 API Key(&C)");

  AppendMenuA(help, MF_STRING, IDM_KEYS, "快捷键(&K)");
  AppendMenuA(help, MF_STRING, IDM_ABOUT, "关于 xp work Assistant(&A)");

  AppendMenuA(bar, MF_POPUP, (UINT_PTR)file, "文件(&F)");
  AppendMenuA(bar, MF_POPUP, (UINT_PTR)edit, "编辑(&E)");
  AppendMenuA(bar, MF_POPUP, (UINT_PTR)sess, "会话(&S)");
  AppendMenuA(bar, MF_POPUP, (UINT_PTR)cfg, "设置(&O)");
  AppendMenuA(bar, MF_POPUP, (UINT_PTR)help, "帮助(&H)");
  return bar;
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  switch (msg) {
    case WM_CREATE: {
      HMENU bar = GetMenu(hwnd);
      RECT rc;
      HFONT f;
      int x, y, w, h;

      GetClientRect(hwnd, &rc);
      ui_init();
      ui_resize(rc.right, rc.bottom);

      ui_input_rect(&x, &y, &w, &h);
      /* 用 Unicode 版 EDIT：输入法上屏的是 UTF-16，不受系统 ANSI 代码页影响 */
      g_edit = CreateWindowExW(0, L"EDIT", L"",
                               WS_CHILD | WS_VISIBLE | ES_LEFT | ES_AUTOHSCROLL,
                               x, y, w, h, hwnd, (HMENU)ID_INPUT,
                               (HINSTANCE)GetWindowLongPtrA(hwnd, GWLP_HINSTANCE), NULL);
      f = CreateFontA(-14, 0, 0, 0, FW_NORMAL, 0, 0, 0, GB2312_CHARSET,
                      OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                      FIXED_PITCH | FF_MODERN, "SimSun");
      SendMessageA(g_edit, WM_SETFONT, (WPARAM)f, TRUE);
      g_old_edit = (WNDPROC)SetWindowLongPtrA(g_edit, GWLP_WNDPROC, (LONG_PTR)EditProc);

      if (settings_ready()) {
        char b[320];
        snprintf(b, sizeof b, "  在线模式：%s  /  %s", settings_base(), settings_model());
        ui_notice(b);
      }

      DragAcceptFiles(hwnd, TRUE);
      g_input_brush = CreateSolidBrush(RGB(11, 14, 18));
      SetTimer(hwnd, 1, 25, NULL);
      SetTimer(hwnd, 7, 5000, NULL);
      if (bar) { sync_model_menu(bar); sync_effort_menu(bar); sync_tools_menu(bar); }
      return 0;
    }

    case WM_KEYDOWN:
      if (wp == VK_PRIOR) { ui_scroll_by(10); InvalidateRect(hwnd, NULL, FALSE); return 0; }
      if (wp == VK_NEXT)  { ui_scroll_by(-10); InvalidateRect(hwnd, NULL, FALSE); return 0; }
      if (wp == VK_HOME && (GetKeyState(VK_CONTROL) & 0x8000)) {
        ui_scroll_by(100000); InvalidateRect(hwnd, NULL, FALSE); return 0;
      }
      if (wp == VK_END && (GetKeyState(VK_CONTROL) & 0x8000)) {
        ui_scroll_to_bottom(); InvalidateRect(hwnd, NULL, FALSE); return 0;
      }
      break;

    case WM_SIZE:
      ui_resize(LOWORD(lp), HIWORD(lp));
      layout_edit();
      InvalidateRect(hwnd, NULL, FALSE);
      return 0;

    case WM_GETMINMAXINFO: {
      MINMAXINFO *mm = (MINMAXINFO *)lp;
      mm->ptMinTrackSize.x = 480;
      mm->ptMinTrackSize.y = 360;
      return 0;
    }

    case WM_ERASEBKGND:
      return 1;

    case WM_PAINT: {
      PAINTSTRUCT ps;
      RECT rc;
      HDC dc = BeginPaint(hwnd, &ps);
      GetClientRect(hwnd, &rc);
      if (rc.right <= 0 || rc.bottom <= 0) { EndPaint(hwnd, &ps); return 0; }
      ensure_backbuffer(dc, rc.right, rc.bottom);
      gfx_set_target(g_mem);
      gfx_begin(rc.right, rc.bottom);
      ui_paint();
      gfx_end();
      BitBlt(dc, 0, 0, rc.right, rc.bottom, g_mem, 0, 0, SRCCOPY);
      EndPaint(hwnd, &ps);
      return 0;
    }

    case WM_APP_TOOL: {
      char *txt = (char *)lp;
      int before = ui_sidebar_w();
      ui_tool_event((int)wp, txt);
      free(txt);
      if (ui_sidebar_w() != before) layout_edit();   /* 侧边栏弹出来了，输入框跟着挪 */
      InvalidateRect(hwnd, NULL, TRUE);
      return 0;
    }

    case WM_APP_BALANCE: {
      char *txt = (char *)lp;
      balance_pending = 0;
      balance_tick = 0;
      if (wp == 0) {
        ui_balance_set(txt);
      } else {
        char line[300];
        snprintf(line, sizeof line, "  %s", txt);
        ui_notice(line);
      }
      free(txt);
      InvalidateRect(hwnd, NULL, TRUE);
      return 0;
    }

    case WM_APP_AGENT_DONE:
      ui_agent_done();
      balance_force = 1;
      InvalidateRect(hwnd, NULL, FALSE);
      return 0;

    case WM_APP_PROBE:
      ui_probe_done();
      InvalidateRect(hwnd, NULL, FALSE);
      return 0;

    case WM_APP_NET:
      ui_net_done((int)wp);
      InvalidateRect(hwnd, NULL, FALSE);
      return 0;

    case WM_TIMER:
      if (wp == 7) {
        balance_tick++;
        if (balance_force || balance_tick >= 12) {   /* 每 60 秒刷一次 */
          balance_force = 0;
          start_balance();
        }
        return 0;
      }
      if (ui_busy() || ui_typing() || ui_animating()) {
        ui_tick();
        InvalidateRect(hwnd, NULL, FALSE);
      }
      return 0;

    case WM_RBUTTONDOWN: {
      int x = GET_X_LPARAM(lp), y = GET_Y_LPARAM(lp);
      if (ui_preview_hit(x, y)) {
        comment_show(x, y);
        return 0;
      }
      return 0;
    }

    case WM_SETCURSOR: {
      POINT pt;
      GetCursorPos(&pt);
      ScreenToClient(hwnd, &pt);
      if (ui_divider_hit(pt.x, pt.y) || g_dragging) {
        SetCursor(LoadCursorA(NULL, IDC_SIZEWE));
        return TRUE;
      }
      break;                       /* 其余交给默认处理 */
    }

    case WM_MOUSEMOVE: {
      int mx = GET_X_LPARAM(lp), my = GET_Y_LPARAM(lp);
      if (g_dragging) {
        ui_set_sidebar_w(mx);
        layout_edit();
        InvalidateRect(hwnd, NULL, TRUE);
        return 0;
      }
      if (ui_preview_hit(mx, my) && (wp & MK_LBUTTON)) {
        ui_preview_sel_update(my);
        InvalidateRect(hwnd, NULL, FALSE);
      }
      return 0;
    }

    case WM_LBUTTONUP:
      if (g_dragging) {
        g_dragging = 0;
        ReleaseCapture();
        return 0;
      }
      if (GetCapture() == hwnd) ReleaseCapture();
      return 0;

    case WM_MOUSEWHEEL: {
      int delta = GET_WHEEL_DELTA_WPARAM(wp);
      ui_scroll_by(-(delta / WHEEL_DELTA) * 3);
      InvalidateRect(hwnd, NULL, FALSE);
      return 0;
    }

    case WM_LBUTTONDOWN: {
      int x = (short)LOWORD(lp), y = (short)HIWORD(lp);
      int act;
      if (ui_divider_hit(x, y)) {
        g_dragging = 1;
        SetCapture(hwnd);
        return 0;
      }
      act = ui_click(x, y);
      layout_edit();
      if (act == UI_CLICK_EFFORT) {
        int ex, ey, ew, eh;
        HMENU m = CreatePopupMenu();
        ui_effort_rect(&ex, &ey, &ew, &eh);
        AppendMenuA(m, MF_STRING, IDM_EFFORT + 0, "关闭思考");
        AppendMenuA(m, MF_STRING, IDM_EFFORT + 1, "低");
        AppendMenuA(m, MF_STRING, IDM_EFFORT + 2, "高");
        AppendMenuA(m, MF_STRING, IDM_EFFORT + 3, "最高");
        {
          int cur = 2;
          char lbl[32];
          settings_effort_label();
          snprintf(lbl, sizeof lbl, "%s", settings_effort());
          if (!strcmp(lbl, "off")) cur = 0;
          else if (!strcmp(lbl, "low")) cur = 1;
          else if (!strcmp(lbl, "max")) cur = 3;
          CheckMenuRadioItem(m, IDM_EFFORT + 0, IDM_EFFORT + 3, IDM_EFFORT + cur, MF_BYCOMMAND);
        }
        {
          POINT pt;
          pt.x = ex;
          pt.y = ey + eh + 2;
          ClientToScreen(hwnd, &pt);
          {
            int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN,
                                     pt.x, pt.y, 0, hwnd, NULL);
            if (cmd >= IDM_EFFORT && cmd <= IDM_EFFORT + 3) {
              static const char *V[4] = { "off", "low", "high", "max" };
              settings_set_effort(V[cmd - IDM_EFFORT]);
              settings_save();
              sync_effort_menu(GetMenu(hwnd));
              InvalidateRect(hwnd, NULL, FALSE);
            }
          }
        }
        DestroyMenu(m);
        return 0;
      }
      if (act == UI_CLICK_PREVIEW_LINE) {
        SetCapture(hwnd);          /* 拖着选多行 */
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;
      }
      if (act == UI_CLICK_DELETE_SESSION) {
        int idx = ui_menu_session();
        char q[256];
        snprintf(q, sizeof q, "删除会话「%s」？\n\n对话内容会一起清掉，不能撤销。",
                 ui_session_title(idx));
        if (MessageBoxA(hwnd, q, "删除会话", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES) {
          ui_delete_session(idx);
          InvalidateRect(hwnd, NULL, FALSE);
        }
        return 0;
      }
      if (act == UI_CLICK_ARCHIVED_TOGGLE) {
        ui_toggle_archived_view();
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;
      }
      if (act == UI_CLICK_SESSION_MENU) {
        int idx = ui_menu_session();
        HMENU m = CreatePopupMenu();
        POINT pt;
        AppendMenuA(m, MF_STRING, 1, "重命名…");
        AppendMenuA(m, MF_SEPARATOR, 0, NULL);
        AppendMenuA(m, MF_STRING, 2, ui_session_fav(idx) ? "取消收藏" : "收藏");
        AppendMenuA(m, MF_SEPARATOR, 0, NULL);
        AppendMenuA(m, MF_STRING, 3, ui_session_archived(idx) ? "取消归档" : "归档");
        GetCursorPos(&pt);
        {
          int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN,
                                   pt.x, pt.y, 0, hwnd, NULL);
          if (cmd == 1) {
            char name[64];
            snprintf(name, sizeof name, "%s", ui_session_title(idx));
            if (oc_prompt(hwnd, "重命名会话", "新的会话名：", name, sizeof name, 0))
              ui_rename_session(idx, name);   /* EDIT 取出来就是本地编码 */
          } else if (cmd == 2) {
            ui_toggle_fav(idx);
          } else if (cmd == 3) {
            ui_toggle_archived(idx);
          }
        }
        DestroyMenu(m);
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;
      }
      if (act == UI_CLICK_PREVIEW_BTN) {
        ui_preview_toggle();
        InvalidateRect(hwnd, NULL, TRUE);
        return 0;
      }
      if (act == UI_CLICK_BALANCE) {
        if (settings_ready()) start_balance();
        else ui_notice("  先填 API Key 和接口地址");
        return 0;
      }
      if (act == UI_CLICK_SEND) {
        if (ui_busy()) stop_current();
        else { SetFocus(g_edit); send_current(); }
      } else if (act == UI_CLICK_ATTACH) {
        pick_attachments();
      } else {
        SetFocus(g_edit);
      }
      InvalidateRect(hwnd, NULL, FALSE);
      return 0;
    }

    case WM_DROPFILES: {
      HDROP hd = (HDROP)wp;
      UINT n = DragQueryFileA(hd, 0xFFFFFFFF, NULL, 0);
      UINT i;
      for (i = 0; i < n; i++) {
        char path[MAX_PATH];
        if (DragQueryFileA(hd, i, path, MAX_PATH)) load_attachment(path);
      }
      DragFinish(hd);
      SetFocus(g_edit);
      InvalidateRect(hwnd, NULL, FALSE);
      return 0;
    }

    case WM_CTLCOLOREDIT:
      SetTextColor((HDC)wp, RGB(232, 234, 236));
      SetBkColor((HDC)wp, RGB(11, 14, 18));
      return (LRESULT)g_input_brush;

    case WM_COMMAND:
      switch (LOWORD(wp)) {
        case IDM_NEW:
          ui_new_session();
          InvalidateRect(hwnd, NULL, FALSE);
          return 0;
        case IDM_DEL_SESS:
          if (MessageBoxA(hwnd, "删除当前会话？\n\n对话内容会一起清掉，不能撤销。",
                          "删除会话", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES) {
            ui_delete_session(ui_current_session());
          }
          InvalidateRect(hwnd, NULL, FALSE);
          return 0;
        case IDM_DEL_LAST:
          ui_delete_last_exchange();
          InvalidateRect(hwnd, NULL, FALSE);
          return 0;
        case IDM_CLEAR:
          ui_reset();
          InvalidateRect(hwnd, NULL, FALSE);
          return 0;
        case IDM_ATTACH:
          pick_attachments();
          return 0;
        case IDM_COPY:
          copy_transcript();
          return 0;
        case IDM_SETTINGS:
          if (settings_dialog(hwnd)) {
            char b[320];
            snprintf(b, sizeof b, "  已保存：%s  /  %s  /  推理强度 %s%s",
                     settings_base(), settings_model(), settings_effort_label(),
                     settings_key_plain() ? "（密钥未能加密，已明文保存）" : "");
            ui_notice(b);
            sync_model_menu(GetMenu(hwnd));
            sync_effort_menu(GetMenu(hwnd));
            InvalidateRect(hwnd, NULL, FALSE);
          }
          return 0;
        case IDM_TOOLS:
          if (!settings_tools_enabled()) {
            if (MessageBoxA(hwnd,
                  "允许 AI 在你电脑上执行命令、读写文件？\n\n"
                  "它会通过 cmd.exe 执行命令，改动磁盘上的真实文件。\n"
                  "危险命令（format、del /s、reg delete 等）会被本地规则拒绝，\n"
                  "但仍然建议只在你信任的对话里打开。",
                  "安全提示", MB_YESNO | MB_ICONWARNING) != IDYES)
              return 0;
            settings_set_tools(1);
            ui_notice("  已允许 AI 操作本机（可用菜单再关掉）");
          } else {
            settings_set_tools(0);
            ui_notice("  已关闭本机操作");
          }
          settings_save();
          sync_tools_menu(GetMenu(hwnd));
          InvalidateRect(hwnd, NULL, FALSE);
          return 0;
        case IDM_BALANCE:
          if (!settings_ready()) {
            ui_notice("  先填 API Key 和接口地址");
          } else {
            start_balance();
          }
          InvalidateRect(hwnd, NULL, FALSE);
          return 0;
        case IDM_PROBE:
          if (oc_probe_send()) ui_notice("  正在检测网络与 TLS …");
          else ui_notice("  检测启动失败");
          InvalidateRect(hwnd, NULL, FALSE);
          return 0;
        case IDM_CLEARKEY:
          settings_clear_key();
          ui_notice("  已清除 API Key，回到离线演示。");
          InvalidateRect(hwnd, NULL, FALSE);
          return 0;
        case IDM_EXIT:
          DestroyWindow(hwnd);
          return 0;
        case IDC_CMT_CANCEL:
          comment_hide();
          return 0;
        case IDC_CMT_OK: {
          char typed[512], sel[2048], cur[1024], add[3200], all[4400];
          int a = 0, b = 0, n;
          GetWindowTextA(g_cmt_edit, typed, sizeof typed);
          sel[0] = 0;
          ui_preview_selected_text(sel, sizeof sel);
          ui_preview_sel(&a, &b);
          n = GetWindowTextA(g_edit, cur, sizeof cur);
          if (n < 0) n = 0;
          cur[n] = 0;
          if (sel[0])
            snprintf(add, sizeof add, "%s\n> %s 第 %d-%d 行：\n```\n%s```\n%s\n",
                     cur[0] ? "\n" : "", ui_preview_name(), a, b, sel,
                     typed[0] ? typed : "我的意见：");
          else
            snprintf(add, sizeof add, "%s%s", cur[0] ? " " : "", typed);
          snprintf(all, sizeof all, "%s%s", cur, add);
          SetWindowTextA(g_edit, all);
          SendMessageA(g_edit, EM_SETSEL, (WPARAM)-1, (LPARAM)-1);
          comment_hide();
          return 0;
        }
        case IDM_ABOUT: {
          char note[2048], info[2048], psline[128];
          char ps[MAX_PATH];
          int have_ps = exec_have_powershell(ps, sizeof ps);

          snprintf(note, sizeof note, "%s", settings_note());
          snprintf(psline, sizeof psline, "PowerShell：%s",
                   have_ps ? "已安装（可以用 run_ps）" : "未安装（只能用 cmd）");
          snprintf(info, sizeof info,
                   "xp work Assistant 1.0  Windows XP 桌面版\r\n"
                   "备注：本程序大部分采用 deepseek-v4.1 flash 构建\r\n"
                   "作者：ava517gg\r\n"
                   "余额每分钟刷新 1 次（你也可以手动刷新）\r\n"
                   "这个包里的 PowerShell 2.0 要 SP3 的机器才可以\r\n"
                   "请自行升级\r\n"
                   "API key：存在配置文件 ini（已加密）\r\n"
                   "应该可以自上网搜索\r\n"
                   "后续估计会慢慢优化\r\n"
                   ":p\r\n"
                   "%s\r\n"
                   "────────────────────\r\n"
                   "下面是你自己的备注（存进 xpwork.ini）：",
                   psline);
          if (oc_prompt(hwnd, "关于 xp work Assistant", info, note, sizeof note, 1)) {
            settings_set_note(note);
            ui_notice("  备注已保存");
          }
          InvalidateRect(hwnd, NULL, FALSE);
          return 0;
        }
        case IDM_KEYS:
          MessageBoxA(hwnd,
            "Ctrl+Enter   发送（输入法开着时用这个）\n"
            "Enter        发送（英文输入状态下）\n"
            "Ctrl+Enter   强制发送\n"
            "Esc          中断当前回复\n"
            "↑ / ↓        输入历史\n"
            "滚轮         翻看对话\n\n"
            "输入框支持中文输入法。\n"
            "/help /clear /model /about 由 agent 处理。",
            "快捷键", MB_OK | MB_ICONINFORMATION);
          return 0;
        default:
          if (LOWORD(wp) >= IDM_EFFORT && LOWORD(wp) < IDM_EFFORT + 4) {
            static const char *V[4] = { "off", "low", "high", "max" };
            char b[96];
            settings_set_effort(V[LOWORD(wp) - IDM_EFFORT]);
            settings_save();
            sync_effort_menu(GetMenu(hwnd));
            snprintf(b, sizeof b, "  推理强度：%s", settings_effort_label());
            ui_notice(b);
            InvalidateRect(hwnd, NULL, FALSE);
            return 0;
          }
          if (LOWORD(wp) >= IDM_MODEL && LOWORD(wp) < IDM_MODEL + 4) {
            ui_set_model(LOWORD(wp) - IDM_MODEL);
            sync_model_menu(GetMenu(hwnd));
            InvalidateRect(hwnd, NULL, FALSE);
            return 0;
          }
          break;
      }
      break;

    case WM_DESTROY:
      KillTimer(hwnd, 1);
      PostQuitMessage(0);
      return 0;
  }
  return DefWindowProc(hwnd, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmd, int show) {
  WNDCLASSA wc;
  HMENU bar;
  RECT rc;
  HWND hwnd;
  MSG msg;

  (void)hPrev; (void)cmd;
  g_hwnd = NULL;
  settings_init();
  settings_load();
  cost_init();

  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = WndProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 0;
  wc.hInstance = hInst;
  wc.hIcon = LoadIconA(hInst, MAKEINTRESOURCEA(1));
  if (!wc.hIcon) wc.hIcon = LoadIconA(NULL, IDI_APPLICATION);
  wc.hCursor = LoadCursorA(NULL, IDC_ARROW);
  wc.hbrBackground = NULL;
  wc.lpszMenuName = NULL;
  wc.lpszClassName = "OpencodeDesktop";
  if (!wc.hIcon) wc.hIcon = NULL;

  if (!RegisterClassA(&wc)) return 1;

  bar = build_menu();

  rc.left = 0; rc.top = 0; rc.right = 760; rc.bottom = 560;
  AdjustWindowRectEx(&rc, WS_OVERLAPPEDWINDOW, TRUE, 0);

  hwnd = CreateWindowExA(0, "OpencodeDesktop",
                         "xp work Assistant",
                         WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                         CW_USEDEFAULT, CW_USEDEFAULT,
                         rc.right - rc.left, rc.bottom - rc.top,
                         NULL, bar, hInst, NULL);
  if (!hwnd) return 1;
  g_hwnd = hwnd;

  ShowWindow(hwnd, show);
  UpdateWindow(hwnd);
  SetFocus(g_edit);

  while (GetMessage(&msg, NULL, 0, 0) > 0) {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  return (int)msg.wParam;
}

/* ---------------------------------------------------------------- 附件 */

static void to_gbk(const char *src, int len, char *out, int cap) {
  int wn = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, src, len, NULL, 0);
  if (wn > 0) {
    wchar_t *w = (wchar_t *)malloc(sizeof(wchar_t) * (size_t)wn);
    if (w) {
      MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, src, len, w, wn);
      WideCharToMultiByte(CP_ACP, 0, w, wn, out, cap - 1, NULL, NULL);
      out[cap - 1] = 0;
      free(w);
      return;
    }
  }
  /* 不是合法 UTF-8，就当作系统 ANSI（GBK）文本 */
  if (len > cap - 1) len = cap - 1;
  memcpy(out, src, (size_t)len);
  out[len] = 0;
}

static int is_image_ext(const char *path) {
  const char *e = strrchr(path, '.');
  if (!e) return 0;
  e++;
  return !_stricmp(e, "png") || !_stricmp(e, "jpg") || !_stricmp(e, "jpeg") ||
         !_stricmp(e, "gif") || !_stricmp(e, "bmp") || !_stricmp(e, "ico") ||
         !_stricmp(e, "webp") || !_stricmp(e, "tif") || !_stricmp(e, "tiff");
}

/* 从文件头读出宽高，读不出就给 0 */
static void image_size(const unsigned char *b, int n, int *w, int *h) {
  *w = *h = 0;
  if (n > 24 && b[0] == 0x89 && b[1] == 'P') {              /* PNG */
    *w = (b[16] << 24) | (b[17] << 16) | (b[18] << 8) | b[19];
    *h = (b[20] << 24) | (b[21] << 16) | (b[22] << 8) | b[23];
  } else if (n > 10 && b[0] == 'G' && b[1] == 'I' && b[2] == 'F') {   /* GIF */
    *w = b[6] | (b[7] << 8);
    *h = b[8] | (b[9] << 8);
  } else if (n > 26 && b[0] == 'B' && b[1] == 'M') {        /* BMP */
    *w = b[18] | (b[19] << 8) | (b[20] << 16) | (b[21] << 24);
    *h = b[22] | (b[23] << 8) | (b[24] << 16) | (b[25] << 24);
  } else if (n > 4 && b[0] == 0xFF && b[1] == 0xD8) {       /* JPEG */
    int i = 2;
    while (i + 9 < n) {
      if (b[i] != 0xFF) { i++; continue; }
      if (b[i + 1] >= 0xC0 && b[i + 1] <= 0xCF &&
          b[i + 1] != 0xC4 && b[i + 1] != 0xC8 && b[i + 1] != 0xCC) {
        *h = (b[i + 5] << 8) | b[i + 6];
        *w = (b[i + 7] << 8) | b[i + 8];
        break;
      }
      i += 2 + ((b[i + 2] << 8) | b[i + 3]);
    }
  }
}

static int load_attachment(const char *path) {
  FILE *f;
  long sz;
  char *raw;
  static char gbk[68 * 1024];
  const char *p;
  int len, i;
  const char *name;

  if (ui_attach_count() >= 6) {
    MessageBoxA(g_hwnd, "一次最多带 6 个附件。", "附件", MB_OK | MB_ICONINFORMATION);
    return 0;
  }

  f = fopen(path, "rb");
  if (!f) {
    MessageBoxA(g_hwnd, "打不开这个文件。", "附件", MB_OK | MB_ICONWARNING);
    return 0;
  }
  fseek(f, 0, SEEK_END);
  sz = ftell(f);
  fseek(f, 0, SEEK_SET);
  if (sz <= 0) {
    fclose(f);
    MessageBoxA(g_hwnd, "文件是空的。", "附件", MB_OK | MB_ICONWARNING);
    return 0;
  }
  if (is_image_ext(path)) {
    /* 图片只取元信息，不读内容，所以大小不限（上限 32 MB 防呆） */
    unsigned char head[512];
    int got, w = 0, h = 0;
    char desc[512], name2[128];
    const char *nm = strrchr(path, '\\');
    nm = nm ? nm + 1 : path;

    if (sz > 32L * 1024 * 1024) {
      fclose(f);
      MessageBoxA(g_hwnd, "图片太大了，上限 32 MB。", "附件", MB_OK | MB_ICONWARNING);
      return 0;
    }
    got = (int)fread(head, 1, sizeof head, f);
    fclose(f);
    image_size(head, got, &w, &h);

    if (w > 0 && h > 0)
      snprintf(desc, sizeof desc,
               "路径：%s\r\n格式：图片，%d×%d，%.1f KB\r\n"
               "（模型看不到像素内容，需要处理时可以用 run_cmd 打开或调用系统工具）",
               path, w, h, sz / 1024.0);
    else
      snprintf(desc, sizeof desc,
               "路径：%s\r\n格式：图片，%.1f KB\r\n"
               "（模型看不到像素内容，需要处理时可以用 run_cmd 打开或调用系统工具）",
               path, sz / 1024.0);

    snprintf(name2, sizeof name2, "%s", nm);
    ui_attach_add(name2, sz, desc, 1);
    ui_preview_set(path, "", 1, w, h);
    InvalidateRect(g_hwnd, NULL, FALSE);
    return 1;
  }

  if (sz > 128 * 1024) {
    fclose(f);
    MessageBoxA(g_hwnd, "文本文件太大了，单个上限 128 KB。", "附件", MB_OK | MB_ICONWARNING);
    return 0;
  }

  raw = (char *)malloc((size_t)sz + 1);
  if (!raw) { fclose(f); return 0; }
  len = (int)fread(raw, 1, (size_t)sz, f);
  fclose(f);
  raw[len] = 0;

  for (i = 0; i < len && i < 512; i++) {
    if (raw[i] == 0) {
      free(raw);
      MessageBoxA(g_hwnd, "这不是文本文件，只支持文本和代码。", "附件", MB_OK | MB_ICONWARNING);
      return 0;
    }
  }

  p = raw;
  if (len >= 3 && (unsigned char)p[0] == 0xEF && (unsigned char)p[1] == 0xBB && (unsigned char)p[2] == 0xBF) {
    p += 3;
    len -= 3;
  }
  to_gbk(p, len, gbk, sizeof gbk);

  name = strrchr(path, '\\');
  name = name ? name + 1 : path;
  ui_attach_add(name, sz, gbk, 0);
  free(raw);
  InvalidateRect(g_hwnd, NULL, FALSE);
  return 1;
}

static void handle_open_result(char *files) {
  char dir[MAX_PATH];
  char *p = files;

  strncpy(dir, p, MAX_PATH - 1);
  dir[MAX_PATH - 1] = 0;
  p += strlen(p) + 1;

  if (*p == 0) {           /* 只选了一个：整个串就是完整路径 */
    load_attachment(dir);
    return;
  }
  while (*p && ui_attach_count() < 6) {
    char full[MAX_PATH * 2];
    snprintf(full, sizeof full, "%s\\%s", dir, p);
    load_attachment(full);
    p += strlen(p) + 1;
  }
}

void pick_attachments(void) {
  static char files[4096];
  OPENFILENAMEA ofn;

  memset(&ofn, 0, sizeof ofn);
  files[0] = 0;
  ofn.lStructSize = sizeof ofn;
  ofn.hwndOwner = g_hwnd;
  ofn.lpstrFilter =
      "文本、代码与图片\0"
      "*.txt;*.md;*.js;*.json;*.css;*.html;*.c;*.h;*.cpp;*.py;*.java;*.ini;*.log;*.bat;*.xml;*.yml\0"
      "图片 (*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.ico)\0"
      "*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.ico\0"
      "所有文件 (*.*)\0*.*\0";
  ofn.lpstrFile = files;
  ofn.nMaxFile = sizeof files;
  ofn.lpstrTitle = "选择要附加的文件";
  ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY;

  if (GetOpenFileNameA(&ofn)) handle_open_result(files);
}

/* ---------------------------------------------------------------- 在线接口 */

int oc_online(void) { return settings_ready(); }

int oc_net_send(const char *text, int gen) {
  if (!g_hwnd) return 0;
  return net_start(g_hwnd, WM_APP_NET, text, gen);
}

int oc_net_take(int gen, char *out, int cap, char *err, int errcap) {
  return net_take(gen, out, cap, err, errcap);
}

const char *oc_model_name(void) { return settings_model(); }
const char *oc_effort_label(void) { return settings_effort_label(); }

/* ---------------------------------------------------------------- 余额 */

static DWORD WINAPI balance_thread(LPVOID param) {
  static char resp[8192], err[512], url[600], hdr[700];
  const char *base = settings_base();
  char *p;
  (void)param;

  snprintf(url, sizeof url, "%s", base);
  p = strstr(url, "/v1");
  if (p) *p = 0;
  snprintf(url + strlen(url), sizeof url - strlen(url), "/user/balance");
  snprintf(hdr, sizeof hdr, "Authorization: Bearer %s\r\n", settings_key());

  if (tls_http_get_h(url, hdr, resp, sizeof resp, err, sizeof err) == 200) {
    char cur[16], total[32], avail[16];
    char out[128];
    json_get_str(resp, "currency", cur, sizeof cur);
    json_get_str(resp, "total_balance", total, sizeof total);
    json_get_str(resp, "is_available", avail, sizeof avail);
    if (total[0]) {
      if (!strcmp(cur, "CNY")) snprintf(out, sizeof out, "余额 ￥%s", total);
      else snprintf(out, sizeof out, "余额 %s %s", total, cur);
    } else {
      snprintf(out, sizeof out, "余额查询失败");
    }
    {
      char *copy = (char *)malloc(strlen(out) + 1);
      if (copy) {
        strcpy(copy, out);
        PostMessageA(g_hwnd, WM_APP_BALANCE, 0, (LPARAM)copy);
      }
    }
  } else {
    char msg[256];
    snprintf(msg, sizeof msg, "余额查询失败：%s", err[0] ? err : "接口无响应");
    {
      char *copy = (char *)malloc(strlen(msg) + 1);
      if (copy) {
        strcpy(copy, msg);
        PostMessageA(g_hwnd, WM_APP_BALANCE, 1, (LPARAM)copy);
      }
    }
  }
  return 0;
}

/* ---------------------------------------------------------------- agent */

static void agent_emit(int kind, const char *text) {
  size_t n;
  char *copy;
  if (!text) return;
  n = strlen(text);
  copy = (char *)malloc(n + 1);
  if (!copy) return;
  memcpy(copy, text, n + 1);
  PostMessageA(g_hwnd, WM_APP_TOOL, (WPARAM)kind, (LPARAM)copy);
}

static DWORD WINAPI agent_thread(LPVOID param) {
  char *text = (char *)param;
  agent_run(text, agent_emit);
  free(text);
  PostMessageA(g_hwnd, WM_APP_AGENT_DONE, 0, 0);
  return 0;
}

int oc_agent_start(const char *text) {
  char *copy;
  HANDLE th;
  size_t n;
  if (!g_hwnd || !text) return 0;
  n = strlen(text);
  copy = (char *)malloc(n + 1);
  if (!copy) return 0;
  memcpy(copy, text, n + 1);
  th = CreateThread(NULL, 0, agent_thread, copy, 0, NULL);
  if (!th) { free(copy); return 0; }
  CloseHandle(th);
  return 1;
}

void oc_agent_abort(void) { agent_abort(); }
void oc_agent_reset(void) { agent_reset(); }

void oc_layout_changed(void) {
  if (g_hwnd) {
    layout_edit();
    InvalidateRect(g_hwnd, NULL, FALSE);
  }
}
unsigned long oc_ticks(void) { return (unsigned long)GetTickCount(); }

int oc_today_cost(char *out, int cap) {
  double y = cost_today();
  if (!out || cap < 8) return 0;
  snprintf(out, cap, "今日 ￥%.2f", y);
  return 1;
}

int oc_probe_send(void) {
  if (!g_hwnd) return 0;
  return probe_start(g_hwnd, WM_APP_PROBE, settings_base());
}

int oc_probe_take(char *out, int cap) { return probe_take(out, cap); }
