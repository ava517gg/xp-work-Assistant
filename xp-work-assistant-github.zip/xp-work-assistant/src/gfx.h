/* gfx.h -- 极小的绘图接口
 * Win32 后端画到窗口 DC；SVG 后端把同样的调用记录成文件（用于在别的平台上预览）。
 */
#ifndef GFX_H
#define GFX_H

typedef struct { unsigned char r, g, b; } Color;

#define FONT_UI   0   /* Tahoma 12px */
#define FONT_MONO 1   /* Courier New 13px */

void gfx_set_target(void *ctx);   /* Win32: HDC；SVG 后端忽略 */
void gfx_begin(int w, int h);
void gfx_end(void);
void gfx_fill(int x, int y, int w, int h, Color c);
void gfx_frame(int x, int y, int w, int h, Color c);
void gfx_text(int x, int y, const char *s, int len, Color c, int font, int clip_r);
int  gfx_image(const char *path, int x, int y, int w, int h);   /* 返回 1 表示画成功 */

int  gfx_cell_w(int font);
int  gfx_line_h(int font);

#define RGB_(r, g, b) ((Color){ (unsigned char)(r), (unsigned char)(g), (unsigned char)(b) })

#endif
