/* tls_http.h -- 自带的 HTTPS 客户端（mbedTLS + 内置证书包） */
#ifndef TLS_HTTP_H
#define TLS_HTTP_H

/* 返回 HTTP 状态码；<0 表示连接/握手失败，err 里是中文原因 */
int tls_http_post(const char *url, const char *headers, const char *body,
                  char *out, int cap, char *err, int ecap);

int tls_http_get(const char *url, char *out, int cap, char *err, int ecap);
int tls_http_get_h(const char *url, const char *headers, char *out, int cap, char *err, int ecap);

/* 把 URL 的内容原样存成文件（二进制安全）。返回 HTTP 状态码，<0 失败 */
int tls_download(const char *url, const char *headers, const char *path,
                 int *saved, char *err, int ecap);

#endif
