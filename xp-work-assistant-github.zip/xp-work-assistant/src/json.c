/* json.c -- 极简 JSON 读取/转义
 *
 * 不追求完整，只处理 OpenAI 兼容响应里会出现的形态：
 *   "key":"字符串"、"key":{对象}、"key":[{数组}]
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "json.h"

static int hex4(const char *p) {
  int v = 0, i;
  for (i = 0; i < 4; i++) {
    char c = p[i];
    v <<= 4;
    if (c >= '0' && c <= '9') v += c - '0';
    else if (c >= 'a' && c <= 'f') v += c - 'a' + 10;
    else if (c >= 'A' && c <= 'F') v += c - 'A' + 10;
    else return -1;
  }
  return v;
}

static int utf8_put(char *out, int n, int cp) {
  if (cp < 0x80) out[n++] = (char)cp;
  else if (cp < 0x800) {
    out[n++] = (char)(0xC0 | (cp >> 6));
    out[n++] = (char)(0x80 | (cp & 0x3F));
  } else if (cp < 0x10000) {
    out[n++] = (char)(0xE0 | (cp >> 12));
    out[n++] = (char)(0x80 | ((cp >> 6) & 0x3F));
    out[n++] = (char)(0x80 | (cp & 0x3F));
  } else {
    out[n++] = (char)(0xF0 | (cp >> 18));
    out[n++] = (char)(0x80 | ((cp >> 12) & 0x3F));
    out[n++] = (char)(0x80 | ((cp >> 6) & 0x3F));
    out[n++] = (char)(0x80 | (cp & 0x3F));
  }
  return n;
}

int json_get_str(const char *obj, const char *key, char *out, int cap) {
  char pat[128];
  const char *p;
  int n = 0;

  if (!obj || !key) return 0;
  snprintf(pat, sizeof pat, "\"%s\"", key);
  p = strstr(obj, pat);
  if (!p) return 0;
  p = strchr(p + strlen(pat), ':');
  if (!p) return 0;
  p++;
  while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') p++;
  if (*p != '"') return 0;
  p++;

  while (*p && *p != '"' && n < cap - 6) {
    if (*p == '\\') {
      p++;
      switch (*p) {
        case 'n': out[n++] = '\n'; p++; break;
        case 't': out[n++] = '\t'; p++; break;
        case 'r': out[n++] = '\r'; p++; break;
        case '"': out[n++] = '"'; p++; break;
        case '\\': out[n++] = '\\'; p++; break;
        case '/': out[n++] = '/'; p++; break;
        case 'b': p++; break;
        case 'f': p++; break;
        case 'u': {
          int cp = hex4(p + 1);
          if (cp < 0) { p++; break; }
          p += 5;
          if (cp >= 0xD800 && cp <= 0xDBFF && p[0] == '\\' && p[1] == 'u') {
            int lo = hex4(p + 2);
            if (lo >= 0xDC00 && lo <= 0xDFFF) {
              cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
              p += 6;
            }
          }
          n = utf8_put(out, n, cp);
          break;
        }
        default: out[n++] = *p; p++; break;
      }
    } else {
      out[n++] = *p++;
    }
  }
  if (n >= cap) n = cap - 1;
  out[n] = 0;
  return n;
}

void json_escape(const char *in, char *out, int cap) {
  int n = 0;
  while (in && *in && n < cap - 8) {
    unsigned char c = (unsigned char)*in++;
    if (c == '"' || c == '\\') { out[n++] = '\\'; out[n++] = (char)c; }
    else if (c == '\n') { out[n++] = '\\'; out[n++] = 'n'; }
    else if (c == '\r') { out[n++] = '\\'; out[n++] = 'r'; }
    else if (c == '\t') { out[n++] = '\\'; out[n++] = 't'; }
    else if (c < 0x20) { out[n++] = ' '; }
    else out[n++] = (char)c;
  }
  out[n] = 0;
}

int json_get_raw(const char *obj, const char *key, char *out, int cap) {
  char pat[128];
  const char *p;
  int depth = 0, n = 0;

  if (!obj || !key) return 0;
  snprintf(pat, sizeof pat, "\"%s\"", key);
  p = strstr(obj, pat);
  if (!p) return 0;
  p = strchr(p + strlen(pat), ':');
  if (!p) return 0;
  p++;
  while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') p++;
  if (*p != '{' && *p != '[') return 0;

  while (*p && n < cap - 1) {
    char c = *p;
    out[n++] = c;
    if (c == '"') {                     /* 跳过字符串里的括号 */
      p++;
      while (*p && *p != '"') {
        if (n >= cap - 2) break;
        if (*p == '\\' && p[1]) { out[n++] = *p++; }
        if (n >= cap - 1) break;
        out[n++] = *p++;
      }
      if (*p == '"' && n < cap - 1) out[n++] = *p++;
      continue;
    }
    if (c == '{' || c == '[') depth++;
    else if (c == '}' || c == ']') {
      depth--;
      if (depth == 0) { p++; break; }
    }
    p++;
  }
  if (n >= cap) n = cap - 1;
  out[n] = 0;
  return n;
}

int json_get_int(const char *obj, const char *key, long *out) {
  char pat[128];
  const char *p;
  long v = 0;
  int neg = 0, got = 0;

  if (!obj || !key || !out) return 0;
  snprintf(pat, sizeof pat, "\"%s\"", key);
  p = strstr(obj, pat);
  if (!p) return 0;
  p = strchr(p + strlen(pat), ':');
  if (!p) return 0;
  p++;
  while (*p == ' ' || *p == '\t') p++;
  if (*p == '-') { neg = 1; p++; }
  while (*p >= '0' && *p <= '9') { v = v * 10 + (*p - '0'); p++; got = 1; }
  if (!got) return 0;
  *out = neg ? -v : v;
  return 1;
}
