/* json.h -- 够用就好的 JSON 小工具 */
#ifndef OC_JSON_H
#define OC_JSON_H

/* 在 obj 里找 "key":"..." 并把字符串解出来（支持 \" \\ \n \t \uXXXX） */
int json_get_str(const char *obj, const char *key, char *out, int cap);

/* 把字符串转义成 JSON 字面量内容（不含两侧引号） */
void json_escape(const char *in, char *out, int cap);

/* 找 "key": 后面第一个 '{' 或 '['，配平括号，把整段拷出来 */
int json_get_raw(const char *obj, const char *key, char *out, int cap);
int json_get_int(const char *obj, const char *key, long *out);

#endif
