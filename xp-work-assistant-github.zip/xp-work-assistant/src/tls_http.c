/* tls_http.c -- 自带 TLS 的 HTTP 客户端
 *
 * 为什么要有它：Windows XP 的 SChannel 只到 TLS 1.0，补丁 + 根证书折腾下来
 * 还是会被现代 CDN 拒掉。这个文件把 mbedTLS 和一份 CA 证书包直接编进 exe，
 * 自己完成 TLS 1.2 握手和证书校验，系统的加密栈完全不参与。
 *
 * 只实现需要的那点东西：一次 HTTP/1.1 请求、Content-Length 或 chunked 响应。
 */

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#define closesocket close
#define INVALID_SOCKET (-1)
typedef int SOCKET;
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/x509_crt.h"
#include "mbedtls/error.h"

#include "tls_http.h"
#include "certs.h"

#define MAX_RESP (256 * 1024)
#define TIMEOUT_MS 30000

/* ---------------------------------------------------------------- 基础 */

static int g_wsa;

static void ensure_wsa(void) {
#ifdef _WIN32
  if (!g_wsa) {
    WSADATA w;
    WSAStartup(MAKEWORD(2, 2), &w);
    g_wsa = 1;
  }
#else
  g_wsa = 1;
#endif
}

static void set_nonblock(SOCKET s, int on) {
#ifdef _WIN32
  u_long nb = (u_long)on;
  ioctlsocket(s, FIONBIO, &nb);
#else
  int fl = fcntl(s, F_GETFL, 0);
  fcntl(s, F_SETFL, on ? (fl | O_NONBLOCK) : (fl & ~O_NONBLOCK));
#endif
}

static int parse_url(const char *url, char *host, int hcap, int *port,
                     char *path, int pcap, int *is_https) {
  const char *p = url;
  const char *h;
  int n = 0;

  *is_https = 0;
  *port = 80;
  if (strncmp(p, "https://", 8) == 0) { *is_https = 1; *port = 443; p += 8; }
  else if (strncmp(p, "http://", 7) == 0) { p += 7; }
  else return 0;

  h = p;
  while (*p && *p != '/' && *p != ':' && n < hcap - 1) host[n++] = *p++;
  host[n] = 0;
  if (!n) return 0;

  if (*p == ':') {
    p++;
    *port = atoi(p);
    while (*p && *p != '/') p++;
  }
  if (*p == 0) snprintf(path, pcap, "/");
  else snprintf(path, pcap, "%s", p);
  return 1;
}

static SOCKET dial(const char *host, int port, char *err, int ecap) {
  struct addrinfo hints, *res = NULL, *ai;
  char portstr[16];
  SOCKET s = INVALID_SOCKET;

  memset(&hints, 0, sizeof hints);
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  snprintf(portstr, sizeof portstr, "%d", port);

  if (getaddrinfo(host, portstr, &hints, &res) != 0) {
    snprintf(err, ecap, "域名解析失败：%s", host);
    return INVALID_SOCKET;
  }

  for (ai = res; ai; ai = ai->ai_next) {
    fd_set wf;
    struct timeval tv;
    s = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
    if (s == INVALID_SOCKET) continue;

    set_nonblock(s, 1);
    if (connect(s, ai->ai_addr, (int)ai->ai_addrlen) == 0) {
      set_nonblock(s, 0);
      break;
    }
    FD_ZERO(&wf);
    FD_SET(s, &wf);
    tv.tv_sec = TIMEOUT_MS / 1000;
    tv.tv_usec = 0;
    if (select((int)s + 1, NULL, &wf, NULL, &tv) == 1) {
      set_nonblock(s, 0);
      break;
    }
    closesocket(s);
    s = INVALID_SOCKET;
  }
  freeaddrinfo(res);

  if (s == INVALID_SOCKET) {
    snprintf(err, ecap, "连不上 %s:%d（端口不通或被防火墙拦了）", host, port);
    return INVALID_SOCKET;
  }
  {
#ifdef _WIN32
    DWORD to = TIMEOUT_MS;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char *)&to, sizeof to);
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (const char *)&to, sizeof to);
#else
    struct timeval tv;
    tv.tv_sec = TIMEOUT_MS / 1000;
    tv.tv_usec = 0;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv);
#endif
  }
  return s;
}

/* ---------------------------------------------------------------- 读写 */

typedef struct {
  SOCKET s;
  mbedtls_ssl_context *ssl;
} Io;

/* mbedTLS 的 bio 回调只能做“传输层”：直接读写 socket。
 * 绝不能在这里调 mbedtls_ssl_write，否则 ssl_write -> flush -> bio -> ssl_write 无限递归。 */
static int bio_send(void *ctx, const unsigned char *buf, size_t len) {
  Io *io = (Io *)ctx;
  int n = send(io->s, (const char *)buf, (int)len, 0);
  if (n <= 0) return MBEDTLS_ERR_NET_SEND_FAILED;
  return n;
}

static int bio_recv(void *ctx, unsigned char *buf, size_t len) {
  Io *io = (Io *)ctx;
  int n = recv(io->s, (char *)buf, (int)len, 0);
  if (n == 0) return MBEDTLS_ERR_NET_CONN_RESET;
  if (n < 0) return MBEDTLS_ERR_NET_RECV_FAILED;
  return n;
}

/* 对上层：有 TLS 就走 TLS，没有就直连 */
static int conn_send(Io *io, const unsigned char *buf, size_t len) {
  if (io->ssl) return mbedtls_ssl_write(io->ssl, buf, len);
  return bio_send(io, buf, len);
}

static int conn_recv(Io *io, unsigned char *buf, size_t len) {
  if (io->ssl) return mbedtls_ssl_read(io->ssl, buf, len);
  return bio_recv(io, buf, len);
}

static int send_all(Io *io, const char *data, int len) {
  int sent = 0;
  while (sent < len) {
    int n = conn_send(io, (const unsigned char *)data + sent, (size_t)(len - sent));
    if (n <= 0) {
      if (n == MBEDTLS_ERR_SSL_WANT_READ || n == MBEDTLS_ERR_SSL_WANT_WRITE) continue;
      return 0;
    }
    sent += n;
  }
  return 1;
}

/* ---------------------------------------------------------------- 响应解析 */

static int hexval(int c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

/* chunked 解码，就地写回；返回解码后长度 */
static int dechunk(char *body, int len) {
  char *in = body;
  char *out = body;
  int remain = len;

  while (remain > 0) {
    char *eol = in;
    long sz = 0;
    int digits = 0;
    while (eol < in + remain && *eol != '\r' && *eol != '\n') {
      int v = hexval((unsigned char)*eol);
      if (v < 0) break;
      sz = sz * 16 + v;
      digits++;
      eol++;
    }
    if (!digits) break;
    while (eol < in + remain && *eol != '\n') eol++;
    if (eol >= in + remain) break;
    eol++;                        /* 跳过 \n */
    if (sz <= 0) break;           /* 结束块 */
    if (sz > in + remain - eol) sz = (long)(in + remain - eol);
    memcpy(out, eol, (size_t)sz);
    out += sz;
    in = eol + sz;
    remain = (int)(body + len - in);
    while (in < body + len && (*in == '\r' || *in == '\n')) { in++; remain--; }
  }
  return (int)(out - body);
}

/* ---------------------------------------------------------------- 请求 */

static int request_ex(const char *method, const char *url, const char *headers,
                      const char *body, char *out, int cap, char *err, int ecap,
                      char **raw_body, int *raw_len) {
  char host[256], path[1024];
  int port, is_https, status = -1, total = 0;
  SOCKET s = INVALID_SOCKET;
  Io io;
  mbedtls_ssl_context ssl;
  mbedtls_ssl_config conf;
  mbedtls_entropy_context ent;
  mbedtls_ctr_drbg_context drbg;
  mbedtls_x509_crt ca;
  int tls_ready = 0;
  static char buf[MAX_RESP + 1];

  if (out && cap > 0) out[0] = 0;
  if (err && ecap > 0) err[0] = 0;

  ensure_wsa();
  if (!parse_url(url, host, sizeof host, &port, path, sizeof path, &is_https)) {
    snprintf(err, ecap, "接口地址不合法：%s", url);
    return -1;
  }

  s = dial(host, port, err, ecap);
  if (s == INVALID_SOCKET) return -1;

  io.s = s;
  io.ssl = NULL;

  if (is_https) {
    int ret;
    int n;

    mbedtls_ssl_init(&ssl);
    mbedtls_ssl_config_init(&conf);
    mbedtls_entropy_init(&ent);
    mbedtls_ctr_drbg_init(&drbg);
    mbedtls_x509_crt_init(&ca);

    n = mbedtls_x509_crt_parse(&ca, (const unsigned char *)CA_PEM, sizeof CA_PEM);
    if (n < 0) {
      snprintf(err, ecap, "内置证书包解析失败");
      goto cleanup;
    }
    if ((ret = mbedtls_ctr_drbg_seed(&drbg, mbedtls_entropy_func, &ent,
                                     (const unsigned char *)"xpwork", 8)) != 0) {
      snprintf(err, ecap, "随机数初始化失败");
      goto cleanup;
    }
    if ((ret = mbedtls_ssl_config_defaults(&conf, MBEDTLS_SSL_IS_CLIENT,
                                           MBEDTLS_SSL_TRANSPORT_STREAM,
                                           MBEDTLS_SSL_PRESET_DEFAULT)) != 0) {
      snprintf(err, ecap, "TLS 配置失败");
      goto cleanup;
    }
    mbedtls_ssl_conf_authmode(&conf, MBEDTLS_SSL_VERIFY_REQUIRED);
    mbedtls_ssl_conf_ca_chain(&conf, &ca, NULL);
    mbedtls_ssl_conf_rng(&conf, mbedtls_ctr_drbg_random, &drbg);
    /* XP 老机器留给握手的耐心有限，这里放宽一点 */
    mbedtls_ssl_conf_read_timeout(&conf, TIMEOUT_MS);

    if ((ret = mbedtls_ssl_setup(&ssl, &conf)) != 0) {
      snprintf(err, ecap, "TLS 初始化失败");
      goto cleanup;
    }
    if ((ret = mbedtls_ssl_set_hostname(&ssl, host)) != 0) {
      snprintf(err, ecap, "SNI 设置失败");
      goto cleanup;
    }
    mbedtls_ssl_set_bio(&ssl, &io, bio_send, bio_recv, NULL);

    ret = mbedtls_ssl_handshake(&ssl);
    if (ret != 0) {
      uint32_t vr = mbedtls_ssl_get_verify_result(&ssl);
      if (vr != 0) {
        char vbuf[256];
        mbedtls_x509_crt_verify_info(vbuf, sizeof vbuf, "  ", vr);
        snprintf(err, ecap, "证书校验没通过（内置证书包里没有对应的根证书）");
      } else {
        char ebuf[128];
        mbedtls_strerror(ret, ebuf, sizeof ebuf);
        snprintf(err, ecap, "TLS 握手失败：%s", ebuf);
      }
      goto cleanup;
    }
    tls_ready = 1;
    io.ssl = &ssl;
  }

  {
    int hlen, blen, total;
    char *msg;

    hlen = (int)strlen(method) + (int)strlen(path) + (int)strlen(host) +
           (int)strlen(headers ? headers : "") + 128;
    blen = body ? (int)strlen(body) : 0;
    msg = (char *)malloc((size_t)hlen + (size_t)blen + 1);
    if (!msg) {
      snprintf(err, ecap, "内存不足");
      goto cleanup;
    }
    if (strcmp(method, "POST") == 0)
      total = snprintf(msg, (size_t)hlen + 1,
                       "%s %s HTTP/1.1\r\n"
                       "Host: %s\r\n"
                       "%s"
                       "Content-Length: %d\r\n"
                       "Connection: close\r\n"
                       "\r\n",
                       method, path, host, headers ? headers : "", blen);
    else
      total = snprintf(msg, (size_t)hlen + 1,
                       "%s %s HTTP/1.1\r\n"
                       "Host: %s\r\n"
                       "%s"
                       "Connection: close\r\n"
                       "\r\n",
                       method, path, host, headers ? headers : "");
    if (blen > 0) {
      memcpy(msg + total, body, (size_t)blen);
      total += blen;
    }
    if (getenv("TLS_DEBUG")) {
      fwrite(msg, 1, (size_t)(total > 400 ? 400 : total), stderr);
      fprintf(stderr, "\n[total %d bytes]\n", total);
    }
    if (!send_all(&io, msg, total)) {
      free(msg);
      snprintf(err, ecap, "发送请求失败");
      goto cleanup;
    }
    free(msg);
  }

  for (;;) {
    int n;
    if (total >= MAX_RESP) break;
    n = conn_recv(&io, (unsigned char *)buf + total, (size_t)(MAX_RESP - total));
    if (n <= 0) {
      if (n == MBEDTLS_ERR_SSL_WANT_READ || n == MBEDTLS_ERR_SSL_WANT_WRITE) continue;
      break;                      /* 连接关闭或超时，按已收到的处理 */
    }
    total += n;
  }
  buf[total] = 0;

  if (total <= 0) {
    snprintf(err, ecap, "服务器没有返回任何数据");
    goto cleanup;
  }

  {
    char *bodyp = strstr(buf, "\r\n\r\n");
    int blen;
    if (!bodyp) {
      snprintf(err, ecap, "响应格式不对");
      goto cleanup;
    }
    if (strncmp(buf, "HTTP/1.", 7) == 0) status = atoi(buf + 9);
    bodyp += 4;

    if (strstr(buf, "Transfer-Encoding: chunked") ||
        strstr(buf, "transfer-encoding: chunked")) {
      int n = dechunk(bodyp, (int)(buf + total - bodyp));
      bodyp[n] = 0;
    }
    blen = total - (int)(bodyp - buf);
    if (raw_body) *raw_body = bodyp;
    if (raw_len) *raw_len = blen;
    if (out && cap > 0) {
      int n = blen < cap - 1 ? blen : cap - 1;
      memcpy(out, bodyp, (size_t)n);
      out[n] = 0;
    }
  }

cleanup:
  if (is_https) {
    if (tls_ready) mbedtls_ssl_close_notify(&ssl);
    mbedtls_ssl_free(&ssl);
    mbedtls_ssl_config_free(&conf);
    mbedtls_x509_crt_free(&ca);
    mbedtls_ctr_drbg_free(&drbg);
    mbedtls_entropy_free(&ent);
  }
  if (s != INVALID_SOCKET) closesocket(s);
  return status;
}

int tls_http_post(const char *url, const char *headers, const char *body,
                  char *out, int cap, char *err, int ecap) {
  return request_ex("POST", url, headers, body, out, cap, err, ecap, NULL, NULL);
}

int tls_download(const char *url, const char *headers, const char *path,
                 int *saved, char *err, int ecap) {
  char *bp = NULL;
  int bl = 0, st;
  FILE *f;

  if (saved) *saved = 0;
  st = request_ex("GET", url, headers ? headers : "", NULL, NULL, 0, err, ecap, &bp, &bl);
  if (st < 0) return -1;
  if (st != 200) return st;
  if (!bp || bl <= 0) { snprintf(err, ecap, "响应是空的"); return -1; }

  f = fopen(path, "wb");
  if (!f) { snprintf(err, ecap, "写不了 %s", path); return -1; }
  fwrite(bp, 1, (size_t)bl, f);
  fclose(f);
  if (saved) *saved = bl;
  return 200;
}

int tls_http_get(const char *url, char *out, int cap, char *err, int ecap) {
  return request_ex("GET", url, "", NULL, out, cap, err, ecap, NULL, NULL);
}

int tls_http_get_h(const char *url, const char *headers, char *out, int cap,
                   char *err, int ecap) {
  return request_ex("GET", url, headers ? headers : "", NULL, out, cap, err, ecap, NULL, NULL);
}
