/* net.h -- 通过 WinInet 调 OpenAI 兼容接口 */
#ifndef NET_H
#define NET_H

int  net_start(void *hwnd, unsigned msg, const char *gbk_prompt, int gen);
int  net_take(int gen, char *out, int cap, char *err, int errcap);
int  net_poll(int gen, char *out, int cap, char *err, int errcap);

#endif

/* TLS / 连通性自检 */
int  probe_start(void *hwnd, unsigned msg, const char *gbk_url);
int  probe_take(char *out, int cap);   /* 1 = 通了 */
