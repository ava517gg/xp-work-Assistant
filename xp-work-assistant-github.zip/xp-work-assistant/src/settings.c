/* settings.c -- 配置对话框 + ini 读写
 *
 * 用 Win32 原生控件拼出来的一个模态小窗口：三个输入框（Key / 接口地址 / 模型）。
 * 配置写到 exe 同目录的 xpwork.ini；写不进去就退到 %APPDATA%\xpwork.ini。
 */

#include <windows.h>
#include <wincrypt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "settings.h"

#define IDC_KEY   1001
#define IDC_BASE  1002
#define IDC_MODEL 1003
#define IDC_PRESET 1004
#define IDC_EFFORT 1005

#define DLG_W 392
#define DLG_H 292

static char g_key[256];
static char g_base[256];
static char g_model[64];
static char g_effort[8] = "high";
static int  g_tools;
static char g_note[2048];
static int  g_key_plain;   /* 加密失败时的降级标记 */
static char g_ini[MAX_PATH];

static int  s_done, s_ok;
static HWND s_dlg;
static HFONT s_font;
static HBRUSH s_bg;

/* ---------------------------------------------------------------- 路径 */

static void join_dir(char *out, int cap, const char *name) {
  char path[MAX_PATH];
  DWORD n = GetModuleFileNameA(NULL, path, MAX_PATH);
  char *p;
  if (!n) { snprintf(out, cap, "%s", name); return; }
  p = strrchr(path, '\\');
  if (p) p[1] = 0; else path[0] = 0;
  snprintf(out, cap, "%s%s", path, name);
}

static void trim(char *s) {
  char *p = s;
  int n;
  while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') p++;
  if (p != s) memmove(s, p, strlen(p) + 1);
  n = (int)strlen(s);
  while (n > 0 && (s[n-1] == ' ' || s[n-1] == '\t' || s[n-1] == '\r' || s[n-1] == '\n')) s[--n] = 0;
}

/* ---------------------------------------------------------------- 密钥加密
 * 用 Windows 自带的 DPAPI（CryptProtectData）加密，密文只有当前用户能解开。
 * XP 上就有，不需要额外运行库。ini 里存的是 base64。
 */

static int key_protect(const char *plain, char *out, int cap) {
  DATA_BLOB in, enc;
  DWORD n;
  BOOL ok;

  if (!plain || !*plain) { out[0] = 0; return 0; }
  in.pbData = (BYTE *)plain;
  in.cbData = (DWORD)strlen(plain);
  if (!CryptProtectData(&in, L"xp work Assistant", NULL, NULL, NULL,
                        CRYPTPROTECT_UI_FORBIDDEN, &enc))
    return 0;
  n = (DWORD)cap;
  ok = CryptBinaryToStringA(enc.pbData, enc.cbData,
                            CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, out, &n);
  LocalFree(enc.pbData);
  return ok ? 1 : 0;
}

static int key_unprotect(const char *b64, char *out, int cap) {
  DATA_BLOB enc, dec;
  DWORD n = 0;
  char *tmp;

  if (!b64 || !*b64) return 0;
  if (!CryptStringToBinaryA(b64, 0, CRYPT_STRING_BASE64, NULL, &n, NULL, NULL)) return 0;
  if (n == 0 || n > 8192) return 0;
  tmp = (char *)malloc(n);
  if (!tmp) return 0;
  enc.pbData = (BYTE *)tmp;
  enc.cbData = n;
  if (!CryptStringToBinaryA(b64, 0, CRYPT_STRING_BASE64, enc.pbData, &n, NULL, NULL)) {
    free(tmp);
    return 0;
  }
  if (!CryptUnprotectData(&enc, NULL, NULL, NULL, NULL, CRYPTPROTECT_UI_FORBIDDEN, &dec)) {
    free(tmp);
    return 0;
  }
  free(tmp);
  if ((int)dec.cbData >= cap) dec.cbData = (DWORD)cap - 1;
  memcpy(out, dec.pbData, dec.cbData);
  out[dec.cbData] = 0;
  LocalFree(dec.pbData);
  return 1;
}

static void strip_slash(char *s) {
  int n = (int)strlen(s);
  while (n > 0 && s[n-1] == '/') s[--n] = 0;
}

static int path_in_temp(const char *p) {
  char tmp[MAX_PATH];
  DWORD n = GetTempPathA(sizeof tmp, tmp);
  if (!n) return 0;
  if (_strnicmp(p, tmp, (int)strlen(tmp)) == 0) return 1;
  {
    char lo[MAX_PATH];
    int i;
    for (i = 0; i < (int)sizeof lo - 1 && p[i]; i++) {
      char c = p[i];
      lo[i] = (c >= 'A' && c <= 'Z') ? (char)(c - 'A' + 'a') : c;
    }
    lo[i] = 0;
    return strstr(lo, "\\temp\\") != NULL;
  }
}

void settings_init(void) {
  char alt[MAX_PATH], old[MAX_PATH], exe[MAX_PATH];
  DWORD en = GetModuleFileNameA(NULL, exe, MAX_PATH);
  char *appdata0 = getenv("APPDATA");

  /* 从压缩包里直接双击运行时，exe 在临时目录，配置必须放 %APPDATA%，
     否则每次解压到新目录，Key 就"丢"了 */
  if (en && path_in_temp(exe) && appdata0) {
    snprintf(g_ini, MAX_PATH, "%s\\xpwork.ini", appdata0);
    return;
  }

  join_dir(g_ini, MAX_PATH, "xpwork.ini");
  if (GetFileAttributesA(g_ini) == 0xFFFFFFFF) {
    /* 老版本叫 opencode.ini，搬过来 */
    join_dir(old, MAX_PATH, "opencode.ini");
    if (GetFileAttributesA(old) != 0xFFFFFFFF) {
      CopyFileA(old, g_ini, FALSE);
    }
  }
  if (GetFileAttributesA(g_ini) == 0xFFFFFFFF) {
    /* %APPDATA% 里可能有一份 */
    char *appdata = getenv("APPDATA");
    if (appdata) {
      snprintf(alt, sizeof alt, "%s\\xpwork.ini", appdata);
      if (GetFileAttributesA(alt) != 0xFFFFFFFF)
        snprintf(g_ini, MAX_PATH, "%s", alt);
    }
  }
}

void settings_load(void) {
  g_key[0] = g_base[0] = g_model[0] = 0;
  strcpy(g_effort, "high");
  {
    char enc[8192];
    g_key[0] = 0;
    GetPrivateProfileStringA("api", "key_enc", "", enc, sizeof enc, g_ini);
    if (enc[0]) {
      if (!key_unprotect(enc, g_key, sizeof g_key)) g_key[0] = 0;   /* 换了机器/用户就解不开 */
    }
    if (!g_key[0])
      GetPrivateProfileStringA("api", "key", "", g_key, sizeof g_key, g_ini);  /* 老的明文，稍后迁移 */
  }
  GetPrivateProfileStringA("api", "base", "", g_base, sizeof g_base, g_ini);
  GetPrivateProfileStringA("api", "model", "", g_model, sizeof g_model, g_ini);
  GetPrivateProfileStringA("api", "effort", "high", g_effort, sizeof g_effort, g_ini);
  g_tools = GetPrivateProfileIntA("api", "tools", 0, g_ini);
  {
    char raw[4096];
    int i, j = 0;
    GetPrivateProfileStringA("about", "note", "", raw, sizeof raw, g_ini);
    for (i = 0; raw[i] && j < (int)sizeof g_note - 2; i++) {
      if (raw[i] == '\\' && raw[i + 1] == 'n') { g_note[j++] = '\n'; i++; }
      else g_note[j++] = raw[i];
    }
    g_note[j] = 0;
  }
  trim(g_key);
  trim(g_base);
  trim(g_model);
  strip_slash(g_base);
}

static BOOL write_ini(void) {
  BOOL ok = TRUE;
  char enc[8192];

  g_key_plain = 0;
  if (g_key[0] && key_protect(g_key, enc, sizeof enc)) {
    ok = WritePrivateProfileStringA("api", "key_enc", enc, g_ini) && ok;
    WritePrivateProfileStringA("api", "key", NULL, g_ini);      /* 不留明文 */
  } else if (g_key[0]) {
    /* 加密不可用（极少见）：退回明文，并让界面提示 */
    g_key_plain = 1;
    WritePrivateProfileStringA("api", "key_enc", NULL, g_ini);
    ok = WritePrivateProfileStringA("api", "key", g_key, g_ini) && ok;
  } else if (!g_key[0]) {
    WritePrivateProfileStringA("api", "key_enc", NULL, g_ini);
    WritePrivateProfileStringA("api", "key", NULL, g_ini);
  }
  ok = WritePrivateProfileStringA("api", "base", g_base, g_ini) && ok;
  ok = WritePrivateProfileStringA("api", "model", g_model, g_ini) && ok;
  ok = WritePrivateProfileStringA("api", "effort", g_effort, g_ini) && ok;
  ok = WritePrivateProfileStringA("api", "tools", g_tools ? "1" : "0", g_ini) && ok;
  return ok;
}

int settings_save(void) {
  BOOL ok = write_ini();
  {
    /* 回读校验：加密存了但解不开（比如 DPAPI 不可用），退回明文 */
    char chk[8192], tmp[512];
    chk[0] = 0;
    GetPrivateProfileStringA("api", "key_enc", "", chk, sizeof chk, g_ini);
    if (chk[0] && g_key[0]) {
      tmp[0] = 0;
      if (!key_unprotect(chk, tmp, sizeof tmp) || strcmp(tmp, g_key) != 0) {
        WritePrivateProfileStringA("api", "key_enc", NULL, g_ini);
        WritePrivateProfileStringA("api", "key", g_key, g_ini);
        g_key_plain = 1;
        ok = TRUE;
      }
    }
  }

  if (!ok) {
    /* exe 目录不可写，换到 %APPDATA% */
    char *appdata = getenv("APPDATA");
    if (appdata) {
      char alt[MAX_PATH];
      snprintf(alt, sizeof alt, "%s\\xpwork.ini", appdata);
      if (alt[0] && strcmp(alt, g_ini) != 0) {
        snprintf(g_ini, MAX_PATH, "%s", alt);
        ok = write_ini();
      }
    }
  }
  return ok ? 1 : 0;
}

const char *settings_key(void) { return g_key; }
const char *settings_base(void) { return g_base; }
const char *settings_model(void) { return g_model; }

const char *settings_effort(void) {
  if (!strcmp(g_effort, "off") || !strcmp(g_effort, "low") ||
      !strcmp(g_effort, "high") || !strcmp(g_effort, "max")) return g_effort;
  return "high";
}

const char *settings_effort_label(void) {
  const char *e = settings_effort();
  if (!strcmp(e, "off")) return "关闭";
  if (!strcmp(e, "low")) return "低";
  if (!strcmp(e, "max")) return "最高";
  return "高";
}

void settings_set_key(const char *v) {
  strncpy(g_key, v ? v : "", sizeof g_key - 1);
  g_key[sizeof g_key - 1] = 0;
}

void settings_set_base(const char *v) {
  strncpy(g_base, v ? v : "", sizeof g_base - 1);
  g_base[sizeof g_base - 1] = 0;
}

void settings_set_model(const char *v) {
  strncpy(g_model, v ? v : "", sizeof g_model - 1);
  g_model[sizeof g_model - 1] = 0;
}

void settings_set_effort(const char *v) {
  if (!v) return;
  strncpy(g_effort, v, sizeof g_effort - 1);
  g_effort[sizeof g_effort - 1] = 0;
}
const char *settings_ini_path(void) { return g_ini; }

int settings_ready(void) { return g_key[0] && g_base[0] && g_model[0]; }

const char *settings_note(void) { return g_note; }
int settings_key_plain(void) { return g_key_plain; }

void settings_set_note(const char *v) {
  char esc[4096];
  int i, j = 0;
  for (i = 0; v && v[i] && j < (int)sizeof esc - 3; i++) {
    if (v[i] == '\n') { esc[j++] = '\\'; esc[j++] = 'n'; }
    else if (v[i] == '\r') { }
    else esc[j++] = v[i];
  }
  esc[j] = 0;
  snprintf(g_note, sizeof g_note, "%s", v ? v : "");
  WritePrivateProfileStringA("about", "note", esc, g_ini);
}

int settings_tools_enabled(void) { return g_tools; }
void settings_set_tools(int on) { g_tools = on ? 1 : 0; }

void settings_clear_key(void) {
  g_key[0] = 0;
  settings_save();
}

/* ---------------------------------------------------------------- 对话框 */

static int effort_index(void) {
  const char *e = settings_effort();
  if (!strcmp(e, "off")) return 0;
  if (!strcmp(e, "low")) return 1;
  if (!strcmp(e, "max")) return 3;
  return 2;
}

static const char *effort_value(int idx) {
  static const char *V[4] = { "off", "low", "high", "max" };
  if (idx < 0 || idx > 3) return "high";
  return V[idx];
}

static HWND mk_label(HWND p, const char *text, int x, int y, int w, int h) {
  HWND c = CreateWindowExA(0, "STATIC", text, WS_CHILD | WS_VISIBLE | SS_LEFT,
                           x, y, w, h, p, NULL, NULL, NULL);
  SendMessageA(c, WM_SETFONT, (WPARAM)s_font, TRUE);
  return c;
}

static HWND mk_edit(HWND p, int id, const char *text, int x, int y, int w, int h) {
  HWND c = CreateWindowExA(WS_EX_CLIENTEDGE, "EDIT", text,
                           WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL,
                           x, y, w, h, p, (HMENU)(INT_PTR)id, NULL, NULL);
  SendMessageA(c, WM_SETFONT, (WPARAM)s_font, TRUE);
  return c;
}

static LRESULT CALLBACK DlgProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  switch (m) {
    case WM_CREATE:
      mk_label(h, "API Key：", 14, 16, 70, 18);
      mk_edit(h, IDC_KEY, g_key, 88, 13, 288, 20);

      mk_label(h, "接口地址：", 14, 52, 70, 18);
      mk_edit(h, IDC_BASE, g_base, 88, 49, 288, 20);

      mk_label(h, "模型：", 14, 88, 70, 18);
      mk_edit(h, IDC_MODEL, g_model, 88, 85, 288, 20);

      mk_label(h, "推理强度：", 14, 124, 70, 18);
      {
        HWND cb = CreateWindowExA(0, "COMBOBOX", "",
                                  WS_CHILD | WS_VISIBLE | WS_TABSTOP |
                                  CBS_DROPDOWNLIST | WS_VSCROLL,
                                  88, 121, 150, 120, h, (HMENU)IDC_EFFORT, NULL, NULL);
        SendMessageA(cb, WM_SETFONT, (WPARAM)s_font, TRUE);
        SendMessageA(cb, CB_ADDSTRING, 0, (LPARAM)"关闭思考（最快）");
        SendMessageA(cb, CB_ADDSTRING, 0, (LPARAM)"低");
        SendMessageA(cb, CB_ADDSTRING, 0, (LPARAM)"高（默认）");
        SendMessageA(cb, CB_ADDSTRING, 0, (LPARAM)"最高（最慢最贵）");
        SendMessageA(cb, CB_SETCURSEL, (WPARAM)effort_index(), 0);
      }
      mk_label(h, "DeepSeek 官方：https://api.deepseek.com/v1，模型 deepseek-flash", 14, 156, 366, 16);
      mk_label(h, "地址后面会自动接 /chat/completions；填完点确定即可生效。", 14, 174, 366, 16);

      CreateWindowExA(0, "BUTTON", "填入 DeepSeek 官方",
                      WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON,
                      14, 214, 150, 26, h, (HMENU)IDC_PRESET, NULL, NULL);
      CreateWindowExA(0, "BUTTON", "确定",
                      WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_DEFPUSHBUTTON,
                      190, 214, 88, 26, h, (HMENU)IDOK, NULL, NULL);
      CreateWindowExA(0, "BUTTON", "取消",
                      WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                      286, 214, 88, 26, h, (HMENU)IDCANCEL, NULL, NULL);
      {
        HWND a = GetDlgItem(h, IDOK);
        HWND b = GetDlgItem(h, IDCANCEL);
        HWND c = GetDlgItem(h, IDC_PRESET);
        SendMessageA(a, WM_SETFONT, (WPARAM)s_font, TRUE);
        SendMessageA(b, WM_SETFONT, (WPARAM)s_font, TRUE);
        SendMessageA(c, WM_SETFONT, (WPARAM)s_font, TRUE);
      }
      return 0;

    case WM_CTLCOLORSTATIC:
      SetBkColor((HDC)wp, GetSysColor(COLOR_BTNFACE));
      return (LRESULT)s_bg;

    case WM_COMMAND:
      if (LOWORD(wp) == IDOK) {
        GetDlgItemTextA(h, IDC_KEY, g_key, sizeof g_key);
        GetDlgItemTextA(h, IDC_BASE, g_base, sizeof g_base);
        GetDlgItemTextA(h, IDC_MODEL, g_model, sizeof g_model);
        {
          int sel = (int)SendDlgItemMessageA(h, IDC_EFFORT, CB_GETCURSEL, 0, 0);
          settings_set_effort(effort_value(sel));
        }
        s_ok = 1;
        DestroyWindow(h);
      } else if (LOWORD(wp) == IDC_PRESET) {
        SetDlgItemTextA(h, IDC_BASE, "https://api.deepseek.com/v1");
        SetDlgItemTextA(h, IDC_MODEL, "deepseek-flash");
        SetFocus(GetDlgItem(h, IDC_KEY));
      } else if (LOWORD(wp) == IDCANCEL) {
        s_ok = 0;
        DestroyWindow(h);
      }
      return 0;

    case WM_CLOSE:
      s_ok = 0;
      DestroyWindow(h);
      return 0;

    case WM_DESTROY:
      s_done = 1;
      return 0;
  }
  return DefWindowProc(h, m, wp, lp);
}

int settings_dialog(void *parent) {
  HWND owner = (HWND)parent;
  WNDCLASSA wc;
  RECT pr, dr;
  MSG msg;
  int w = DLG_W, h = DLG_H;

  memset(&wc, 0, sizeof wc);
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = DlgProc;
  wc.hInstance = GetModuleHandleA(NULL);
  wc.hCursor = LoadCursorA(NULL, IDC_ARROW);
  wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
  wc.lpszClassName = "OcSettings";
  RegisterClassA(&wc);

  s_font = CreateFontA(-12, 0, 0, 0, FW_NORMAL, 0, 0, 0, GB2312_CHARSET,
                       OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                       DEFAULT_PITCH | FF_SWISS, "SimSun");
  s_bg = GetSysColorBrush(COLOR_BTNFACE);

  GetWindowRect(owner, &pr);
  dr.left = pr.left + ((pr.right - pr.left) - w) / 2;
  dr.top = pr.top + ((pr.bottom - pr.top) - h) / 2;

  s_done = 0;
  s_ok = 0;

  s_dlg = CreateWindowExA(WS_EX_DLGMODALFRAME, "OcSettings", "xp work Assistant 设置",
                          WS_POPUP | WS_CAPTION | WS_SYSMENU,
                          dr.left, dr.top, w, h, owner, NULL, wc.hInstance, NULL);
  if (!s_dlg) return 0;

  EnableWindow(owner, FALSE);
  ShowWindow(s_dlg, SW_SHOW);
  SetFocus(GetDlgItem(s_dlg, IDC_KEY));

  while (!s_done && GetMessage(&msg, NULL, 0, 0) > 0) {
    if (!IsDialogMessage(s_dlg, &msg)) {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  }

  EnableWindow(owner, TRUE);
  SetActiveWindow(owner);
  DestroyWindow(s_dlg);
  DeleteObject(s_font);

  if (s_ok) {
    settings_save();
    return 1;
  }
  return 0;
}

/* ---------------------------------------------------------------- 通用输入框 */

#define PD_ID_EDIT 3001
static HWND pd_dlg, pd_edit;
static char *pd_buf;
static int   pd_cap, pd_ml, pd_ok, pd_done, pd_label_h;

static LRESULT CALLBACK PromptProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  switch (m) {
    case WM_CREATE: {
      int y = 12;
      const char *txt = (const char *)((CREATESTRUCT *)lp)->lpCreateParams;
      CreateWindowExA(0, "STATIC", txt ? txt : "",
                      WS_CHILD | WS_VISIBLE, 14, y, 442, pd_label_h,
                      h, NULL, NULL, NULL);
      y += pd_label_h + 8;
      pd_edit = CreateWindowExA(WS_EX_CLIENTEDGE, "EDIT",
                                pd_buf,
                                WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL |
                                (pd_ml ? (ES_MULTILINE | ES_AUTOVSCROLL | ES_WANTRETURN)
                                       : ES_AUTOHSCROLL),
                                14, y, 442, pd_ml ? 110 : 22, h,
                                (HMENU)PD_ID_EDIT, NULL, NULL);
      if (s_font) SendMessageA(pd_edit, WM_SETFONT, (WPARAM)s_font, TRUE);
      y += (pd_ml ? 110 : 22) + 12;
      {
        HWND b1 = CreateWindowExA(0, "BUTTON", "确定",
                                  WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_DEFPUSHBUTTON,
                                  290, y, 80, 26, h, (HMENU)IDOK, NULL, NULL);
        HWND b2 = CreateWindowExA(0, "BUTTON", "取消",
                                  WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                                  376, y, 80, 26, h, (HMENU)IDCANCEL, NULL, NULL);
        if (s_font) {
          SendMessageA(b1, WM_SETFONT, (WPARAM)s_font, TRUE);
          SendMessageA(b2, WM_SETFONT, (WPARAM)s_font, TRUE);
        }
      }
      return 0;
    }
    case WM_COMMAND:
      if (LOWORD(wp) == IDOK) {
        int n = GetWindowTextA(pd_edit, pd_buf, pd_cap);
        if (n < 0) n = 0;
        pd_buf[n] = 0;
        pd_ok = 1;
        pd_done = 1;
        DestroyWindow(h);
        return 0;
      }
      if (LOWORD(wp) == IDCANCEL) { pd_done = 1; DestroyWindow(h); return 0; }
      return 0;
    case WM_CLOSE: pd_done = 1; DestroyWindow(h); return 0;
  }
  return DefWindowProcA(h, m, wp, lp);
}

int oc_prompt(void *owner, const char *caption, const char *text,
              char *buf, int cap, int multiline) {
  WNDCLASSA wc;
  MSG msg;
  RECT pr, dr;
  int w = 470, h;
  HWND ow = (HWND)owner;
  int lines = 1, li;

  for (li = 0; text && text[li]; li++) if (text[li] == '\n') lines++;
  pd_label_h = lines * 16 + 14;
  if (multiline) h = pd_label_h + 26 + 110 + 12 + 34 + 18;
  else h = pd_label_h + 26 + 22 + 12 + 34 + 12;

  pd_buf = buf;
  pd_cap = cap;
  pd_ml = multiline;
  pd_ok = 0;
  pd_done = 0;

  memset(&wc, 0, sizeof wc);
  wc.lpfnWndProc = PromptProc;
  wc.hInstance = GetModuleHandleA(NULL);
  wc.hCursor = LoadCursorA(NULL, IDC_ARROW);
  wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
  wc.lpszClassName = "OcPrompt";
  RegisterClassA(&wc);

  if (!s_font)
    s_font = CreateFontA(-12, 0, 0, 0, FW_NORMAL, 0, 0, 0, GB2312_CHARSET,
                         OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                         DEFAULT_PITCH | FF_SWISS, "SimSun");

  if (ow) { GetWindowRect(ow, &pr); }
  else { pr.left = 200; pr.top = 200; pr.right = 1100; pr.bottom = 800; }
  dr.left = pr.left + ((pr.right - pr.left) - w) / 2;
  dr.top = pr.top + ((pr.bottom - pr.top) - h) / 2;

  pd_dlg = CreateWindowExA(WS_EX_DLGMODALFRAME, "OcPrompt", caption,
                           WS_POPUP | WS_CAPTION | WS_SYSMENU,
                           dr.left, dr.top, w, h, ow, NULL, wc.hInstance, (LPVOID)text);
  if (!pd_dlg) return 0;

  if (ow) EnableWindow(ow, FALSE);
  ShowWindow(pd_dlg, SW_SHOW);
  SetFocus(pd_edit);
  SendMessageA(pd_edit, EM_SETSEL, 0, -1);

  while (!pd_done && GetMessage(&msg, NULL, 0, 0) > 0) {
    if (!IsDialogMessage(pd_dlg, &msg)) {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  }
  if (ow) { EnableWindow(ow, TRUE); SetActiveWindow(ow); }
  return pd_ok;
}

/* ---------------------------------------------------------------- 今日消耗 */

/* DeepSeek 大致单价：输入 2 元/百万 token，输出 8 元/百万 token（估算用） */
#define PRICE_IN   0.000002
#define PRICE_OUT  0.000008

static double g_cost;
static long   g_cost_tok;
static char   g_cost_date[16];

static void today_str(char *out, int cap) {
  SYSTEMTIME st;
  GetLocalTime(&st);
  snprintf(out, cap, "%04d-%02d-%02d", st.wYear, st.wMonth, st.wDay);
}

void cost_init(void) {
  char d[16], buf[64];
  today_str(d, sizeof d);
  GetPrivateProfileStringA("cost", "date", "", g_cost_date, sizeof g_cost_date, g_ini);
  if (strcmp(g_cost_date, d) != 0) {
    snprintf(g_cost_date, sizeof g_cost_date, "%s", d);
    g_cost = 0;
    g_cost_tok = 0;
    WritePrivateProfileStringA("cost", "date", g_cost_date, g_ini);
    WritePrivateProfileStringA("cost", "yuan", "0", g_ini);
    WritePrivateProfileStringA("cost", "tokens", "0", g_ini);
  } else {
    GetPrivateProfileStringA("cost", "yuan", "0", buf, sizeof buf, g_ini);
    g_cost = atof(buf);
    GetPrivateProfileStringA("cost", "tokens", "0", buf, sizeof buf, g_ini);
    g_cost_tok = atol(buf);
  }
}

void cost_add(long in_tok, long out_tok) {
  char buf[64];
  g_cost += (double)in_tok * PRICE_IN + (double)out_tok * PRICE_OUT;
  g_cost_tok += in_tok + out_tok;
  snprintf(buf, sizeof buf, "%.6f", g_cost);
  WritePrivateProfileStringA("cost", "yuan", buf, g_ini);
  snprintf(buf, sizeof buf, "%ld", g_cost_tok);
  WritePrivateProfileStringA("cost", "tokens", buf, g_ini);
}

double cost_today(void) { return g_cost; }
long   cost_tokens_today(void) { return g_cost_tok; }
