/* text.h -- 中英混排的字符宽度
 *
 * Windows 上是 GBK（系统代码页 936），Linux 预览构建是 UTF-8。
 * 两种编码都要能算出「占几列」：ASCII 1 列，汉字 2 列。
 */
#ifndef OC_TEXT_H
#define OC_TEXT_H

/* 取 i 处字符的字节长度 *len 和显示宽度 *wid（列） */
static void oc_char(const char *s, int i, int n, int *len, int *wid) {
  unsigned char c;
  if (i >= n) { *len = 0; *wid = 0; return; }
  c = (unsigned char)s[i];

#if defined(_WIN32)
  if (c >= 0x81 && i + 1 < n) { *len = 2; *wid = 2; }
  else { *len = 1; *wid = 1; }
#else
  if (c < 0x80) { *len = 1; *wid = 1; }
  else if ((c & 0xE0) == 0xC0) { *len = 2; *wid = 1; }
  else if ((c & 0xF0) == 0xE0) { *len = 3; *wid = 2; }
  else if ((c & 0xF8) == 0xF0) { *len = 4; *wid = 2; }
  else { *len = 1; *wid = 1; }
  if (i + *len > n) *len = n - i;
#endif
  if (i + *len > n) *len = n - i;
}

#endif
