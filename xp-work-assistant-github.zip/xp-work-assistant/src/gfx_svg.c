/* gfx_svg.c -- 把同一批绘图调用记录成 SVG
 * 只用于在没有 Windows 的机器上预览界面（配合 headless 构建）。
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "gfx.h"
#include "text.h"

static char *out;
static size_t len, cap;

static int g_w, g_h;

static void put(const char *s) {
  size_t n = strlen(s);
  if (len + n + 1 >= cap) return;
  memcpy(out + len, s, n);
  len += n;
  out[len] = 0;
}

static void putf(const char *fmt, ...) {
  char tmp[1024];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(tmp, sizeof tmp, fmt, ap);
  va_end(ap);
  put(tmp);
}

static void put_escaped(const char *s, int n) {
  int i;
  char buf[8];
  for (i = 0; i < n; i++) {
    unsigned char c = (unsigned char)s[i];
    if (c == '&') put("&amp;");
    else if (c == '<') put("&lt;");
    else if (c == '>') put("&gt;");
    else if (c < 32) {
      snprintf(buf, sizeof buf, "&#%d;", c);
      put(buf);
    } else {
      buf[0] = (char)c;
      buf[1] = 0;
      put(buf);
    }
  }
}

void gfx_set_target(void *ctx) { (void)ctx; }

void gfx_begin(int w, int h) {
  if (!out) {
    cap = 4 * 1024 * 1024;
    out = (char *)malloc(cap);
  }
  len = 0;
  out[0] = 0;
  g_w = w; g_h = h;
  putf("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"%d\" height=\"%d\" "
       "viewBox=\"0 0 %d %d\">", w, h, w, h);
  putf("<rect width=\"%d\" height=\"%d\" fill=\"#ffffff\"/>", w, h);
}

void gfx_end(void) {
  const char *path = getenv("GFX_OUT");
  FILE *f;
  put("</svg>\n");
  if (!path) path = "screen.svg";
  f = fopen(path, "wb");
  if (f) { fwrite(out, 1, len, f); fclose(f); }
}

int gfx_cell_w(int font) { (void)font; return 7; }
int gfx_line_h(int font) { (void)font; return 18; }

void gfx_fill(int x, int y, int w, int h, Color c) {
  putf("<rect x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" fill=\"#%02x%02x%02x\"/>",
       x, y, w, h, c.r, c.g, c.b);
}

void gfx_frame(int x, int y, int w, int h, Color c) {
  putf("<rect x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" fill=\"none\" stroke=\"#%02x%02x%02x\"/>",
       x, y, w, h, c.r, c.g, c.b);
}

void gfx_text(int x, int y, const char *s, int len, Color c, int font, int clip_r) {
  int cw = gfx_cell_w(font), lh = gfx_line_h(font);
  int base = y + (lh + 10) / 2;
  const char *ff_ui = "Noto Sans CJK SC, Microsoft YaHei, DejaVu Sans, sans-serif";
  const char *ff_mono = "DejaVu Sans Mono, Noto Sans CJK SC, monospace";
  int fs_ui = 12, fs_mono = 12;
  int i, col;

  if (len <= 0) return;

  if (font == FONT_UI) {
    if (x + len * cw > clip_r + 40) len = (clip_r - x) / cw;
    if (len <= 0) return;
    putf("<g font-family=\"%s\" font-size=\"%d\" fill=\"#%02x%02x%02x\">", ff_ui, fs_ui, c.r, c.g, c.b);
    putf("<text x=\"%d\" y=\"%d\">", x, base);
    put_escaped(s, len);
    put("</text></g>");
    return;
  }

  putf("<g font-family=\"%s\" font-size=\"%d\" fill=\"#%02x%02x%02x\">", ff_mono, fs_mono, c.r, c.g, c.b);
  col = 0;
  i = 0;
  while (i < len) {
    int clen, cwid;
    oc_char(s, i, len, &clen, &cwid);
    if (!clen) break;
    if (x + (col + cwid) * cw > clip_r) break;
    if (s[i] != ' ') {
      int fs = (cwid == 2) ? (fs_mono * 2 * cw / 12) : fs_mono;
      putf("<text x=\"%d\" y=\"%d\" font-size=\"%d\">", x + col * cw, base, fs);
      put_escaped(s + i, clen);
      put("</text>");
    }
    col += cwid;
    i += clen;
  }
  put("</g>");
}

int gfx_image(const char *path, int x, int y, int w, int h) {
  (void)path;
  gfx_frame(x, y, w, h, RGB_(60, 74, 90));
  return 0;
}
