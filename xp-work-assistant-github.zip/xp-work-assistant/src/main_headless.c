/* main_headless.c -- 不开窗口，直接跑界面并导出 SVG（用于预览） */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gfx.h"
#include "ui.h"

int oc_online(void) { return 0; }
int oc_net_send(const char *text, int gen) { (void)text; (void)gen; return 0; }
int oc_net_take(int gen, char *out, int cap, char *err, int errcap) {
  (void)gen; (void)cap; (void)errcap;
  if (out) out[0] = 0;
  if (err) err[0] = 0;
  return 0;
}

const char *oc_model_name(void) { return "demo"; }
const char *oc_effort_label(void) { return "高"; }
int oc_probe_send(void) { return 0; }
int oc_agent_start(const char *t) { (void)t; return 0; }
void oc_agent_abort(void) {}
void oc_agent_reset(void) {}
void oc_layout_changed(void) {}
unsigned long oc_ticks(void) { return 1000UL * 60 * 60 * 24 * 12; }
int oc_today_cost(char *out, int cap) { (void)cap; if (out) snprintf(out, 64, "今日 ￥0.00"); return 1; }
int oc_probe_take(char *out, int cap) { (void)cap; if (out) out[0] = 0; return 0; }

int main(void) {
  const char *send = getenv("OC_SEND");
  const char *input = getenv("OC_INPUT");
  int ticks = getenv("OC_TICKS") ? atoi(getenv("OC_TICKS")) : 300;
  int w = getenv("OC_W") ? atoi(getenv("OC_W")) : 760;
  int h = getenv("OC_H") ? atoi(getenv("OC_H")) : 560;
  int i;

  ui_init();
  ui_resize(w, h);

  if (send && *send) ui_send(send);

  for (i = 0; i < ticks; i++) ui_tick();

  {
    const char *att = getenv("OC_ATTACH");   /* 形如 app.js:2134 */
    if (att && *att) {
      char name[128];
      const char *c = strchr(att, ':');
      long size = 0;
      size_t n = c ? (size_t)(c - att) : strlen(att);
      if (n >= sizeof name) n = sizeof name - 1;
      memcpy(name, att, n);
      name[n] = 0;
      if (c) size = atol(c + 1);
      ui_attach_add(name, size, "// preview", 0);
    }
  }

  ui_scroll_to_bottom();
  if (input) ui_preview_input(input, (int)strlen(input));
  else ui_preview_input("", 0);

  gfx_begin(w, h);
  ui_paint();
  gfx_end();
  return 0;
}
