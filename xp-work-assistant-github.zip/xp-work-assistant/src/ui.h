/* ui.h -- 界面层（平台无关） */
#ifndef UI_H
#define UI_H

extern int g_sidebar_w;
#define SIDEBAR_W g_sidebar_w
#define SIDEBAR_WIDE 372
#define SIDEBAR_NARROW 176
#define STATUS_H  24
#define INPUT_H   112
#define CHAT_PAD  14
#define LH_MONO   18

void ui_init(void);
void ui_resize(int w, int h);
void ui_paint(void);
void ui_tick(void);
int  ui_busy(void);
int  ui_typing(void);   /* 正在逐字输出 */

void ui_send(const char *text);        /* 提交一条输入 */
void ui_scroll_by(int lines);
void ui_scroll_to_bottom(void);
void ui_abort(void);
void ui_reset(void);
void ui_delete_last_exchange(void);   /* 删掉最后一轮问答 */
void ui_delete_session(int idx);      /* 删掉一个会话 */
void ui_new_session(void);
int  ui_current_session(void);
int  ui_menu_session(void);           /* 刚点了哪一行的 "…" */
int  ui_session_fav(int idx);
int  ui_session_archived(int idx);
const char *ui_session_title(int idx);
void ui_rename_session(int idx, const char *title);
void ui_toggle_fav(int idx);
void ui_toggle_archived(int idx);
void ui_toggle_archived_view(void);
void ui_set_model(int idx);
int  ui_model(void);
int  ui_transcript(char *buf, int cap);   /* 纯文本导出，返回长度 */

/* 主窗口用来摆放输入框的位置（客户区坐标） */
void ui_input_rect(int *x, int *y, int *w, int *h);
void ui_send_rect(int *x, int *y, int *w, int *h);

/* 鼠标返回值 */
#define UI_CLICK_NONE   0
#define UI_CLICK_SEND   1
#define UI_CLICK_ATTACH 2
#define UI_CLICK_EFFORT 3
#define UI_CLICK_BALANCE 4
#define UI_CLICK_SESSION_MENU 5
#define UI_CLICK_ARCHIVED_TOGGLE 6
#define UI_CLICK_DELETE_SESSION 7
#define UI_CLICK_PREVIEW_LINE 8
#define UI_CLICK_PREVIEW_BTN 9

int  ui_click(int x, int y);

/* 输入区上方那排按钮的位置（主窗口用来弹菜单） */
void ui_effort_rect(int *x, int *y, int *w, int *h);
void ui_balance_rect(int *x, int *y, int *w, int *h);

/* 附件 */
void ui_attach_add(const char *name, long size, const char *gbk_text, int is_image);
int  ui_attach_count(void);
void ui_attach_clear(void);

/* headless 预览：画输入框里的文字 + 光标 */
void ui_preview_input(const char *text, int caret);

/* 在线模式 */
void ui_notice(const char *text);
void ui_probe_done(void);
void ui_tool_event(int kind, const char *text);
void ui_agent_done(void);
void ui_balance_set(const char *text);
void ui_preview_set(const char *name, const char *text, int is_image, int iw, int ih);
void ui_preview_close(void);
void ui_preview_toggle(void);
int  ui_preview_open(void);
int  ui_sidebar_w(void);
int  ui_divider_hit(int x, int y);
void ui_set_sidebar_w(int w);
int  ui_animating(void);
void ui_preview_sel_begin(int y);
void ui_preview_sel_update(int y);
int  ui_preview_sel(int *a, int *b);   /* 返回是否有选中 */
int  ui_preview_selected_text(char *out, int cap);
int  ui_preview_hit(int x, int y);
int  ui_preview_line_click(int y);
int  ui_preview_pick_line(void);
const char *ui_preview_name(void);
void ui_net_done(int gen);

/* 下面三个由平台层实现 */
int  oc_online(void);
int  oc_net_send(const char *text, int gen);
int  oc_net_take(int gen, char *out, int cap, char *err, int errcap);
const char *oc_model_name(void);
const char *oc_effort_label(void);
int  oc_probe_send(void);
int  oc_probe_take(char *out, int cap);
int  oc_agent_start(const char *text);
void oc_agent_abort(void);
void oc_agent_reset(void);
void oc_layout_changed(void);   /* 侧边栏宽度变了，重新摆子窗口 */
unsigned long oc_ticks(void);   /* 毫秒，用于显示“几分钟前” */
int oc_today_cost(char *out, int cap);   /* 今日消耗文案 */

#endif
