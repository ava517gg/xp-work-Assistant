/* imgview.c -- 用 GDI+ 的 flat API 在侧边栏里画图片（XP 自带 gdiplus.dll）
 *
 * 项目是纯 C，而 GDI+ 的头文件只有 C++ 版，所以这里自己声明函数原型，
 * 直接链接 gdiplus.dll 的导出表。
 */

#include <windows.h>

typedef unsigned int UINT32;

typedef struct {
  UINT32 GdiplusVersion;
  void  *DebugEventCallback;
  BOOL   SuppressBackgroundThread;
  BOOL   SuppressExternalCodecs;
} GpStartupInput;

extern int  WINAPI GdiplusStartup(ULONG_PTR *token, const void *input, void *output);
extern void WINAPI GdiplusShutdown(ULONG_PTR token);
extern int  WINAPI GdipLoadImageFromFile(const WCHAR *name, void **image);
extern int  WINAPI GdipGetImageWidth(void *image, UINT *w);
extern int  WINAPI GdipGetImageHeight(void *image, UINT *h);
extern int  WINAPI GdipCreateFromHDC(HDC hdc, void **graphics);
extern int  WINAPI GdipDeleteGraphics(void *graphics);
extern int  WINAPI GdipDrawImageRectI(void *graphics, void *image, int x, int y, int w, int h);
extern int  WINAPI GdipSetInterpolationMode(void *graphics, int mode);
extern int  WINAPI GdipDisposeImage(void *image);

static ULONG_PTR g_token;
static int g_ready = -1;

static int ensure_gdiplus(void) {
  if (g_ready >= 0) return g_ready;
  {
    GpStartupInput in;
    in.GdiplusVersion = 1;
    in.DebugEventCallback = NULL;
    in.SuppressBackgroundThread = FALSE;
    in.SuppressExternalCodecs = FALSE;
    g_ready = (GdiplusStartup(&g_token, &in, NULL) == 0) ? 1 : 0;
  }
  return g_ready;
}

static void to_wide(const char *gbk, WCHAR *out, int cap) {
  MultiByteToWideChar(CP_ACP, 0, gbk, -1, out, cap);
}

/* 把图片等比缩放后画进 (x,y,w,h)。返回 1 表示画成功 */
int oc_draw_image(HDC hdc, const char *path, int x, int y, int w, int h) {
  WCHAR wp[MAX_PATH * 2];
  void *img = NULL, *g = NULL;
  UINT iw = 0, ih = 0;
  int dw, dh, dx, dy;

  if (!ensure_gdiplus() || !hdc || !path || !*path) return 0;
  to_wide(path, wp, MAX_PATH * 2);
  if (GdipLoadImageFromFile(wp, &img) != 0 || !img) return 0;
  GdipGetImageWidth(img, &iw);
  GdipGetImageHeight(img, &ih);
  if (!iw || !ih) { GdipDisposeImage(img); return 0; }

  dw = w;
  dh = (int)((double)ih * (double)w / (double)iw);
  if (dh > h) { dh = h; dw = (int)((double)iw * (double)h / (double)ih); }
  if (dw < 1) dw = 1;
  if (dh < 1) dh = 1;
  dx = x + (w - dw) / 2;
  dy = y + (h - dh) / 2;

  if (GdipCreateFromHDC(hdc, &g) == 0 && g) {
    GdipSetInterpolationMode(g, 7);      /* HighQualityBicubic */
    GdipDrawImageRectI(g, img, dx, dy, dw, dh);
    GdipDeleteGraphics(g);
  }
  GdipDisposeImage(img);
  return 1;
}

/* 问一下图片尺寸（预览标题用） */
int oc_image_size(const char *path, int *w, int *h) {
  WCHAR wp[MAX_PATH * 2];
  void *img = NULL;
  UINT iw = 0, ih = 0;

  if (w) *w = 0;
  if (h) *h = 0;
  if (!ensure_gdiplus() || !path || !*path) return 0;
  to_wide(path, wp, MAX_PATH * 2);
  if (GdipLoadImageFromFile(wp, &img) != 0 || !img) return 0;
  GdipGetImageWidth(img, &iw);
  GdipGetImageHeight(img, &ih);
  GdipDisposeImage(img);
  if (w) *w = (int)iw;
  if (h) *h = (int)ih;
  return (iw && ih) ? 1 : 0;
}
