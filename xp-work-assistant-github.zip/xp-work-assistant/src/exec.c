/* exec.c -- 用 cmd.exe 执行命令，带超时和输出捕获
 *
 * Windows XP 上没有 bash/PowerShell 可用，所以统一走 cmd.exe /c。
 * stdout 和 stderr 合并到同一个管道，免得交错乱序。
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "exec.h"

#define READ_CHUNK 2048


static int run_program(const char *cmdline, char *out, int cap, int *exit_code, int timeout_ms) {
  SECURITY_ATTRIBUTES sa;
  HANDLE rd = NULL, wr = NULL;
  STARTUPINFOA si;
  PROCESS_INFORMATION pi;
  char line[2048];
  DWORD total = 0, waited = 0;
  int ok = 0;

  if (exit_code) *exit_code = -1;
  if (out && cap > 0) out[0] = 0;
  if (!cmdline || !*cmdline) return 0;

  memset(&sa, 0, sizeof sa);
  sa.nLength = sizeof sa;
  sa.bInheritHandle = TRUE;

  if (!CreatePipe(&rd, &wr, &sa, 64 * 1024)) return 0;
  SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);

  memset(&si, 0, sizeof si);
  si.cb = sizeof si;
  si.dwFlags = STARTF_USESTDHANDLES;
  si.hStdInput = NULL;
  si.hStdOutput = wr;
  si.hStdError = wr;

  snprintf(line, sizeof line, "%s", cmdline);

  memset(&pi, 0, sizeof pi);
  if (!CreateProcessA(NULL, line, NULL, NULL, TRUE, CREATE_NO_WINDOW,
                      NULL, NULL, &si, &pi)) {
    {
      DWORD e = GetLastError();
      if (out && cap > 0)
        snprintf(out, cap, "error: 启动进程失败（Win32 错误 %lu）", (unsigned long)e);
      CloseHandle(rd);
      CloseHandle(wr);
      return 0;
    }
  }

  CloseHandle(wr);          /* 父进程不留写端，否则读不到 EOF */

  for (;;) {
    char buf[READ_CHUNK];
    DWORD avail = 0, got = 0;

    if (!PeekNamedPipe(rd, NULL, 0, NULL, &avail, NULL)) break;

    if (avail > 0) {
      DWORD want = avail < sizeof buf ? avail : (DWORD)sizeof buf;
      if (!ReadFile(rd, buf, want, &got, NULL) || got == 0) break;
      if (total < (DWORD)cap - 1) {
        DWORD room = (DWORD)cap - 1 - total;
        DWORD n = got < room ? got : room;
        memcpy(out + total, buf, n);
        total += n;
        out[total] = 0;
      }
      ok = 1;
      continue;
    }

    if (WaitForSingleObject(pi.hProcess, 40) == WAIT_OBJECT_0) {
      /* 进程退了，把管道里剩下的读干净 */
      for (;;) {
        DWORD more = 0;
        if (!PeekNamedPipe(rd, NULL, 0, NULL, &more, NULL) || more == 0) break;
        if (!ReadFile(rd, buf, sizeof buf, &got, NULL) || got == 0) break;
        if (total < (DWORD)cap - 1) {
          DWORD room = (DWORD)cap - 1 - total;
          DWORD n = got < room ? got : room;
          memcpy(out + total, buf, n);
          total += n;
          out[total] = 0;
        }
        ok = 1;
      }
      break;
    }

    waited += 40;
    if (timeout_ms > 0 && waited > (DWORD)timeout_ms) {
      TerminateProcess(pi.hProcess, 1);
      if (out && total < (DWORD)cap - 1) {
        const char *t = "\r\n[timeout]";
        DWORD n = (DWORD)strlen(t);
        if (total + n < (DWORD)cap) {
          memcpy(out + total, t, n);
          total += n;
          out[total] = 0;
        }
      }
      break;
    }
  }

  if (exit_code) {
    DWORD code = 0;
    if (GetExitCodeProcess(pi.hProcess, &code)) *exit_code = (int)code;
  }

  CloseHandle(rd);
  CloseHandle(pi.hProcess);
  CloseHandle(pi.hThread);
  return ok;
}

/* 命令写成临时 .bat 再执行：
 *  - 不受命令行 8191 字符上限影响
 *  - 不用和 CreateProcess 的引号规则搏斗（"路径 带空格" 常见坑）
 */
int exec_cmd(const char *cmd, char *out, int cap, int *exit_code, int timeout_ms) {
  static unsigned long seq;
  char tmp[MAX_PATH], bat[MAX_PATH], line[MAX_PATH * 2];
  FILE *f;

  if (exit_code) *exit_code = -1;
  if (out && cap > 0) out[0] = 0;
  if (!cmd || !*cmd) return 0;

  if (!GetTempPathA(sizeof tmp, tmp)) return 0;
  snprintf(bat, sizeof bat, "%sxpwork_cmd_%lu_%lu.bat", tmp,
           (unsigned long)GetCurrentProcessId(), ++seq);

  f = fopen(bat, "wb");
  if (!f) {
    snprintf(out, cap, "error: 写不了临时脚本 %s", bat);
    return 0;
  }
  fputs("@echo off\r\n", f);
  fwrite(cmd, 1, strlen(cmd), f);
  fputc('\r', f);
  fputc('\n', f);
  fclose(f);

  snprintf(line, sizeof line, "cmd.exe /c \"%s\"", bat);
  {
    int r = run_program(line, out, cap, exit_code, timeout_ms);
    DWORD e = GetLastError();
    DeleteFileA(bat);
    if (!r && (!out || !out[0])) {
      if (out) snprintf(out, cap, "error: 无法启动 cmd.exe（Win32 错误 %lu）", (unsigned long)e);
    }
    return r;
  }
}

int exec_have_powershell(char *path, int cap) {
  return SearchPathA(NULL, "powershell.exe", NULL, (DWORD)cap, path, NULL) != 0;
}

int exec_ps(const char *cmd, char *out, int cap, int *exit_code, int timeout_ms) {
  char ps[MAX_PATH], tmp[MAX_PATH], tmp2[MAX_PATH], line[MAX_PATH * 2];
  FILE *f;

  if (exit_code) *exit_code = -1;
  if (out && cap > 0) out[0] = 0;
  if (!cmd || !*cmd) return 0;

  if (!exec_have_powershell(ps, sizeof ps)) {
    if (out) snprintf(out, cap, "这台机器上没有 powershell.exe（XP 默认不带；要先装 .NET 2.0 再装 Windows PowerShell 2.0）");
    return 0;
  }

  if (!GetTempPathA(sizeof tmp, tmp)) return 0;
  snprintf(tmp2, sizeof tmp2, "%sxpwork_ps_%lu.ps1", tmp, (unsigned long)GetCurrentProcessId());

  f = fopen(tmp2, "wb");
  if (!f) return 0;
  fwrite(cmd, 1, strlen(cmd), f);
  fputc('\r', f);
  fputc('\n', f);
  fclose(f);

  snprintf(line, sizeof line,
           "\"%s\" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"%s\"",
           ps, tmp2);
  {
    int r = run_program(line, out, cap, exit_code, timeout_ms);
    DeleteFileA(tmp2);
    return r;
  }
}

int exec_read_file(const char *path, char *out, int cap, int *size) {
  FILE *f;
  long n;
  int i;

  if (size) *size = 0;
  if (!path || cap < 2) return 0;

  f = fopen(path, "rb");
  if (!f) return 0;
  fseek(f, 0, SEEK_END);
  n = ftell(f);
  fseek(f, 0, SEEK_SET);
  if (n < 0) { fclose(f); return 0; }
  if (n > cap - 1) n = cap - 1;
  n = (long)fread(out, 1, (size_t)n, f);
  fclose(f);
  out[n] = 0;

  for (i = 0; i < n && i < 512; i++) {
    if (out[i] == 0) { out[0] = 0; return 0; }   /* 二进制，不返回 */
  }
  if (size) *size = (int)n;
  return 1;
}

int exec_write_file(const char *path, const char *data, int len) {
  FILE *f;
  if (!path || !data) return 0;
  f = fopen(path, "wb");
  if (!f) return 0;
  if (len > 0) fwrite(data, 1, (size_t)len, f);
  fclose(f);
  return 1;
}
