/* gfx_win32.c -- GDI 后端 */
#include <windows.h>
#include "gfx.h"

static HDC target;
static HFONT fonts[2];
static int cw[2], lh[2], fh[2];
static int ready;

static struct { COLORREF c; HBRUSH b; } brushes[32];
static int nbrush;

void gfx_set_target(void *ctx) { target = (HDC)ctx; }

static HBRUSH brush_for(COLORREF c) {
  int i;
  for (i = 0; i < nbrush; i++)
    if (brushes[i].c == c) return brushes[i].b;
  if (nbrush < 32) {
    brushes[nbrush].c = c;
    brushes[nbrush].b = CreateSolidBrush(c);
    return brushes[nbrush++].b;
  }
  return (HBRUSH)GetStockObject(BLACK_BRUSH);
}

static void init_fonts(void) {
  HDC dc; SIZE sz; TEXTMETRIC tm; HFONT old;
  int i;

  dc = CreateCompatibleDC(target);
  /* 宋体：中文 XP 自带，ASCII 半角、汉字全角，正好是等宽的 */
  fonts[FONT_UI] = CreateFontA(-13, 0, 0, 0, FW_NORMAL, 0, 0, 0, GB2312_CHARSET,
                               OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                               DEFAULT_PITCH | FF_SWISS, "SimSun");
  fonts[FONT_MONO] = CreateFontA(-14, 0, 0, 0, FW_NORMAL, 0, 0, 0, GB2312_CHARSET,
                                 OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                 FIXED_PITCH | FF_MODERN, "SimSun");

  lh[FONT_UI] = 18;
  lh[FONT_MONO] = 18;

  for (i = 0; i < 2; i++) {
    old = (HFONT)SelectObject(dc, fonts[i]);
    GetTextExtentPoint32A(dc, "MMMM", 4, &sz);
    GetTextMetrics(dc, &tm);
    cw[i] = sz.cx / 4;
    fh[i] = tm.tmHeight;
    SelectObject(dc, old);
  }
  DeleteDC(dc);
  ready = 1;
}

int gfx_cell_w(int font) { return ready ? cw[font] : 8; }
int gfx_line_h(int font) { return ready ? lh[font] : 18; }

void gfx_begin(int w, int h) {
  (void)w; (void)h;
  if (!ready) init_fonts();
}

void gfx_end(void) {}

void gfx_fill(int x, int y, int w, int h, Color c) {
  RECT r;
  r.left = x; r.top = y; r.right = x + w; r.bottom = y + h;
  FillRect(target, &r, brush_for(RGB(c.r, c.g, c.b)));
}

void gfx_frame(int x, int y, int w, int h, Color c) {
  RECT r;
  r.left = x; r.top = y; r.right = x + w; r.bottom = y + h;
  FrameRect(target, &r, brush_for(RGB(c.r, c.g, c.b)));
}

int oc_draw_image(HDC hdc, const char *path, int x, int y, int w, int h);

int gfx_image(const char *path, int x, int y, int w, int h) {
  return oc_draw_image(target, path, x, y, w, h);
}

void gfx_text(int x, int y, const char *s, int len, Color c, int font, int clip_r) {
  RECT r;
  HFONT old;
  if (len <= 0) return;
  r.left = x;
  r.top = y;
  r.right = clip_r;
  r.bottom = y + lh[font];

  old = (HFONT)SelectObject(target, fonts[font]);
  SetTextColor(target, RGB(c.r, c.g, c.b));
  SetBkMode(target, TRANSPARENT);
  ExtTextOutA(target, x, y + (lh[font] - fh[font]) / 2, ETO_CLIPPED, &r, s, (UINT)len, NULL);
  SelectObject(target, old);
}
