/* settings.h -- API 配置（存在 exe 同目录的 opencode.ini） */
#ifndef SETTINGS_H
#define SETTINGS_H

void settings_init(void);
void settings_load(void);
int  settings_save(void);

const char *settings_key(void);
const char *settings_base(void);
const char *settings_model(void);
const char *settings_effort(void);      /* off / low / high / max */
const char *settings_effort_label(void);
const char *settings_note(void);
int         settings_key_plain(void);
/* 今日消耗（元），按 DeepSeek 的 token 单价估算 */
void        cost_init(void);
void        cost_add(long in_tok, long out_tok);
double      cost_today(void);
long        cost_tokens_today(void);
void        settings_set_note(const char *v);

/* 通用输入框：单行或多行。返回 1 表示点了确定 */
int oc_prompt(void *owner, const char *caption, const char *text,
              char *buf, int cap, int multiline);/* 关闭 / 低 / 高 / 最高 */
void        settings_set_effort(const char *v);
void        settings_set_key(const char *v);
void        settings_set_base(const char *v);
void        settings_set_model(const char *v);
const char *settings_ini_path(void);

int  settings_ready(void);
int  settings_tools_enabled(void);
void settings_set_tools(int on);          /* 填了接口地址和模型就算可用 */
int  settings_dialog(void *parent); /* 返回 1 表示用户点了确定 */

void settings_clear_key(void);

#endif
