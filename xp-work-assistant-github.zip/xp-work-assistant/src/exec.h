/* exec.h -- 在本机执行命令 / 读写文件（Windows XP 只有 cmd.exe） */
#ifndef OC_EXEC_H
#define OC_EXEC_H

/* 跑一条 cmd 命令，stdout+stderr 合并捕获。返回 1 成功取到输出 */
int exec_cmd(const char *cmd, char *out, int cap, int *exit_code, int timeout_ms);

/* PowerShell：命令写成临时 .ps1 再执行，避免引号地狱 */
int exec_ps(const char *cmd, char *out, int cap, int *exit_code, int timeout_ms);
int exec_have_powershell(char *path, int cap);

int exec_read_file(const char *path, char *out, int cap, int *size);
int exec_write_file(const char *path, const char *data, int len);

#endif
