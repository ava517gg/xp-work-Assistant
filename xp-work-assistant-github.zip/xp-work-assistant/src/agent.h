/* agent.h -- 带工具调用的对话循环 */
#ifndef OC_AGENT_H
#define OC_AGENT_H

/* emit 的 kind */
#define EV_TOOL  0   /* 工具调用标题 */
#define EV_OUT   1   /* 工具输出 */
#define EV_SAY   2   /* 模型最终回答 */
#define EV_ERR   3   /* 错误 */
#define EV_FILE  4   /* 文件预览：路径\n内容 */
#define EV_IMG   5   /* 图片预览：宽 高\n路径 */

typedef void (*EmitFn)(int kind, const char *text);

/* 返回 1 表示跑起来了（0 = 没配置或启动失败） */
int  agent_run(const char *user_gbk, EmitFn emit);
void agent_abort(void);
void agent_reset(void);   /* 清空上下文（新会话 / 清空对话时调） */

#endif
