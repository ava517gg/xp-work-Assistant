/* net.c -- 用 WinInet 发一个 OpenAI 兼容的 /chat/completions 请求
 *
 * 请求在后台线程里跑，完成后 PostMessage 回主窗口，界面不会卡住。
 * XP 自带 wininet.dll；https 走系统 TLS（XP 只有 TLS 1.0，
 * 所以默认建议指向局域网里的 http 服务，比如 Ollama）。
 */

#include <windows.h>
#include <wininet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "net.h"
#include "settings.h"
#include "tls_http.h"

#define MAX_BODY 16384
#define MAX_RESP 65536
#define MAX_TEXT 16384

typedef struct {
  HWND hwnd;
  UINT msg;
  int  gen;
  char prompt[MAX_BODY / 4];
} NetCtx;

static CRITICAL_SECTION g_cs;
static int   g_cs_ready;
static char  g_text[MAX_TEXT];
static char  g_err[512];
static int   g_ok, g_gen, g_done;

/* ---------------------------------------------------------------- 编码 */

static void gbk_to_utf8(const char *in, char *out, int cap) {
  int n = MultiByteToWideChar(CP_ACP, 0, in, -1, NULL, 0);
  wchar_t *w;
  if (n <= 0) { out[0] = 0; return; }
  w = (wchar_t *)malloc(sizeof(wchar_t) * (size_t)n);
  if (!w) { out[0] = 0; return; }
  MultiByteToWideChar(CP_ACP, 0, in, -1, w, n);
  WideCharToMultiByte(CP_UTF8, 0, w, -1, out, cap, NULL, NULL);
  free(w);
}

static void utf8_to_gbk(const char *in, char *out, int cap) {
  int n = MultiByteToWideChar(CP_UTF8, 0, in, -1, NULL, 0);
  wchar_t *w;
  if (n <= 0) { out[0] = 0; return; }
  w = (wchar_t *)malloc(sizeof(wchar_t) * (size_t)n);
  if (!w) { out[0] = 0; return; }
  MultiByteToWideChar(CP_UTF8, 0, in, -1, w, n);
  WideCharToMultiByte(CP_ACP, 0, w, -1, out, cap, NULL, NULL);
  free(w);
}

static void json_escape(const char *in, char *out, int cap) {
  int n = 0;
  while (*in && n < cap - 8) {
    unsigned char c = (unsigned char)*in++;
    if (c == '"' || c == '\\') { out[n++] = '\\'; out[n++] = (char)c; }
    else if (c == '\n') { out[n++] = '\\'; out[n++] = 'n'; }
    else if (c == '\r') { out[n++] = '\\'; out[n++] = 'r'; }
    else if (c == '\t') { out[n++] = '\\'; out[n++] = 't'; }
    else if (c < 0x20) { out[n++] = ' '; }
    else out[n++] = (char)c;
  }
  out[n] = 0;
}

/* ---------------------------------------------------------------- JSON */

static int hex4(const char *p) {
  int v = 0, i;
  for (i = 0; i < 4; i++) {
    char c = p[i];
    v <<= 4;
    if (c >= '0' && c <= '9') v += c - '0';
    else if (c >= 'a' && c <= 'f') v += c - 'a' + 10;
    else if (c >= 'A' && c <= 'F') v += c - 'A' + 10;
    else return -1;
  }
  return v;
}

static int utf8_put(char *out, int n, int cp) {
  if (cp < 0x80) out[n++] = (char)cp;
  else if (cp < 0x800) {
    out[n++] = (char)(0xC0 | (cp >> 6));
    out[n++] = (char)(0x80 | (cp & 0x3F));
  } else if (cp < 0x10000) {
    out[n++] = (char)(0xE0 | (cp >> 12));
    out[n++] = (char)(0x80 | ((cp >> 6) & 0x3F));
    out[n++] = (char)(0x80 | (cp & 0x3F));
  } else {
    out[n++] = (char)(0xF0 | (cp >> 18));
    out[n++] = (char)(0x80 | ((cp >> 12) & 0x3F));
    out[n++] = (char)(0x80 | ((cp >> 6) & 0x3F));
    out[n++] = (char)(0x80 | (cp & 0x3F));
  }
  return n;
}

/* 找 "key":"..." 并把字符串解出来（UTF-8 原样） */
static int json_get_string(const char *json, const char *key, char *out, int cap) {
  char pat[64];
  const char *p;
  int n = 0;

  snprintf(pat, sizeof pat, "\"%s\"", key);
  p = strstr(json, pat);
  if (!p) return 0;
  p = strchr(p + strlen(pat), ':');
  if (!p) return 0;
  p++;
  while (*p == ' ' || *p == '\t') p++;
  if (*p != '"') return 0;
  p++;

  while (*p && *p != '"' && n < cap - 6) {
    if (*p == '\\') {
      p++;
      switch (*p) {
        case 'n': out[n++] = '\n'; p++; break;
        case 't': out[n++] = '\t'; p++; break;
        case 'r': out[n++] = '\r'; p++; break;
        case '"': out[n++] = '"'; p++; break;
        case '\\': out[n++] = '\\'; p++; break;
        case '/': out[n++] = '/'; p++; break;
        case 'u': {
          int cp = hex4(p + 1);
          if (cp < 0) { p++; break; }
          p += 5;
          if (cp >= 0xD800 && cp <= 0xDBFF && p[0] == '\\' && p[1] == 'u') {
            int lo = hex4(p + 2);
            if (lo >= 0xDC00 && lo <= 0xDFFF) {
              cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
              p += 6;
            }
          }
          n = utf8_put(out, n, cp);
          break;
        }
        default: out[n++] = *p; p++; break;
      }
    } else {
      out[n++] = *p++;
    }
  }
  out[n] = 0;
  return n;
}

/* ---------------------------------------------------------------- 线程 */

static void build_url(char *out, int cap) {
  const char *b = settings_base();
  int n = (int)strlen(b);
  while (n > 0 && b[n - 1] == '/') n--;
  if (strncmp(b, "http://", 7) == 0 || strncmp(b, "https://", 8) == 0)
    snprintf(out, cap, "%.*s/chat/completions", n, b);
  else
    snprintf(out, cap, "http://%.*s/chat/completions", n, b);
}

static DWORD WINAPI net_thread(LPVOID param) {
  NetCtx *ctx = (NetCtx *)param;
  HINTERNET hNet = NULL, hConn = NULL, hReq = NULL;
  char url[512], body[MAX_BODY], resp[MAX_RESP];
  char host[256], path[512];
  char hdr[600], err[512] = "", text[MAX_TEXT] = "";
  char esc[MAX_BODY / 2];
  URL_COMPONENTSA uc;
  int ok = 0, https;
  DWORD status = 0, len = sizeof status, total = 0, got = 0, to = 120000;

  build_url(url, sizeof url);
  https = (strncmp(url, "https://", 8) == 0);

  json_escape(ctx->prompt, esc, sizeof esc);
  {
    const char *eff = settings_effort();
    if (!strcmp(eff, "off"))
      snprintf(body, sizeof body,
               "{\"model\":\"%s\",\"stream\":false,\"thinking\":{\"type\":\"disabled\"},"
               "\"messages\":[{\"role\":\"user\",\"content\":\"%s\"}]}",
               settings_model(), esc);
    else
      snprintf(body, sizeof body,
               "{\"model\":\"%s\",\"stream\":false,\"thinking\":{\"type\":\"enabled\"},"
               "\"reasoning_effort\":\"%s\","
               "\"messages\":[{\"role\":\"user\",\"content\":\"%s\"}]}",
               settings_model(), eff, esc);
  }

  if (settings_key()[0])
    snprintf(hdr, sizeof hdr,
             "Content-Type: application/json\r\nAuthorization: Bearer %s\r\n",
             settings_key());
  else
    snprintf(hdr, sizeof hdr, "Content-Type: application/json\r\n");

  /* https 用自带的 mbedTLS，完全不依赖系统的 TLS 栈 */
  if (https) {
    int st;
    char terr[512];
    st = tls_http_post(url, hdr, body, resp, sizeof resp, terr, sizeof terr);
    if (st < 0) {
      snprintf(err, sizeof err, "%s", terr);
      goto done;
    }
    status = (DWORD)st;
    goto parsed;
  }

  memset(&uc, 0, sizeof uc);
  uc.dwStructSize = sizeof uc;
  uc.lpszHostName = host;
  uc.dwHostNameLength = sizeof host;
  uc.lpszUrlPath = path;
  uc.dwUrlPathLength = sizeof path;

  if (!InternetCrackUrlA(url, 0, 0, &uc)) {
    snprintf(err, sizeof err, "接口地址无法解析：%s", url);
    goto done;
  }

  hNet = InternetOpenA("xpwork/1.0", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
  if (!hNet) { snprintf(err, sizeof err, "InternetOpen 失败"); goto done; }

  hConn = InternetConnectA(hNet, host, uc.nPort, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
  if (!hConn) { snprintf(err, sizeof err, "连不上 %s:%d", host, (int)uc.nPort); goto done; }

  hReq = HttpOpenRequestA(hConn, "POST", path, NULL, NULL, NULL,
                          INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE |
                          (https ? INTERNET_FLAG_SECURE : 0), 0);
  if (!hReq) { snprintf(err, sizeof err, "HttpOpenRequest 失败"); goto done; }

  InternetSetOptionA(hReq, INTERNET_OPTION_CONNECT_TIMEOUT, &to, sizeof to);
  InternetSetOptionA(hReq, INTERNET_OPTION_SEND_TIMEOUT, &to, sizeof to);
  InternetSetOptionA(hReq, INTERNET_OPTION_RECEIVE_TIMEOUT, &to, sizeof to);

  if (!HttpSendRequestA(hReq, hdr, -1, body, (DWORD)strlen(body))) {
    DWORD e = GetLastError();
    snprintf(err, sizeof err, "请求失败（错误码 %lu）。XP 只支持 TLS 1.0，https 服务多半连不上。", (unsigned long)e);
    goto done;
  }

  HttpQueryInfoA(hReq, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &status, &len, NULL);

  len = sizeof resp - 1;
  while (total < len && InternetReadFile(hReq, resp + total, len - total, &got) && got > 0)
    total += got;
  resp[total] = 0;

parsed:
  if (status != 200) {
    char msg[512];
    if (json_get_string(resp, "message", msg, sizeof msg) && msg[0])
      snprintf(err, sizeof err, "HTTP %lu：%s", (unsigned long)status, msg);
    else
      snprintf(err, sizeof err, "HTTP %lu", (unsigned long)status);
    goto done;
  }

  {
    char u8[MAX_TEXT];
    if (!json_get_string(resp, "content", u8, sizeof u8) || !u8[0]) {
      snprintf(err, sizeof err, "返回里没有 content 字段");
      goto done;
    }
    utf8_to_gbk(u8, text, sizeof text);
    ok = 1;
  }

done:
  if (hReq) InternetCloseHandle(hReq);
  if (hConn) InternetCloseHandle(hConn);
  if (hNet) InternetCloseHandle(hNet);

  EnterCriticalSection(&g_cs);
  strncpy(g_text, text, sizeof g_text - 1);
  g_text[sizeof g_text - 1] = 0;
  strncpy(g_err, err, sizeof g_err - 1);
  g_err[sizeof g_err - 1] = 0;
  g_ok = ok;
  g_gen = ctx->gen;
  g_done = 1;
  LeaveCriticalSection(&g_cs);

  if (ctx->hwnd) PostMessageA(ctx->hwnd, ctx->msg, (WPARAM)ctx->gen, 0);
  free(ctx);
  return 0;
}

int net_start(void *hwnd, unsigned msg, const char *gbk_prompt, int gen) {
  NetCtx *ctx;
  HANDLE th;
  char u8[MAX_BODY / 4];

  if (!g_cs_ready) {
    InitializeCriticalSection(&g_cs);
    g_cs_ready = 1;
  }

  ctx = (NetCtx *)malloc(sizeof(NetCtx));
  if (!ctx) return 0;
  ctx->hwnd = (HWND)hwnd;
  ctx->msg = msg;
  ctx->gen = gen;

  gbk_to_utf8(gbk_prompt, u8, sizeof u8);
  strncpy(ctx->prompt, u8, sizeof ctx->prompt - 1);
  ctx->prompt[sizeof ctx->prompt - 1] = 0;

  EnterCriticalSection(&g_cs);
  g_done = 0;
  LeaveCriticalSection(&g_cs);

  th = CreateThread(NULL, 0, net_thread, ctx, 0, NULL);
  if (!th) { free(ctx); return 0; }
  CloseHandle(th);
  return 1;
}

/* 轮询版：给没有窗口的消息循环（控制台程序）用。返回 0 = 还没好 */
int net_poll(int gen, char *out, int cap, char *err, int errcap) {
  int done;
  EnterCriticalSection(&g_cs);
  done = (g_done && g_gen == gen);
  if (done) {
    strncpy(out, g_text, cap - 1);
    out[cap - 1] = 0;
    strncpy(err, g_err, errcap - 1);
    err[errcap - 1] = 0;
  }
  LeaveCriticalSection(&g_cs);
  return done;
}

int net_take(int gen, char *out, int cap, char *err, int errcap) {
  int ok;
  EnterCriticalSection(&g_cs);
  ok = (g_done && g_gen == gen) ? g_ok : 0;
  strncpy(out, g_text, cap - 1);
  out[cap - 1] = 0;
  strncpy(err, g_err, errcap - 1);
  err[errcap - 1] = 0;
  LeaveCriticalSection(&g_cs);
  return ok;
}

/* ---------------------------------------------------------------- 连通性自检 */

typedef struct {
  HWND hwnd;
  UINT msg;
  char url[512];
} ProbeCtx;

static CRITICAL_SECTION g_pcs;
static int  g_pcs_ready;
static int  g_probe_ok, g_probe_done;
static char g_probe_msg[512];

static const char *probe_reason(DWORD e) {
  switch (e) {
    case 12007: return "域名解析失败：检查 DNS 或网络";
    case 12029: return "连不上服务器：端口、防火墙或代理";
    case 12002: return "连接超时";
    case 12157: return "TLS 握手失败：XP 多半还没装 TLS 1.2 补丁";
    case 12045: return "证书校验失败";
    case 12006: return "连接被断开";
    case 12019: return "服务器无响应";
    default:    return "连接失败";
  }
}

static DWORD WINAPI probe_thread(LPVOID param) {
  ProbeCtx *ctx = (ProbeCtx *)param;
  HINTERNET hNet = NULL, hUrl = NULL;
  DWORD err = 0, status = 0, len = sizeof status, to = 15000;
  int ok = 0;
  char msg[512];

  snprintf(msg, sizeof msg, "连接失败");

  /* https 用自带 TLS 探测，避免被系统的 SChannel 挡住 */
  if (strncmp(ctx->url, "https://", 8) == 0) {
    static char tmp[4096];
    char terr[512];
    int st = tls_http_get(ctx->url, tmp, sizeof tmp, terr, sizeof terr);
    if (st < 0) {
      snprintf(msg, sizeof msg, "  [x] %s", terr);
    } else {
      ok = 1;
      snprintf(msg, sizeof msg, "  [v] TLS 通道正常（自带 TLS）：HTTP %d", st);
    }
    goto out;
  }

  hNet = InternetOpenA("xpwork/1.0", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
  if (!hNet) {
    snprintf(msg, sizeof msg, "  初始化网络失败");
    goto out;
  }
  InternetSetOptionA(hNet, INTERNET_OPTION_CONNECT_TIMEOUT, &to, sizeof to);
  InternetSetOptionA(hNet, INTERNET_OPTION_SEND_TIMEOUT, &to, sizeof to);
  InternetSetOptionA(hNet, INTERNET_OPTION_RECEIVE_TIMEOUT, &to, sizeof to);

  hUrl = InternetOpenUrlA(hNet, ctx->url, NULL, 0,
                          INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
  if (!hUrl) {
    err = GetLastError();
    snprintf(msg, sizeof msg, "  [x] %s（错误码 %lu）", probe_reason(err), (unsigned long)err);
    goto out;
  }

  if (HttpQueryInfoA(hUrl, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &status, &len, NULL)) {
    ok = 1;
    snprintf(msg, sizeof msg, "  [v] TLS 通道正常：HTTP %lu", (unsigned long)status);
  } else {
    ok = 1;
    snprintf(msg, sizeof msg, "  [v] 已连上服务器（读不到状态码也算通）");
  }

out:
  if (hUrl) InternetCloseHandle(hUrl);
  if (hNet) InternetCloseHandle(hNet);

  EnterCriticalSection(&g_pcs);
  g_probe_ok = ok;
  g_probe_done = 1;
  strncpy(g_probe_msg, msg, sizeof g_probe_msg - 1);
  g_probe_msg[sizeof g_probe_msg - 1] = 0;
  LeaveCriticalSection(&g_pcs);

  PostMessageA(ctx->hwnd, ctx->msg, 0, 0);
  free(ctx);
  return 0;
}

int probe_start(void *hwnd, unsigned msg, const char *gbk_url) {
  ProbeCtx *ctx;
  HANDLE th;

  if (!g_pcs_ready) {
    InitializeCriticalSection(&g_pcs);
    g_pcs_ready = 1;
  }
  ctx = (ProbeCtx *)malloc(sizeof(ProbeCtx));
  if (!ctx) return 0;
  ctx->hwnd = (HWND)hwnd;
  ctx->msg = msg;
  snprintf(ctx->url, sizeof ctx->url, "%s",
           (gbk_url && gbk_url[0]) ? gbk_url : "https://api.deepseek.com/v1");

  EnterCriticalSection(&g_pcs);
  g_probe_done = 0;
  g_probe_ok = 0;
  LeaveCriticalSection(&g_pcs);

  th = CreateThread(NULL, 0, probe_thread, ctx, 0, NULL);
  if (!th) { free(ctx); return 0; }
  CloseHandle(th);
  return 1;
}

int probe_take(char *out, int cap) {
  int ok;
  EnterCriticalSection(&g_pcs);
  ok = g_probe_ok;
  strncpy(out, g_probe_msg, cap - 1);
  out[cap - 1] = 0;
  LeaveCriticalSection(&g_pcs);
  return ok;
}
