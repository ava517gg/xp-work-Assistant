/* ui.c -- opencode desktop 的界面层（中文版）
 *
 * 所有布局和绘制都在这里，平台代码只负责开窗口、转事件。
 * 同一份代码也会被 headless 构建调用，把界面输出成 SVG 用来预览。
 *
 * 编码：Windows 构建用 -fexec-charset=GBK 编译，字符串是 GBK 字节，
 * 和中文 XP 的 ANSI 代码页一致；Linux 预览构建则是 UTF-8。
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "gfx.h"
#include "ui.h"

void ui_delete_session(int idx);
void ui_new_session(void);
#include "text.h"

#define MAX_RAW   400
#define MAX_VIS   4000
#define MAX_Q     260
#define Q_LEN     320

/* ---------------------------------------------------------------- 配色 */

static const Color C_FACE    = { 236, 233, 216 };
static const Color C_FACE_2  = { 244, 242, 232 };
static const Color C_BORDER  = { 172, 168, 153 };
static const Color C_INK     = {  26,  26,  26 };
static const Color C_INK_DIM = { 108, 104,  92 };
static const Color C_SEL     = {  49, 106, 197 };
static const Color C_WHITE   = { 255, 255, 255 };

static const Color C_CHAT_BG = {  16,  20,  24 };
static const Color C_CHAT_TX = { 214, 214, 214 };
static const Color C_MUTED   = { 122, 128, 136 };
static const Color C_TOOL    = { 111, 179, 210 };
static const Color C_OK      = { 126, 231, 135 };
static const Color C_WARN    = { 229, 192, 123 };
static const Color C_ADD_TX  = { 155, 232, 155 };
static const Color C_ADD_BG  = {  22,  40,  26 };
static const Color C_DEL_TX  = { 240, 160, 160 };
static const Color C_DEL_BG  = {  42,  22,  24 };
static const Color C_USER_BG = {  28,  36,  48 };
static const Color C_INPUT_BG= {  11,  14,  18 };
static const Color C_BTN     = {  43, 108, 176 };
static const Color C_SB_TH   = {  74,  85,  99 };

/* ---------------------------------------------------------------- 状态 */

enum { ST_TXT, ST_USER, ST_TOOL, ST_DIM, ST_ADD, ST_DEL, ST_OK, ST_WARN };

typedef struct {
  char text[Q_LEN];
  unsigned char style;
} RawLine;

static RawLine raw[MAX_RAW];
static int nraw;

typedef struct {
  short r, off, len;
} Vis;

static Vis vis[MAX_VIS];
static int nvis;
static int vis_dirty = 1;

static int W = 760, H = 560;
int g_sidebar_w = SIDEBAR_NARROW;
static int g_sw_target = SIDEBAR_NARROW;
static int g_sel_a, g_sel_b;
static int pv_line_at(int y);
static int scroll;
static int follow = 1;

static int typing_raw = -1;
static int typing_len, typing_shown;

static int busy;
static int net_pending;
static char tw_buf[16384];
static int  tw_len, tw_pos, tw_active, tw_line = -1;
/* 余额文案。带一个哨兵值：万一被别处的越界写坏，绘制时能发现并自愈，
   而不是把乱码一直显示下去 */
#define BAL_MAGIC 0x42414C31UL
static struct {
  unsigned long magic;
  char text[64];
} g_bal = { BAL_MAGIC, "" };
static int net_gen;       /* 每次请求的代号，用来丢弃过期结果 */

static int tokens = 1204;
static double cost = 0.012;
static int model_idx = 0;

static const char *MODELS[] = {
  "claude-sonnet-4", "gpt-5-codex", "qwen3-coder", "claude-opus-4.5"
};

static int sel_session = 0;
typedef struct {
  char title[48];
  int  fav;
  int  archived;
  unsigned long born;
} Session;
static Session sess[8];
static int  nsess;
static int  g_menu_idx;
static int  g_tool_running;   /* 有命令正在跑 */
static int  g_anim;           /* 光泽动画的相位 */
static char g_pv_name[128];
static char g_pv_text[32768];
static int  g_pv_is_image, g_pv_w, g_pv_h;
static int  g_pv_lines;
static int  g_pv_top;         /* 预览区起始 y */
static int  g_pick_line;
int ui_preview_pick_line(void) { return g_pick_line; }
int ui_sidebar_w(void) { return g_sidebar_w; }

int ui_divider_hit(int x, int y) {
  (void)y;
  if (g_sw_target <= 200) return 0;          /* 收起状态没有分隔条 */
  return (x >= g_sidebar_w - 5 && x <= g_sidebar_w + 5);
}

void ui_set_sidebar_w(int w) {
  if (w < 240) w = 240;
  if (w > 620) w = 620;
  g_sidebar_w = w;
  g_sw_target = w;                            /* 拖完就停在这个宽度 */
  vis_dirty = 1;
}
const char *ui_preview_name(void) { return g_pv_name; }
int ui_preview_line_click(int y) { (void)y; return g_pick_line; }
static int  show_archived;
static int  archived_rect_y;
static int  sess_seq = 1;

static char preview_input[256];
static int preview_caret = -1;

/* ---------------------------------------------------------------- 附件 */

#define MAX_ATTACH 4
#define MAX_ATTACH_BODY (128 * 1024)

typedef struct {
  char name[64];
  long size;
  int  is_image;
  char *text;
} Attach;

static Attach attach[MAX_ATTACH];
static int nattach;
static char payload[768 * 1024];

void ui_attach_add(const char *name, long size, const char *text, int is_image) {
  Attach *a;
  size_t n;
  if (nattach >= MAX_ATTACH) return;
  if (!name || !text) return;
  n = strlen(text);
  if (n > MAX_ATTACH_BODY) n = MAX_ATTACH_BODY;
  a = &attach[nattach];
  strncpy(a->name, name, sizeof a->name - 1);
  a->name[sizeof a->name - 1] = 0;
  a->size = size;
  a->is_image = is_image;
  a->text = (char *)malloc(n + 1);
  if (!a->text) return;
  memcpy(a->text, text, n);
  a->text[n] = 0;
  nattach++;
}

int ui_attach_count(void) { return nattach; }

void ui_attach_clear(void) {
  int i;
  for (i = 0; i < nattach; i++) free(attach[i].text);
  nattach = 0;
}

static void attach_remove(int idx) {
  int i;
  if (idx < 0 || idx >= nattach) return;
  free(attach[idx].text);
  for (i = idx; i < nattach - 1; i++) attach[i] = attach[i + 1];
  nattach--;
}

/* ---------------------------------------------------------------- 几何 */

static int chat_h(void) { return H - STATUS_H - INPUT_H; }

/* 在线时显示配置里的模型名，离线时显示演示用的名字 */
static const char *model_label(void) {
  if (oc_online()) {
    const char *m = oc_model_name();
    if (m && m[0]) return m;
  }
  return MODELS[model_idx];
}

static void input_rect(int *x, int *y, int *w, int *h) {
  int bx = SIDEBAR_W + CHAT_PAD;
  int by = chat_h() + 64;
  int bw = W - SIDEBAR_W - CHAT_PAD * 2 - 74;
  if (bw < 40) bw = 40;
  *x = bx; *y = by; *w = bw; *h = 24;
}

static void send_button_rect(int *x, int *y, int *w, int *h) {
  *x = W - CHAT_PAD - 64;
  *y = chat_h() + 62;
  *w = 64;
  *h = 28;
}

void ui_input_rect(int *x, int *y, int *w, int *h) { input_rect(x, y, w, h); }
void ui_send_rect(int *x, int *y, int *w, int *h) { send_button_rect(x, y, w, h); }

static int chat_cols(void) {
  int cw = gfx_cell_w(FONT_MONO);
  int w = W - SIDEBAR_W - CHAT_PAD * 2 - 14;
  if (cw < 1) cw = 7;
  if (w < 8 * cw) w = 8 * cw;
  return w / cw;
}

/* 一段字节占多少像素（某字体） */
static int text_px_font(const char *s, int n, int font) {
  int i = 0, w = 0, cw = gfx_cell_w(font);
  while (i < n) {
    int len, wid;
    oc_char(s, i, n, &len, &wid);
    if (!len) break;
    w += wid * cw;
    i += len;
  }
  return w;
}

/* ---------------------------------------------------------------- 文本行 */

static void raw_add(const char *text, unsigned char style) {
  RawLine *l;
  if (nraw >= MAX_RAW) {
    memmove(&raw[0], &raw[1], sizeof(RawLine) * (MAX_RAW - 1));
    nraw = MAX_RAW - 1;
    if (typing_raw > 0) typing_raw--;
  }
  l = &raw[nraw++];
  strncpy(l->text, text, Q_LEN - 1);
  l->text[Q_LEN - 1] = 0;
  l->style = style;
  vis_dirty = 1;
  follow = 1;
}

static void vis_push(int r, int off, int len) {
  if (nvis >= MAX_VIS) return;
  vis[nvis].r = (short)r;
  vis[nvis].off = (short)off;
  vis[nvis].len = (short)len;
  nvis++;
}

static void rebuild_vis(void) {
  int i, cols = chat_cols();
  nvis = 0;
  if (cols < 8) cols = 8;

  for (i = 0; i < nraw; i++) {
    const char *s = raw[i].text;
    int len = (int)strlen(s);
    int shown = (i == typing_raw) ? typing_shown : len;
    int off = 0;

    if (shown <= 0) { vis_push(i, 0, 0); continue; }

    while (off < shown) {
      int p = off, w = 0, brk = -1;

      while (p < shown) {
        int clen, cwid;
        oc_char(s, p, shown, &clen, &cwid);
        if (!clen) break;
        if (w + cwid > cols) break;
        w += cwid;
        p += clen;
        if (s[p - 1] == ' ') brk = p;   /* 可以在空格后断行 */
      }

      if (p >= shown) {
        vis_push(i, off, shown - off);
        break;
      }
      if (brk > off + 1) p = brk;       /* 有空格就优先在空格处断 */
      if (p <= off) p = off + 1;        /* 兜底，防止死循环 */

      vis_push(i, off, p - off);
      off = p;
      while (s[off] == ' ' && off < shown) off++;
    }
  }
  vis_dirty = 0;
}

static int max_scroll(void) {
  int n = (chat_h() - 8) / LH_MONO;
  int m = nvis - n;
  return m > 0 ? m : 0;
}

/* ---------------------------------------------------------------- 绘制 */

static void style_colors(unsigned char st, Color *fg, Color *bg) {
  *fg = C_CHAT_TX;
  *bg = C_CHAT_BG;
  switch (st) {
    case ST_USER: *fg = C_WHITE;   *bg = C_USER_BG; break;
    case ST_TOOL: *fg = C_TOOL;    break;
    case ST_DIM:  *fg = C_MUTED;   break;
    case ST_ADD:  *fg = C_ADD_TX;  *bg = C_ADD_BG; break;
    case ST_DEL:  *fg = C_DEL_TX;  *bg = C_DEL_BG; break;
    case ST_OK:   *fg = C_OK;      break;
    case ST_WARN: *fg = C_WARN;    break;
    default: break;
  }
}

static void age_text(unsigned long born, char *out, int cap) {
  unsigned long now = oc_ticks();
  unsigned long ms = (now > born) ? now - born : 0;
  unsigned long min = ms / 60000UL;
  if (min < 1) snprintf(out, cap, "刚刚");
  else if (min < 60) snprintf(out, cap, "%lu分钟", min);
  else if (min < 60 * 24) snprintf(out, cap, "%lu小时", min / 60);
  else snprintf(out, cap, "%lu天", min / (60 * 24));
}

/* ---- 语法高亮：接近 VSCode Dark+ 的配色 ---- */
#define CL_DEF   RGB_(212, 212, 212)
#define CL_KW    RGB_(86, 156, 214)
#define CL_CTRL  RGB_(197, 134, 192)
#define CL_TYPE  RGB_(78, 201, 176)
#define CL_FUNC  RGB_(220, 220, 170)
#define CL_NUM   RGB_(181, 206, 168)
#define CL_STR   RGB_(206, 145, 120)
#define CL_CMT   RGB_(106, 153, 85)

static const char *KW_CTRL[] = {
  "if","else","for","while","do","switch","case","default","break","continue",
  "return","goto","try","catch","finally","throw","elif","except","with","as",
  "yield","await","async","in","is","not","and","or","lambda","pass","raise",
  "import","from","class","def","del","global","assert","print",
  NULL
};
static const char *KW_TYPE[] = {
  "int","char","void","float","double","long","short","unsigned","signed",
  "struct","union","enum","typedef","const","static","extern","volatile",
  "sizeof","register","bool","string","size_t","uint32_t","int32_t",
  NULL
};
static const char *KW_WORD[] = {
  "function","var","let","new","this","self","null","nullptr","NULL","true",
  "false","True","False","None","undefined","typeof","instanceof","public",
  "private","protected","extends","implements","interface","package","using",
  "namespace","template","typename","auto","override","virtual","inline",
  NULL
};

static int in_list(const char **L, const char *s, int n) {
  int i;
  for (i = 0; L[i]; i++) {
    int l = (int)strlen(L[i]);
    if (l == n && strncmp(s, L[i], (size_t)n) == 0) return 1;
  }
  return 0;
}

static int is_ident(char c) {
  return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
         (c >= '0' && c <= '9') || c == '_';
}

static void draw_code(int x, int y, const char *s, int len, int maxx, int *in_block) {
  int i = 0;
  const char QUOTE = (char)39;

  /* 上一行没闭合的块注释继续染色 */
  if (in_block && *in_block) {
    int e = 0;
    while (e + 1 < len && !(s[e] == '*' && s[e + 1] == '/')) e++;
    if (e + 1 < len) {
      e += 2;
      gfx_text(x, y, s, e, CL_CMT, FONT_MONO, maxx);
      *in_block = 0;
      i = e;
    } else {
      gfx_text(x, y, s, len, CL_CMT, FONT_MONO, maxx);
      return;
    }
  }

  if (!in_block || !*in_block) {
    if (len > 0 && s[0] == '#') {
      int pre = (len > 1 && (s[1] == QUOTE || s[1] == '<')) ||
                (len > 7 && strncmp(s, "#include", 8) == 0) ||
                (len > 6 && strncmp(s, "#define", 7) == 0);
      gfx_text(x, y, s, len, pre ? CL_CTRL : CL_CMT, FONT_MONO, maxx);
      return;
    }
  }

  while (i < len) {
    int start = i;
    Color col = CL_DEF;
    char c = s[i];

    if (c == '/' && i + 1 < len && s[i + 1] == '/') {
      gfx_text(x + text_px_font(s, i, FONT_MONO), y, s + i, len - i, CL_CMT, FONT_MONO, maxx);
      return;
    }
    if (c == '/' && i + 1 < len && s[i + 1] == '*') {
      int e = i + 2;
      while (e + 1 < len && !(s[e] == '*' && s[e + 1] == '/')) e++;
      if (e + 1 < len) {
        e += 2;
      } else {
        e = len;
        if (in_block) *in_block = 1;      /* 没闭合，下一行继续 */
      }
      gfx_text(x + text_px_font(s, i, FONT_MONO), y, s + i, e - i, CL_CMT, FONT_MONO, maxx);
      i = e;
      continue;
    }
    if (c == '"' || c == QUOTE) {
      char q = c;
      i++;
      while (i < len) {
        if (s[i] == '\\' && i + 1 < len) { i += 2; continue; }
        if (s[i] == q) { i++; break; }
        i++;
      }
      gfx_text(x + text_px_font(s, start, FONT_MONO), y, s + start, i - start, CL_STR, FONT_MONO, maxx);
      continue;
    }
    if (c >= '0' && c <= '9') {
      i++;
      while (i < len && (is_ident(s[i]) || s[i] == '.')) i++;
      gfx_text(x + text_px_font(s, start, FONT_MONO), y, s + start, i - start, CL_NUM, FONT_MONO, maxx);
      continue;
    }
    if (is_ident(c)) {
      int n, j;
      i++;
      while (i < len && is_ident(s[i])) i++;
      n = i - start;
      if (in_list(KW_CTRL, s + start, n)) col = CL_CTRL;
      else if (in_list(KW_TYPE, s + start, n)) col = CL_TYPE;
      else if (in_list(KW_WORD, s + start, n)) col = CL_KW;
      else {
        j = i;
        while (j < len && s[j] == ' ') j++;
        if (j < len && s[j] == '(') col = CL_FUNC;
      }
      gfx_text(x + text_px_font(s, start, FONT_MONO), y, s + start, n, col, FONT_MONO, maxx);
      continue;
    }
    i++;
    while (i < len && !is_ident(s[i]) && s[i] != '"' && s[i] != QUOTE &&
           s[i] != '/' && !(s[i] >= '0' && s[i] <= '9')) i++;
    gfx_text(x + text_px_font(s, start, FONT_MONO), y, s + start, i - start, CL_DEF, FONT_MONO, maxx);
  }
}


static void paint_preview(void) {
  int y = 40, ln = 0, i = 0;
  int palette_w[2] = { SIDEBAR_W - 40, SIDEBAR_W - 4 };

  gfx_fill(1, 34, SIDEBAR_W - 2, H - 34, RGB_(12, 15, 19));
  gfx_text(12, 8, ">_", 2, RGB_(31, 138, 58), FONT_MONO, SIDEBAR_W - 8);
  gfx_text(30, 7, "预览", (int)strlen("预览"), RGB_(226, 230, 236), FONT_UI, SIDEBAR_W - 30);
  gfx_text(SIDEBAR_W - 20, 7, "×", (int)strlen("×"), RGB_(26, 30, 36), FONT_UI, SIDEBAR_W - 6);

  gfx_text(12, y, g_pv_name, (int)strlen(g_pv_name), RGB_(186, 214, 255), FONT_UI, palette_w[1]);
  y += 20;
  gfx_fill(10, y, SIDEBAR_W - 20, 1, RGB_(40, 46, 56));
  y += 6;
  g_pv_top = y;

  if (g_pv_is_image) {
    char b[128];
    snprintf(b, sizeof b, "图片 %d×%d", g_pv_w, g_pv_h);
    gfx_text(12, y, b, (int)strlen(b), C_INK_DIM, FONT_UI, palette_w[1]);
    y += 20;
    {
      int box_h = H - STATUS_H - y - 40;
      if (box_h > 220) box_h = 220;
      if (box_h < 80) box_h = 80;
      gfx_fill(10, y, SIDEBAR_W - 20, box_h, RGB_(18, 22, 28));
      gfx_frame(10, y, SIDEBAR_W - 20, box_h, RGB_(52, 60, 72));
      if (!gfx_image(g_pv_name, 12, y + 2, SIDEBAR_W - 24, box_h - 4)) {
        gfx_text(20, y + box_h / 2 - 8, "（图片打不开）",
                 (int)strlen("（图片打不开）"), RGB_(200, 140, 140), FONT_UI, SIDEBAR_W - 30);
      }
      y += box_h + 8;
    }
    gfx_text(12, y, "可以在对话里让它用命令处理这个文件", (int)strlen("可以在对话里让它用命令处理这个文件"), C_INK_DIM, FONT_UI, SIDEBAR_W - 16);
    return;
  }

  {
    const char *p = g_pv_text;
    int sa = 0, sb = 0, has_sel = ui_preview_sel(&sa, &sb);
    int in_block = 0;
    while (*p && y < H - STATUS_H - 20) {
      const char *nl = strchr(p, '\n');
      int len = nl ? (int)(nl - p) : (int)strlen(p);
      char num[12];
      ln++;
      if (has_sel && ln >= sa && ln <= sb)
        gfx_fill(1, y, SIDEBAR_W - 3, LH_MONO, RGB_(36, 62, 96));
      snprintf(num, sizeof num, "%3d", ln);
      gfx_text(8, y, num, (int)strlen(num), RGB_(96, 104, 118), FONT_MONO, SIDEBAR_W - 40);
      draw_code(34, y, p, len, SIDEBAR_W - 8, &in_block);
      y += LH_MONO;
      if (!nl) break;
      p = nl + 1;
    }
  }
  (void)i;
}

static void paint_sidebar(void) {
  if (g_pv_name[0] && g_sidebar_w > 200) {
    gfx_fill(0, 0, SIDEBAR_W, H, C_FACE);
    gfx_fill(SIDEBAR_W - 1, 0, 1, H, C_BORDER);
    gfx_fill(1, 0, SIDEBAR_W - 2, 34, C_FACE_2);
    paint_preview();
    return;
  }
  int y, i;

  gfx_fill(0, 0, SIDEBAR_W, H, C_FACE);
  gfx_fill(SIDEBAR_W - 1, 0, 1, H, C_BORDER);
  gfx_fill(1, 0, SIDEBAR_W - 2, 34, C_FACE_2);

  gfx_text(12, 8, ">_", 2, RGB_(31, 138, 58), FONT_MONO, SIDEBAR_W - 8);
  gfx_text(30, 7, "xp work Assistant", (int)strlen("xp work Assistant"), C_INK, FONT_UI, SIDEBAR_W - 4);

  /* ---- 会话（未归档） ---- */
  y = 42;
  gfx_text(12, y, "会话", (int)strlen("会话"), C_INK_DIM, FONT_UI, SIDEBAR_W - 8);
  y += 18;

  for (i = 0; i < nsess; i++) {
    char buf[64], age[24];
    int tw;
    if (sess[i].archived) continue;
    snprintf(buf, sizeof buf, "%s%s", sess[i].fav ? "★ " : "", sess[i].title);
    age_text(sess[i].born, age, sizeof age);
    tw = text_px_font(age, (int)strlen(age), FONT_UI);
    if (i == sel_session) {
      gfx_fill(4, y - 2, SIDEBAR_W - 8, 20, C_SEL);
      gfx_text(12, y, buf, (int)strlen(buf), C_WHITE, FONT_UI, SIDEBAR_W - 82);
      gfx_text(SIDEBAR_W - tw - 46, y, age, (int)strlen(age), RGB_(226, 232, 240), FONT_UI, SIDEBAR_W - 44);
      gfx_text(SIDEBAR_W - 40, y, "…", (int)strlen("…"), RGB_(200, 214, 230), FONT_UI, SIDEBAR_W - 24);
      gfx_text(SIDEBAR_W - 20, y, "×", (int)strlen("×"), RGB_(255, 200, 200), FONT_UI, SIDEBAR_W - 7);
    } else {
      gfx_text(12, y, buf, (int)strlen(buf), C_INK, FONT_UI, SIDEBAR_W - tw - 12);
      gfx_text(SIDEBAR_W - tw - 8, y, age, (int)strlen(age), C_INK_DIM, FONT_UI, SIDEBAR_W - 4);
    }
    y += 22;
  }

  /* ---- 归档 ---- */
  {
    int narch = 0;
    for (i = 0; i < nsess; i++) if (sess[i].archived) narch++;
    gfx_fill(10, y + 4, SIDEBAR_W - 20, 1, C_BORDER);
    y += 12;
    {
      char b[64];
      snprintf(b, sizeof b, "%s 归档", show_archived ? "▼" : "→");
      archived_rect_y = y;
      gfx_text(12, y, b, (int)strlen(b), C_INK_DIM, FONT_UI, SIDEBAR_W - 30);
      if (narch) {
        char nb[16];
        snprintf(nb, sizeof nb, "%d", narch);
        gfx_text(SIDEBAR_W - text_px_font(nb, (int)strlen(nb), FONT_UI) - 10, y,
                 nb, (int)strlen(nb), C_INK_DIM, FONT_UI, SIDEBAR_W - 4);
      } else {
        archived_rect_y = y;
      }
    }
    y += 20;
    if (show_archived) {
      for (i = 0; i < nsess; i++) {
        char buf[64], age[24];
        int tw;
        if (!sess[i].archived) continue;
        snprintf(buf, sizeof buf, "%s", sess[i].title);
        age_text(sess[i].born, age, sizeof age);
        tw = text_px_font(age, (int)strlen(age), FONT_UI);
        if (i == sel_session) {
          gfx_fill(4, y - 2, SIDEBAR_W - 8, 20, C_SEL);
          gfx_text(12, y, buf, (int)strlen(buf), C_WHITE, FONT_UI, SIDEBAR_W - 82);
          gfx_text(SIDEBAR_W - tw - 46, y, age, (int)strlen(age), RGB_(226, 232, 240), FONT_UI, SIDEBAR_W - 44);
          gfx_text(SIDEBAR_W - 20, y, "×", (int)strlen("×"), RGB_(255, 200, 200), FONT_UI, SIDEBAR_W - 7);
        } else {
          gfx_text(12, y, buf, (int)strlen(buf), C_INK_DIM, FONT_UI, SIDEBAR_W - tw - 12);
          gfx_text(SIDEBAR_W - tw - 8, y, age, (int)strlen(age), C_INK_DIM, FONT_UI, SIDEBAR_W - 4);
        }
        y += 22;
      }
    }
  }

  /* ---- 模型 ---- */
  gfx_fill(10, y + 6, SIDEBAR_W - 20, 1, C_BORDER);
  y += 14;
  gfx_text(12, y, "模型", (int)strlen("模型"), C_INK_DIM, FONT_UI, SIDEBAR_W - 8);
  y += 18;
  gfx_text(12, y, model_label(), (int)strlen(model_label()), C_INK, FONT_UI, SIDEBAR_W - 8);

  gfx_text(12, H - STATUS_H - 20, "v1.0  中文版", (int)strlen("v1.0  中文版"), C_INK_DIM, FONT_UI, SIDEBAR_W - 6);
}

static void paint_chat(void) {
  int cx = SIDEBAR_W;
  int cw = W - SIDEBAR_W;
  int top = 8;
  int rows = (chat_h() - top) / LH_MONO;
  int i;
  int clip_r = cx + cw - 16;

  gfx_fill(cx, 0, cw, chat_h(), C_CHAT_BG);

  for (i = 0; i < rows; i++) {
    int idx = scroll + i;
    int y = top + i * LH_MONO;
    const RawLine *rl;
    Color fg, bg;
    if (idx >= nvis) break;
    rl = &raw[vis[idx].r];
    style_colors(rl->style, &fg, &bg);
    if (bg.r != C_CHAT_BG.r || bg.g != C_CHAT_BG.g || bg.b != C_CHAT_BG.b)
      gfx_fill(cx, y, cw, LH_MONO, bg);
    if (g_tool_running && idx == nvis - 1) {
      /* 执行中的流动光带 */
      int band = 70;
      int x = cx + CHAT_PAD + ((g_anim * 6) % (cw - band - 20));
      gfx_fill(x, y, band, LH_MONO, RGB_(32, 58, 46));
    }
    if (vis[idx].len > 0)
      gfx_text(cx + CHAT_PAD, y, rl->text + vis[idx].off, vis[idx].len, fg, FONT_MONO, clip_r);
  }

  {
    int ms = max_scroll();
    int track_h = chat_h() - 8;
    gfx_fill(cx + cw - 9, 4, 1, chat_h() - 8, RGB_(30, 36, 44));
    if (ms > 0) {
      int thumb_h = (chat_h() * track_h) / (nvis + 1);
      int thumb_y;
      if (thumb_h < 24) thumb_h = 24;
      if (thumb_h > track_h) thumb_h = track_h;
      thumb_y = 4 + (int)((long)(track_h - thumb_h) * scroll / ms);
      gfx_fill(cx + cw - 10, thumb_y, 6, thumb_h, C_SB_TH);
    }
  }
}

static void attach_button_rect(int *x, int *y, int *w, int *h) {
  *x = SIDEBAR_W + CHAT_PAD;
  *y = chat_h() + 6;
  *w = 84;
  *h = 22;
}

/* 第 i 个附件小标签的位置 */
static void effort_button_rect(int *x, int *y, int *w, int *h) {
  int ax, ay, aw, ah;
  attach_button_rect(&ax, &ay, &aw, &ah);
  *x = ax + aw + 8;
  *y = ay;
  *w = 104;
  *h = ah;
}

static void balance_rect(int *x, int *y, int *w, int *h) {
  int ex, ey, ew, eh;
  effort_button_rect(&ex, &ey, &ew, &eh);
  *x = ex + ew + 8;
  *y = ey;
  *w = 128;
  *h = eh;
}

static void preview_button_rect(int *x, int *y, int *w, int *h) {
  int bx, by, bw, bh;
  balance_rect(&bx, &by, &bw, &bh);
  *x = bx + bw + 8;
  *y = by;
  *w = 64;
  *h = bh;
}

void ui_effort_rect(int *x, int *y, int *w, int *h) { effort_button_rect(x, y, w, h); }
void ui_balance_rect(int *x, int *y, int *w, int *h) { balance_rect(x, y, w, h); }

static void chip_rect(int i, int *x, int *y, int *w, int *h) {
  int bx, by, bw, bh, cx, cw;
  attach_button_rect(&bx, &by, &bw, &bh);
  (void)bw; (void)bh;
  cx = SIDEBAR_W + CHAT_PAD;
  {
    int k;
    for (k = 0; k < i; k++) cx += text_px_font(attach[k].name, (int)strlen(attach[k].name), FONT_UI) + 38;
  }
  cw = text_px_font(attach[i].name, (int)strlen(attach[i].name), FONT_UI) + 38;
  *x = cx; *y = chat_h() + 34; *w = cw; *h = 20;
}

static void paint_input(void) {
  int y0 = chat_h();
  int bx, by, bw, bh;
  int sx, sy, sw, sh;
  int ax, ay, aw, ah;
  const char *hint = "ctrl+enter 发送    esc 中断    ↑↓ 历史";
  int i;

  input_rect(&bx, &by, &bw, &bh);
  send_button_rect(&sx, &sy, &sw, &sh);
  attach_button_rect(&ax, &ay, &aw, &ah);

  gfx_fill(SIDEBAR_W, y0, W - SIDEBAR_W, INPUT_H, C_INPUT_BG);
  gfx_fill(SIDEBAR_W, y0, W - SIDEBAR_W, 1, RGB_(34, 42, 52));

  /* 按钮行：添加附件 | 推理强度 | 余额 */
  gfx_frame(ax, ay, aw, ah, RGB_(52, 70, 92));
  gfx_text(ax + 9, ay + 2, "+ 添加附件", (int)strlen("+ 添加附件"), RGB_(150, 176, 202), FONT_UI, ax + aw - 4);
  {
    int ex, ey, ew, eh;
    int kx, ky, kw, kh;
    char v[160];
    effort_button_rect(&ex, &ey, &ew, &eh);
    gfx_frame(ex, ey, ew, eh, RGB_(52, 70, 92));
    snprintf(v, sizeof v, "强度 %s", oc_effort_label());
    gfx_text(ex + 8, ey + 2, v, (int)strlen(v), RGB_(150, 176, 202), FONT_UI, ex + ew - 16);
    gfx_text(ex + ew - 14, ey + 2, "▼", (int)strlen("▼"), RGB_(120, 140, 160), FONT_UI, ex + ew - 4);

    balance_rect(&kx, &ky, &kw, &kh);
    gfx_frame(kx, ky, kw, kh, RGB_(46, 60, 78));
    if (g_bal.magic != BAL_MAGIC) {   /* 被写坏了，先恢复 */
      g_bal.magic = BAL_MAGIC;
      g_bal.text[0] = 0;
    }
    if (g_bal.text[0]) snprintf(v, sizeof v, "%s", g_bal.text);
    else snprintf(v, sizeof v, "余额 —");
    gfx_text(kx + 8, ky + 2, v, (int)strlen(v), RGB_(126, 200, 150), FONT_UI, kx + kw - 4);

    {
      int px, py, pw, ph;
      preview_button_rect(&px, &py, &pw, &ph);
      if (g_sw_target > 200) {
        gfx_fill(px, py, pw, ph, RGB_(32, 58, 46));
        gfx_frame(px, py, pw, ph, RGB_(63, 185, 80));
        gfx_text(px + 10, py + 2, "预览", (int)strlen("预览"), RGB_(160, 230, 180), FONT_UI, px + pw - 4);
      } else {
        gfx_frame(px, py, pw, ph, RGB_(52, 70, 92));
        gfx_text(px + 10, py + 2, "预览", (int)strlen("预览"), RGB_(150, 176, 202), FONT_UI, px + pw - 4);
      }
    }
  }

  for (i = 0; i < nattach; i++) {
    int cx, cy, cw, ch;
    chip_rect(i, &cx, &cy, &cw, &ch);
    if (cx + cw > W - 10) break;
    gfx_fill(cx, cy, cw, ch, RGB_(27, 36, 48));
    gfx_frame(cx, cy, cw, ch, RGB_(51, 64, 79));
    gfx_text(cx + 8, cy + 1, attach[i].name, (int)strlen(attach[i].name),
             RGB_(207, 216, 227), FONT_UI, cx + cw - 20);
    gfx_text(cx + cw - 17, cy + 1, "x", 1, RGB_(138, 151, 166), FONT_UI, cx + cw - 4);
  }

  /* 输入框 */
  gfx_frame(bx - 3, by - 3, bw + 6, bh + 6, RGB_(48, 58, 70));
  if (preview_caret >= 0) {
    int caret = preview_caret;
    int cx;
    if (caret > (int)strlen(preview_input)) caret = (int)strlen(preview_input);
    if (preview_input[0])
      gfx_text(bx + 2, by, preview_input, (int)strlen(preview_input), C_WHITE, FONT_MONO, bx + bw - 6);
    cx = bx + 2 + text_px_font(preview_input, caret, FONT_MONO);
    gfx_fill(cx, by + 1, 2, bh - 2, RGB_(126, 231, 135));
  }

  /* 发送按钮 */
  gfx_fill(sx, sy, sw, sh, C_BTN);
  gfx_frame(sx, sy, sw, sh, RGB_(24, 72, 128));
  {
    const char *label = busy ? "停止" : "发送";
    int tw = text_px_font(label, (int)strlen(label), FONT_UI);
    gfx_text(sx + (sw - tw) / 2, sy + 6, label, (int)strlen(label), C_WHITE, FONT_UI, sx + sw - 4);
  }

  gfx_text(SIDEBAR_W + CHAT_PAD, y0 + INPUT_H - 16, hint, (int)strlen(hint),
           RGB_(72, 82, 94), FONT_MONO, W - 20);
}

static void paint_status(void) {
  int y = H - STATUS_H;
  char left[200], right[64], tok[32];

  gfx_fill(0, y, W, STATUS_H, C_FACE);
  gfx_fill(0, y, W, 1, C_BORDER);

  if (tokens >= 1000) snprintf(tok, sizeof tok, "%.1fk tokens", tokens / 1000.0);
  else snprintf(tok, sizeof tok, "%d tokens", tokens);

  if (oc_online()) {
    char cost[64];
    if (oc_today_cost(cost, sizeof cost))
      snprintf(left, sizeof left, "  %s  ·  思考%s  ·  %s", model_label(), oc_effort_label(), cost);
    else
      snprintf(left, sizeof left, "  %s  ·  思考%s", model_label(), oc_effort_label());
  }
  else
    snprintf(left, sizeof left, "  %s   |   %s   |   $%.3f", model_label(), tok, cost);
  if (g_tool_running) {
    static const char *dots[] = { "·  ", "·· ", "···", " ··", "  ·" };
    snprintf(right, sizeof right, "执行中%s", dots[(g_anim / 3) % 5]);
  }
  else if (busy) snprintf(right, sizeof right, "生成中…  ");
  else if (oc_online()) snprintf(right, sizeof right, "在线  ");
  else if (oc_online()) snprintf(right, sizeof right, "在线  ");
  else snprintf(right, sizeof right, "离线演示  ");

  gfx_text(2, y + 4, left, (int)strlen(left), C_INK, FONT_UI, W - 100);
  gfx_text(W - text_px_font(right, (int)strlen(right), FONT_UI) - 6, y + 4,
           right, (int)strlen(right), C_INK_DIM, FONT_UI, W - 4);
}

void ui_paint(void) {
  if (vis_dirty) rebuild_vis();
  if (follow) scroll = max_scroll();
  paint_sidebar();
  paint_chat();
  paint_input();
  paint_status();
}

/* ---------------------------------------------------------------- 引擎 */

typedef struct {
  unsigned char kind;   /* 0 line, 1 type, 2 gap */
  unsigned char style;
  int wait;
  char text[Q_LEN];
} Action;

static Action queue[MAX_Q];
static int qn, qi, qwait;

static void q_push(int kind, int style, const char *text, int wait) {
  Action *a;
  if (qn >= MAX_Q) return;
  a = &queue[qn++];
  a->kind = (unsigned char)kind;
  a->style = (unsigned char)style;
  a->wait = wait;
  if (text) { strncpy(a->text, text, Q_LEN - 1); a->text[Q_LEN - 1] = 0; }
  else a->text[0] = 0;
}

static void q_line(const char *t, int st, int wait) { q_push(0, st, t, wait); }
static void q_type(const char *t, int st) {
  char b[Q_LEN];
  snprintf(b, sizeof b, "  %s", t);
  q_push(1, st, b, 0);
}
static void q_gap(int ms) { q_push(2, ST_TXT, "", ms); }

/* ---------------------------------------------------------------- 剧本 */

static const char *APP_JS[] = {
  "import { load, save, add, toggle, clearCompleted } from './store.js'",
  "",
  "let todos = load()",
  "const form = document.querySelector('#form')",
  "const input = document.querySelector('#input')",
  "const list = document.querySelector('#list')"
};

static const char *STORE_JS[] = {
  "const KEY = 'todos'",
  "",
  "export function load() {",
  "  try {",
  "    return JSON.parse(localStorage.getItem(KEY)) || []",
  "  } catch {"
};

static void scen_fix(void) {
  char b[Q_LEN];
  int i;

  q_type("先看一下列表的渲染逻辑。", ST_TXT);
  q_line("", ST_TXT, 120);
  q_line("  . 读取  app.js", ST_TOOL, 360);
  for (i = 0; i < (int)(sizeof APP_JS / sizeof APP_JS[0]); i++) {
    snprintf(b, sizeof b, "    %2d  %s", i + 1, APP_JS[i]);
    q_line(b, ST_DIM, 50);
  }
  q_gap(240);
  q_type("找到了：clearBtn.onclick 重建了数组，但没有调用 commit()，所以改动从来没写回 localStorage。", ST_TXT);
  q_gap(160);
  q_line("", ST_TXT, 60);
  q_line("  ~ 修改  app.js    +1 -0", ST_TOOL, 400);
  q_line("    43    clearBtn.onclick = () => {", ST_DIM, 40);
  q_line("    44 -    todos = clearCompleted(todos)", ST_DEL, 40);
  q_line("    44 +    todos = clearCompleted(todos)", ST_ADD, 40);
  q_line("    45 +    commit()", ST_ADD, 40);
  q_line("    46    }", ST_DIM, 60);
  q_gap(200);
  q_line("", ST_TXT, 60);
  q_line("  $ npm test", ST_WARN, 380);
  q_line("    pass  add appends a todo (1.2ms)", ST_DIM, 80);
  q_line("    pass  toggle flips the flag (0.4ms)", ST_DIM, 80);
  q_line("    pass  clearCompleted filters (0.3ms)", ST_DIM, 80);
  q_line("    3 passing (1.9ms)", ST_OK, 100);
  q_gap(160);
  q_line("  完成 · 42s · 改了 1 个文件 · 3 个测试通过", ST_OK, 0);
}

static void scen_test(void) {
  q_type("跑一下测试。", ST_TXT);
  q_line("", ST_TXT, 120);
  q_line("  $ npm test", ST_WARN, 360);
  q_line("    pass  add appends a todo (1.1ms)", ST_DIM, 80);
  q_line("    pass  toggle flips the flag (0.4ms)", ST_DIM, 80);
  q_line("    pass  clearCompleted filters (0.3ms)", ST_DIM, 80);
  q_line("    3 passing (1.8ms)", ST_OK, 100);
  q_gap(140);
  q_line("  全部通过。", ST_OK, 0);
}

static void scen_explain(void) {
  char b[Q_LEN];
  int i;

  q_type("先读一下状态层。", ST_TXT);
  q_line("", ST_TXT, 120);
  q_line("  . 读取  store.js", ST_TOOL, 360);
  for (i = 0; i < (int)(sizeof STORE_JS / sizeof STORE_JS[0]); i++) {
    snprintf(b, sizeof b, "    %2d  %s", i + 1, STORE_JS[i]);
    q_line(b, ST_DIM, 50);
  }
  q_gap(200);
  q_type("store.js 是纯函数状态层：load() 读 localStorage，add / toggle / clearCompleted 都返回新数组，只有 save() 有副作用。", ST_TXT);
  q_gap(140);
  q_line("", ST_TXT, 60);
  q_line("  提示  每条界面路径最后都要走到 save()", ST_WARN, 0);
}

static void scen_generic(const char *text) {
  char b[Q_LEN];
  snprintf(b, sizeof b, "离线演示版只认得几条指令，你说的「%s」我答不上来。", text);
  q_type(b, ST_TXT);
  q_gap(180);
  q_line("", ST_TXT, 60);
  q_line("  试试：修一下清除按钮 / 讲讲 store.js / 跑一下测试", ST_DIM, 0);
}

/* ---------------------------------------------------------------- 工具 */

static int contains_ci(const char *hay, const char *needle) {
  char a[512], b[64];
  size_t i, n = strlen(needle);
  if (n == 0 || n >= sizeof b) return 0;
  for (i = 0; i < n; i++) b[i] = (char)tolower((unsigned char)needle[i]);
  b[n] = 0;
  strncpy(a, hay, sizeof a - 1);
  a[sizeof a - 1] = 0;
  for (i = 0; a[i]; i++) a[i] = (char)tolower((unsigned char)a[i]);
  return strstr(a, b) != 0;
}

static void do_command(const char *text) {
  if (!strcmp(text, "/help")) {
    raw_add("", ST_TXT);
    raw_add("  /help    这份列表", ST_DIM);
    raw_add("  /clear   清空对话", ST_DIM);
    raw_add("  /model   切换模型", ST_DIM);
    raw_add("  /about   版本信息", ST_DIM);
    raw_add("  /exit    退出", ST_DIM);
  } else if (!strcmp(text, "/clear")) {
    nraw = 0;
    raw_add("  xp work Assistant  1.0", ST_OK);
    raw_add("  新会话。", ST_DIM);
  } else if (!strcmp(text, "/model")) {
    model_idx = (model_idx + 1) % 4;
    raw_add("", ST_TXT);
    raw_add(MODELS[model_idx], ST_DIM);
  } else if (!strcmp(text, "/about")) {
    raw_add("", ST_TXT);
    raw_add("  xp work Assistant  1.0  --  Win32 桌面版", ST_OK);
    raw_add("  32 位 GUI，单文件，无运行库，不联网。", ST_DIM);
    raw_add("  agent 是脚本化的，diff 只是文字。", ST_DIM);
  } else {
    raw_add("", ST_TXT);
    raw_add("  未知命令，输入 /help 看看。", ST_WARN);
  }
}

/* ---------------------------------------------------------------- 交互 */

static void sess_init(void) {
  if (nsess) return;
  nsess = 3;
  snprintf(sess[0].title, sizeof sess[0].title, "清除已完成");
  snprintf(sess[1].title, sizeof sess[0].title, "修待办 bug");
  snprintf(sess[2].title, sizeof sess[0].title, "初始化项目");
  sel_session = 0;
  {
    unsigned long now = oc_ticks();
    sess[0].born = now - 2UL * 60 * 1000;
    sess[1].born = now - 1UL * 24 * 60 * 60 * 1000;
    sess[2].born = now - 11UL * 24 * 60 * 60 * 1000;
  }
}

void ui_init(void) {
  sess_init();
  raw_add("  xp work Assistant  1.0", ST_OK);
  raw_add("  离线演示版：回复是写好的剧本，不联网。", ST_DIM);
  raw_add("", ST_TXT);
  raw_add("  在下面输入需求，或者输入 /help 看命令。", ST_DIM);
  raw_add("", ST_TXT);
}

void ui_resize(int w, int h) {
  if (w < 420) w = 420;
  if (h < 300) h = 300;
  W = w;
  H = h;
  vis_dirty = 1;
  if (follow) scroll = max_scroll();
}

void ui_scroll_by(int lines) {
  int ms;
  if (vis_dirty) rebuild_vis();
  ms = max_scroll();
  scroll += lines;
  if (scroll < 0) scroll = 0;
  if (scroll > ms) scroll = ms;
  follow = (scroll >= ms);
}

void ui_scroll_to_bottom(void) {
  if (vis_dirty) rebuild_vis();
  scroll = max_scroll();
  follow = 1;
}

void ui_abort(void) {
  if (!busy) return;
  busy = 0;
  typing_raw = -1;
  if (net_pending) { net_pending = 0; net_gen++; oc_agent_abort(); }
  qn = qi = 0;
  raw_add("", ST_TXT);
  raw_add("  [已中断]", ST_WARN);
}

int ui_busy(void) { return busy; }
int ui_typing(void) { return tw_active; }

void ui_send(const char *text) {
  char echo[Q_LEN];
  char line[Q_LEN];
  int i;

  if (!text) return;
  if (!*text && nattach == 0) return;
  if (busy) return;

  raw_add("", ST_TXT);
  snprintf(echo, sizeof echo, "> %s", text);
  raw_add(echo, ST_USER);

  for (i = 0; i < nattach; i++) {
    snprintf(line, sizeof line, "  + %s  %s（%.1f KB）",
             attach[i].is_image ? "图片" : "附件", attach[i].name, attach[i].size / 1024.0);
    raw_add(line, ST_DIM);
  }

  if (text[0] == '/') {
    do_command(text);
    return;
  }

  /* 组请求体：用户的话 + 附件全文 */
  {
    int n = 0;
    int room = (int)sizeof payload;
    n = snprintf(payload, (size_t)room, "%s", text);
    if (n < 0) n = 0;
    for (i = 0; i < nattach && n < room - 64; i++) {
      int w;
      if (attach[i].is_image)
        w = snprintf(payload + n, (size_t)(room - n),
                     "\n\n[%s：%s]\n%s", "图片", attach[i].name, attach[i].text);
      else
        w = snprintf(payload + n, (size_t)(room - n),
                     "\n\n[附件：%s]\n```\n%s\n```", attach[i].name, attach[i].text);
      if (w < 0) break;
      n += w;
      if (n >= room) { payload[room - 1] = 0; n = room - 1; break; }
    }
  }

  qn = qi = 0;
  qwait = 0;
  typing_raw = -1;

  tw_active = 0;

  if (oc_online() && oc_agent_start(payload)) {
    ui_attach_clear();
    busy = 1;
    net_pending = 1;
    return;
  }

  if (!oc_online() && nattach > 0)
    raw_add("  （离线演示：附件内容不会被真的读取）", ST_WARN);

  ui_attach_clear();

  busy = 1;
  qwait = 220;

  if (contains_ci(text, "test")) scen_test();
  else if (contains_ci(text, "explain") || contains_ci(text, "what") ||
           contains_ci(text, "why") || contains_ci(text, "讲") ||
           contains_ci(text, "解释")) scen_explain();
  else if (contains_ci(text, "fix") || contains_ci(text, "bug") ||
           contains_ci(text, "clear") || contains_ci(text, "修") ||
           contains_ci(text, "清除")) scen_fix();
  else scen_generic(text);
}

void ui_tick(void) {
  Action *a;

  if (g_sidebar_w != g_sw_target) {
    int d = g_sw_target - g_sidebar_w;
    int step = d / 3;
    if (step == 0) step = (d > 0) ? 1 : -1;
    g_sidebar_w += step;
    if ((d > 0 && g_sidebar_w > g_sw_target) || (d < 0 && g_sidebar_w < g_sw_target))
      g_sidebar_w = g_sw_target;
    oc_layout_changed();
    vis_dirty = 1;
  }
  if (g_tool_running) {
    g_anim++;
    vis_dirty = 1;
  }

  /* 逐字吐出最终回答 */
  if (tw_active) {
    int n = 0;
    if (tw_line < 0) {
      raw_add("", ST_TXT);
      tw_line = nraw - 1;
    }
    while (tw_pos < tw_len && n < 4) {
      char c = tw_buf[tw_pos++];
      n++;
      if (c == '\n') { tw_line = -1; break; }
      {
        int L = (int)strlen(raw[tw_line].text);
        if (L < Q_LEN - 2) {
          raw[tw_line].text[L] = c;
          raw[tw_line].text[L + 1] = 0;
        }
      }
    }
    vis_dirty = 1;
    follow = 1;
    if (tw_pos >= tw_len) { tw_active = 0; }
    return;
  }

  if (!busy) return;
  if (net_pending) return;   /* 网络请求还没回来，别动队列 */

  if (typing_raw >= 0) {
    typing_shown += 3;
    if (typing_shown >= typing_len) {
      typing_shown = typing_len;
      typing_raw = -1;
      qwait = 220;
    }
    vis_dirty = 1;
    return;
  }

  if (qwait > 0) { qwait -= 25; return; }

  if (qi >= qn) {
    busy = 0;
    tokens += 380;
    cost += 0.004;
    return;
  }

  a = &queue[qi++];
  switch (a->kind) {
    case 0:
      raw_add(a->text, a->style);
      if (a->wait) qwait = a->wait;
      break;
    case 1:
      raw_add(a->text, a->style);
      typing_raw = nraw - 1;
      typing_len = (int)strlen(a->text);
      typing_shown = 0;
      vis_dirty = 1;
      break;
    default:
      qwait = a->wait;
      break;
  }

  if (follow) scroll = max_scroll();
}

void ui_preview_input(const char *text, int caret) {
  strncpy(preview_input, text ? text : "", sizeof preview_input - 1);
  preview_input[sizeof preview_input - 1] = 0;
  preview_caret = caret;
}

void ui_reset(void) {
  oc_agent_reset();
  nraw = 0;
  nvis = 0;
  scroll = 0;
  follow = 1;
  busy = 0;
  typing_raw = -1;
  qn = qi = 0;
  vis_dirty = 1;
  ui_init();
}

void ui_delete_session(int idx) {
  int i;
  if (idx < 0 || idx >= nsess) return;
  for (i = idx; i < nsess - 1; i++) sess[i] = sess[i + 1];
  nsess--;
  if (nsess <= 0) {
    nsess = 1;
    snprintf(sess[0].title, sizeof sess[0].title, "新会话 %d", ++sess_seq);
    sess[0].born = oc_ticks();
    sel_session = 0;
  } else if (sel_session >= nsess) {
    sel_session = nsess - 1;
  }
  if (idx == sel_session || idx > sel_session) {
    /* 删的就是当前会话（或它前面的），对话内容一起清掉 */
    if (idx == sel_session) ui_reset();
  }
  vis_dirty = 1;
}

int ui_current_session(void) { return sel_session; }
int ui_menu_session(void) { return g_menu_idx; }
int ui_session_fav(int idx) { return (idx >= 0 && idx < nsess) ? sess[idx].fav : 0; }
int ui_session_archived(int idx) { return (idx >= 0 && idx < nsess) ? sess[idx].archived : 0; }
const char *ui_session_title(int idx) { return (idx >= 0 && idx < nsess) ? sess[idx].title : ""; }

void ui_rename_session(int idx, const char *title) {
  if (idx < 0 || idx >= nsess || !title || !*title) return;
  snprintf(sess[idx].title, sizeof sess[idx].title, "%s", title);
  vis_dirty = 1;
}

void ui_toggle_fav(int idx) {
  if (idx < 0 || idx >= nsess) return;
  sess[idx].fav = !sess[idx].fav;
  vis_dirty = 1;
}

void ui_toggle_archived(int idx) {
  if (idx < 0 || idx >= nsess) return;
  sess[idx].archived = !sess[idx].archived;
  vis_dirty = 1;
}

void ui_toggle_archived_view(void) {
  show_archived = !show_archived;
  vis_dirty = 1;
}

void ui_new_session(void) {
  if (nsess < 8) {
    snprintf(sess[nsess].title, sizeof sess[0].title, "新会话 %d", ++sess_seq);
    sess[nsess].born = oc_ticks();
    sel_session = nsess++;
  }
  ui_reset();
  vis_dirty = 1;
}

void ui_delete_last_exchange(void) {
  int i = nraw - 1;

  /* 往回找最后一条用户消息 */
  while (i >= 0 && raw[i].style != ST_USER) i--;
  if (i < 0) {
    raw_add("  没有可删除的对话", ST_DIM);
    return;
  }
  /* 顺带去掉紧挨着的空行 */
  while (i > 0 && raw[i - 1].text[0] == 0) i--;

  nraw = i;
  scroll = 0;
  follow = 1;
  vis_dirty = 1;
}

void ui_set_model(int idx) {
  if (idx >= 0 && idx < 4) model_idx = idx;
}

int ui_model(void) { return model_idx; }

int ui_transcript(char *buf, int cap) {
  int i, n = 0;
  buf[0] = 0;
  for (i = 0; i < nraw && n < cap - 2; i++) {
    int len = (int)strlen(raw[i].text);
    if (len > cap - n - 2) len = cap - n - 2;
    memcpy(buf + n, raw[i].text, (size_t)len);
    n += len;
    buf[n++] = '\r';
    buf[n++] = '\n';
  }
  buf[n] = 0;
  return n;
}

int ui_click(int x, int y) {
  int sx, sy, sw, sh;
  int ax, ay, aw, ah;
  int i;

  send_button_rect(&sx, &sy, &sw, &sh);
  /* 预览态：先处理预览区的点击 */
  if (g_pv_name[0] && g_sidebar_w > 200 && x < SIDEBAR_W) {
    if (y < 30 && x >= SIDEBAR_W - 26) {
      ui_preview_close();
      return UI_CLICK_NONE;
    }
    if (y >= g_pv_top) {
      ui_preview_sel_begin(y);
      g_pick_line = pv_line_at(y);
      return UI_CLICK_PREVIEW_LINE;
    }
    return UI_CLICK_NONE;
  }

  if (x >= sx && x < sx + sw && y >= sy && y < sy + sh) return UI_CLICK_SEND;

  attach_button_rect(&ax, &ay, &aw, &ah);
  if (x >= ax && x < ax + aw && y >= ay && y < ay + ah) return UI_CLICK_ATTACH;
  {
    int ex, ey, ew, eh;
    effort_button_rect(&ex, &ey, &ew, &eh);
    if (x >= ex && x < ex + ew && y >= ey && y < ey + eh) return UI_CLICK_EFFORT;
    balance_rect(&ex, &ey, &ew, &eh);
    if (x >= ex && x < ex + ew && y >= ey && y < ey + eh) return UI_CLICK_BALANCE;
    preview_button_rect(&ex, &ey, &ew, &eh);
    if (x >= ex && x < ex + ew && y >= ey && y < ey + eh) return UI_CLICK_PREVIEW_BTN;
  }

  for (i = 0; i < nattach; i++) {
    int cx, cy, cw, ch;
    chip_rect(i, &cx, &cy, &cw, &ch);
    if (x >= cx && x < cx + cw && y >= cy && y < cy + ch) {
      if (x > cx + cw - 20) { attach_remove(i); return UI_CLICK_NONE; }
      return UI_CLICK_NONE;
    }
  }

  {
    int sy = 60;
    for (i = 0; i < nsess; i++) {
      if (sess[i].archived) continue;
      if (y >= sy - 2 && y < sy + 18 && x < SIDEBAR_W) {
        if (i == sel_session && x >= SIDEBAR_W - 24) { g_menu_idx = i; return UI_CLICK_DELETE_SESSION; }
        if (i == sel_session && x >= SIDEBAR_W - 48) { g_menu_idx = i; return UI_CLICK_SESSION_MENU; }
        sel_session = i;
        return UI_CLICK_NONE;
      }
      sy += 22;
    }
    {
      int arch_y = sy + 12;
      int ay;
      if (y >= arch_y - 2 && y < arch_y + 16 && x < SIDEBAR_W)
        return UI_CLICK_ARCHIVED_TOGGLE;
      if (!show_archived) return UI_CLICK_NONE;
      ay = arch_y + 20;
      for (i = 0; i < nsess; i++) {
        if (!sess[i].archived) continue;
        if (y >= ay - 2 && y < ay + 18 && x < SIDEBAR_W) {
          if (i == sel_session && x >= SIDEBAR_W - 24) { g_menu_idx = i; return UI_CLICK_DELETE_SESSION; }
          if (i == sel_session && x >= SIDEBAR_W - 48) { g_menu_idx = i; return UI_CLICK_SESSION_MENU; }
          sel_session = i;
          return UI_CLICK_NONE;
        }
        ay += 22;
      }
    }
  }
  return UI_CLICK_NONE;
}

/* ---------------------------------------------------------------- 在线模式 */

static void queue_reply(const char *text) {
  const char *p = text;
  int first = 1;

  while (*p) {
    const char *nl = strchr(p, '\n');
    int len = nl ? (int)(nl - p) : (int)strlen(p);
    char line[Q_LEN];
    if (len > Q_LEN - 1) len = Q_LEN - 1;
    memcpy(line, p, (size_t)len);
    line[len] = 0;
    if (len > 1 && line[len - 1] == '\r') line[len - 1] = 0;

    if (first && line[0]) {
      q_push(1, ST_TXT, line, 0);   /* 第一行打字机 */
      first = 0;
    } else {
      q_push(0, ST_TXT, line, 35);
    }
    if (!nl) break;
    p = nl + 1;
  }
  if (qn == 0) busy = 0;
}

void ui_net_done(int gen) {
  char text[8192];
  char err[256];

  if (!net_pending || gen != net_gen) return;   /* 已中断或过期 */
  net_pending = 0;

  if (!oc_net_take(gen, text, sizeof text, err, sizeof err)) {
    busy = 0;
    raw_add("", ST_TXT);
    raw_add(err[0] ? err : "  请求失败", ST_WARN);
    return;
  }

  qn = qi = 0;
  qwait = 0;
  typing_raw = -1;
  queue_reply(text);
}

void ui_notice(const char *text) {
  raw_add("", ST_TXT);
  raw_add(text, ST_DIM);
}

void ui_tool_event(int kind, const char *text) {
  unsigned char st;
  const char *p;
  if (!text) return;
  st = (kind == 0) ? ST_TOOL : (kind == 1 ? ST_DIM : (kind == 3 ? ST_WARN : ST_TXT));
  p = text;
  if (kind == 5) {                            /* 图片预览：宽 高\n路径 */
    const char *nl = strchr(text, '\n');
    int iw = 0, ih = 0;
    if (nl) {
      sscanf(text, "%d %d", &iw, &ih);
      ui_preview_set(nl + 1, "", 1, iw, ih);
    }
    return;
  }
  if (kind == 4) {                            /* 文件预览：路径\n内容 */
    const char *nl = strchr(text, '\n');
    char nm[128];
    int n = nl ? (int)(nl - text) : (int)strlen(text);
    if (n > (int)sizeof nm - 1) n = (int)sizeof nm - 1;
    memcpy(nm, text, (size_t)n);
    nm[n] = 0;
    ui_preview_set(nm, nl ? nl + 1 : "", 0, 0, 0);
    return;
  }
  if (kind == 0) g_tool_running = 1;          /* 开始执行 */
  else if (kind == 1) g_tool_running = 0;     /* 有输出了 = 跑完了 */

  if (kind == 2) {                       /* 最终回答：交给逐字打字机 */
    int n = (int)strlen(text);
    if (n > (int)sizeof tw_buf - 1) n = (int)sizeof tw_buf - 1;
    memcpy(tw_buf, text, (size_t)n);
    tw_buf[n] = 0;
    tw_len = n;
    tw_pos = 0;
    tw_line = -1;
    tw_active = 1;
  } else {
    raw_add(text, st);
  }
  follow = 1;
}

void ui_preview_set(const char *name, const char *text, int is_image, int iw, int ih) {
  snprintf(g_pv_name, sizeof g_pv_name, "%s", name ? name : "");
  snprintf(g_pv_text, sizeof g_pv_text, "%s", text ? text : "");
  g_sw_target = SIDEBAR_WIDE;
  g_sel_a = g_sel_b = 0;
  g_pv_is_image = is_image;
  g_pv_w = iw;
  g_pv_h = ih;
  {
    int n = 1, i;
    for (i = 0; g_pv_text[i]; i++) if (g_pv_text[i] == '\n') n++;
    g_pv_lines = n;
  }
  vis_dirty = 1;
}

void ui_preview_close(void) {
  g_pv_name[0] = 0;
  g_pv_text[0] = 0;
  g_sw_target = SIDEBAR_NARROW;
  g_sel_a = g_sel_b = 0;
  vis_dirty = 1;
}

int ui_animating(void) { return g_sidebar_w != g_sw_target; }
int ui_preview_open(void) { return g_sw_target > 200; }

void ui_preview_toggle(void) {
  if (!g_pv_name[0]) {
    raw_add("  还没有可预览的文件——让它读一个文件，或者添加一张图片附件", ST_DIM);
    return;
  }
  g_sw_target = (g_sw_target > 200) ? SIDEBAR_NARROW : SIDEBAR_WIDE;
  vis_dirty = 1;
}

int ui_preview_hit(int x, int y) {
  return (g_pv_name[0] && g_sidebar_w > 200 && x < SIDEBAR_W && y >= g_pv_top);
}

static int pv_line_at(int y) {
  int ln = (y - g_pv_top) / LH_MONO + 1;
  if (ln < 1) ln = 1;
  if (ln > g_pv_lines) ln = g_pv_lines;
  return ln;
}

void ui_preview_sel_begin(int y) {
  g_sel_a = g_sel_b = pv_line_at(y);
  vis_dirty = 1;
}

void ui_preview_sel_update(int y) {
  int ln = pv_line_at(y);
  if (g_sel_a == 0) g_sel_a = ln;
  g_sel_b = ln;
  vis_dirty = 1;
}

int ui_preview_selected_text(char *out, int cap) {
  int a = 0, b = 0, ln = 1, used = 0;
  const char *p;
  if (!out || cap < 2) return 0;
  out[0] = 0;
  if (!ui_preview_sel(&a, &b)) return 0;
  p = g_pv_text;
  while (*p && ln <= b) {
    const char *nl = strchr(p, '\n');
    int len = nl ? (int)(nl - p) : (int)strlen(p);
    if (ln >= a) {
      if (used + len + 2 < cap) {
        memcpy(out + used, p, (size_t)len);
        used += len;
        out[used++] = '\n';
        out[used] = 0;
      } else break;
    }
    if (!nl) break;
    p = nl + 1;
    ln++;
  }
  return used;
}

int ui_preview_sel(int *a, int *b) {
  if (g_sel_a == 0) return 0;
  if (a) *a = g_sel_a < g_sel_b ? g_sel_a : g_sel_b;
  if (b) *b = g_sel_a < g_sel_b ? g_sel_b : g_sel_a;
  return 1;
}

void ui_balance_set(const char *text) {
  g_bal.magic = BAL_MAGIC;
  if (!text) { g_bal.text[0] = 0; return; }
  strncpy(g_bal.text, text, sizeof g_bal.text - 1);
  g_bal.text[sizeof g_bal.text - 1] = 0;
}

void ui_agent_done(void) {
  if (!net_pending) return;
  net_pending = 0;
  busy = 0;
}

void ui_probe_done(void) {
  char msg[512];
  int ok = oc_probe_take(msg, sizeof msg);
  raw_add("", ST_TXT);
  raw_add(msg, ok ? ST_OK : ST_WARN);
}
