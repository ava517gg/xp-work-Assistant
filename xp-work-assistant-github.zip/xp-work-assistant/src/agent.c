/* agent.c -- 让模型真的能操作这台电脑
 *
 * 流程：发请求（带 tools 定义）-> 模型返回 tool_calls -> 本地执行 -> 把结果回传 ->
 * 再发一次 -> 直到模型给出最终回答。最多 5 轮。
 *
 * XP 上没有 bash/PowerShell，所有命令都走 cmd.exe /c。
 * 打开工具时强制关闭思考模式：DeepSeek 在带 tools 的请求里要求回传
 * reasoning_content，这里简化处理。
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "agent.h"
#include "json.h"
#include "exec.h"
#include "settings.h"
#include "tls_http.h"

#define MAX_MSGS     (2048 * 1024)
#define MAX_BODY     (2048 * 1024)
#define CTX_SOFT     (MAX_MSGS * 6 / 10)      /* 到这个水位就压缩 */
#define MAX_RESP     (96 * 1024)
#define MAX_TOOL_OUT 4000

static volatile int g_abort;

/* 跨提问保留的对话：system + 历史 + 本轮。这才是“上下文” */
static char g_conv[MAX_MSGS];
static int  g_conv_len = 0;
static char g_hist[256 * 1024];
static int  g_hist_len = 0;

void agent_reset(void) {
  g_conv_len = 0;
  g_conv[0] = 0;
  g_hist_len = 0;
  g_hist[0] = 0;
}

/* 压缩请求用的缓冲（2MB，图片类附件不进这里） */
static char sbody[MAX_BODY];
static char sresp[MAX_RESP];

void agent_abort(void) { g_abort = 1; }

/* ---------------------------------------------------------------- 编码 */

static void gbk_to_utf8(const char *in, char *out, int cap) {
  int n = MultiByteToWideChar(CP_ACP, 0, in, -1, NULL, 0);
  wchar_t *w;
  if (n <= 0) { out[0] = 0; return; }
  w = (wchar_t *)malloc(sizeof(wchar_t) * (size_t)n);
  if (!w) { out[0] = 0; return; }
  MultiByteToWideChar(CP_ACP, 0, in, -1, w, n);
  WideCharToMultiByte(CP_UTF8, 0, w, -1, out, cap, NULL, NULL);
  free(w);
}

static void utf8_to_gbk(const char *in, char *out, int cap) {
  int n = MultiByteToWideChar(CP_UTF8, 0, in, -1, NULL, 0);
  wchar_t *w;
  if (n <= 0) { out[0] = 0; return; }
  w = (wchar_t *)malloc(sizeof(wchar_t) * (size_t)n);
  if (!w) { out[0] = 0; return; }
  MultiByteToWideChar(CP_UTF8, 0, in, -1, w, n);
  WideCharToMultiByte(CP_ACP, 0, w, -1, out, cap, NULL, NULL);
  free(w);
}

/* ---------------------------------------------------------------- 缓冲 */

typedef struct {
  char *p;
  int len, cap;
} Buf;

static void buf_init(Buf *b, char *mem, int cap) { b->p = mem; b->len = 0; b->cap = cap; if (cap) mem[0] = 0; }

static void buf_add(Buf *b, const char *s) {
  int n = (int)strlen(s);
  if (b->len + n >= b->cap - 1) n = b->cap - 1 - b->len;
  if (n <= 0) return;
  memcpy(b->p + b->len, s, (size_t)n);
  b->len += n;
  b->p[b->len] = 0;
}

/* 关键：先 GBK->UTF-8 再转义。
 * 反过来做会出事：GBK 里有 118 个字符的第二字节是 0x5C（反斜杠），
 * 对 GBK 字节流转义会插进去一个反斜杠，把后面的引号吃掉，JSON 直接坏掉。 */
static void push_escaped(Buf *b, const char *gbk_text) {
  int cap = (int)strlen(gbk_text) * 3 + 64;
  char *u8buf = (char *)malloc((size_t)cap);
  char *esc = (char *)malloc((size_t)cap * 2);
  if (!u8buf || !esc) { free(u8buf); free(esc); return; }
  gbk_to_utf8(gbk_text, u8buf, cap);
  json_escape(u8buf, esc, cap * 2);
  buf_add(b, esc);
  free(u8buf);
  free(esc);
}

/* ---------------------------------------------------------------- 工具定义 */

static const char *TOOLS_JSON =
  "["
  "{\"type\":\"function\",\"function\":{"
    "\"name\":\"run_cmd\","
    "\"description\":\"Run a command line on this Windows XP machine via cmd.exe /c. "
    "Use Windows commands such as dir, type, findstr.\","
    "\"parameters\":{\"type\":\"object\","
      "\"properties\":{\"command\":{\"type\":\"string\",\"description\":\"command line to run\"}},"
      "\"required\":[\"command\"]}}},"
  "{\"type\":\"function\",\"function\":{"
    "\"name\":\"run_ps\","
    "\"description\":\"Run a PowerShell command. Only works if PowerShell is installed on the machine; "
    "use run_cmd for cmd.exe instead.\","
    "\"parameters\":{\"type\":\"object\","
      "\"properties\":{\"command\":{\"type\":\"string\",\"description\":\"PowerShell command\"}},"
      "\"required\":[\"command\"]}}},"
  "{\"type\":\"function\",\"function\":{"
    "\"name\":\"read_file\","
    "\"description\":\"Read a text file and return its content.\","
    "\"parameters\":{\"type\":\"object\","
      "\"properties\":{\"path\":{\"type\":\"string\",\"description\":\"file path\"}},"
      "\"required\":[\"path\"]}}},"
  "{\"type\":\"function\",\"function\":{"
    "\"name\":\"web_search\","
    "\"description\":\"Search the web (Bing) and return titles and URLs.\","
    "\"parameters\":{\"type\":\"object\","
      "\"properties\":{\"query\":{\"type\":\"string\",\"description\":\"search keywords\"}},"
      "\"required\":[\"query\"]}}},"
  "{\"type\":\"function\",\"function\":{"
    "\"name\":\"download\","
    "\"description\":\"Download a file from an http/https URL and save it to disk.\","
    "\"parameters\":{\"type\":\"object\","
      "\"properties\":{\"url\":{\"type\":\"string\",\"description\":\"full URL\"},"
      "\"path\":{\"type\":\"string\",\"description\":\"where to save it\"}},"
      "\"required\":[\"url\",\"path\"]}}},"
  "{\"type\":\"function\",\"function\":{"
    "\"name\":\"write_file\","
    "\"description\":\"Create or overwrite a file with the given content.\","
    "\"parameters\":{\"type\":\"object\","
      "\"properties\":{\"path\":{\"type\":\"string\",\"description\":\"file path\"},"
      "\"content\":{\"type\":\"string\",\"description\":\"full file content\"}},"
      "\"required\":[\"path\",\"content\"]}}}"
  "]";

static const char *SYS_PROMPT =
  "你是运行在用户 Windows XP 电脑上的编程助手。你可以调用工具查看文件、执行命令。"
  "系统默认只有 cmd.exe（dir、type、findstr 这类命令）；"
  "如果机器上装了 PowerShell，也可以用 run_ps 工具。"
  "回答用中文，简洁。执行有风险的命令前先说明。";

static void hist_add(char *h, int *len, int cap, const char *text, int maxlen) {
  int n = (int)strlen(text);
  if (n > maxlen) n = maxlen;
  if (*len + n + 8 >= cap) return;
  if (*len > 0) { h[(*len)++] = '\n'; }
  memcpy(h + *len, text, (size_t)n);
  *len += n;
  if (n < (int)strlen(text)) { memcpy(h + *len, "...", 3); *len += 3; }
  h[*len] = 0;
}

static const char *BLOCK[] = {
  "format ", "diskpart", "bcdedit", "shutdown", "rd /s", "rmdir /s",
  "del /f /s", "del /s /q", "reg delete", "cacls", "takeown", "net user",
  "net localgroup", "vssadmin", "cipher /w", "mklink", NULL
};

static int looks_dangerous(const char *cmd) {
  char low[1024];
  int i;
  for (i = 0; i < (int)sizeof low - 1 && cmd[i]; i++) {
    char c = cmd[i];
    low[i] = (c >= 'A' && c <= 'Z') ? (char)(c - 'A' + 'a') : c;
  }
  low[i] = 0;
  for (i = 0; BLOCK[i]; i++)
    if (strstr(low, BLOCK[i])) return 1;
  return 0;
}

/* ---------------------------------------------------------------- 数组切分 */

/* 从 *p（指向数组内）取下一个顶层 {...}，写到 out，并推进 *p */
static int next_obj(const char **p, char *out, int cap) {
  const char *s = *p;
  int depth = 0, n = 0;

  while (*s && *s != '{') s++;
  if (!*s) return 0;

  while (*s && n < cap - 1) {
    char c = *s;
    out[n++] = c;
    if (c == '"') {
      s++;
      while (*s && *s != '"' && n < cap - 1) {
        if (*s == '\\' && s[1]) out[n++] = *s++;
        out[n++] = *s++;
      }
      if (*s == '"') out[n++] = *s++;
      continue;
    }
    if (c == '{') depth++;
    else if (c == '}') {
      depth--;
      if (depth == 0) { s++; break; }
    }
    s++;
  }
  out[n] = 0;
  *p = s;
  return n;
}

/* 把 JSON 字符串里的裸控制字符换成空格。
 * 有些接口自己输出 reasoning_content 时会带真实换行（它们那边解析宽松），
 * 我们原样回传就会被严格的解析器拒掉（control character 0x00-0x1F）。 */
static void sanitize_json(char *s) {
  int in_str = 0, esc = 0;
  for (; *s; s++) {
    unsigned char c = (unsigned char)*s;
    if (in_str) {
      if (esc) { esc = 0; continue; }
      if (c == '\\') { esc = 1; continue; }
      if (c == '"') { in_str = 0; continue; }
      if (c < 0x20) *s = ' ';
    } else if (c == '"') {
      in_str = 1;
    }
  }
}

/* 图片扩展名 + 尺寸（借用 exec.c 里那套头解析） */
static int is_image_path(const char *p) {
  const char *e = strrchr(p, '.');
  if (!e) return 0;
  e++;
  return !_stricmp(e, "png") || !_stricmp(e, "jpg") || !_stricmp(e, "jpeg") ||
         !_stricmp(e, "gif") || !_stricmp(e, "bmp") || !_stricmp(e, "ico");
}

static void image_size_of(const char *path, int *w, int *h) {
  FILE *f = fopen(path, "rb");
  unsigned char b[512];
  int n;
  *w = *h = 0;
  if (!f) return;
  n = (int)fread(b, 1, sizeof b, f);
  fclose(f);
  if (n > 24 && b[0] == 0x89 && b[1] == 'P') {
    *w = (b[16] << 24) | (b[17] << 16) | (b[18] << 8) | b[19];
    *h = (b[20] << 24) | (b[21] << 16) | (b[22] << 8) | b[23];
  } else if (n > 10 && b[0] == 'G' && b[1] == 'I' && b[2] == 'F') {
    *w = b[6] | (b[7] << 8);
    *h = b[8] | (b[9] << 8);
  } else if (n > 26 && b[0] == 'B' && b[1] == 'M') {
    *w = b[18] | (b[19] << 8) | (b[20] << 16) | (b[21] << 24);
    *h = b[22] | (b[23] << 8) | (b[24] << 16) | (b[25] << 24);
  } else if (n > 4 && b[0] == 0xFF && b[1] == 0xD8) {
    int i = 2;
    while (i + 9 < n) {
      if (b[i] != 0xFF) { i++; continue; }
      if (b[i+1] >= 0xC0 && b[i+1] <= 0xCF &&
          b[i+1] != 0xC4 && b[i+1] != 0xC8 && b[i+1] != 0xCC) {
        *h = (b[i+5] << 8) | b[i+6];
        *w = (b[i+7] << 8) | b[i+8];
        break;
      }
      i += 2 + ((b[i+2] << 8) | b[i+3]);
    }
  }
}

/* ---------------------------------------------------------------- 搜索 */

static void url_encode(const char *in, char *out, int cap) {
  int n = 0;
  for (; *in && n < cap - 4; in++) {
    unsigned char c = (unsigned char)*in;
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
      out[n++] = (char)c;
    } else if (c == ' ') {
      out[n++] = '+';
    } else {
      snprintf(out + n, 4, "%%%02X", c);
      n += 3;
    }
  }
  out[n] = 0;
}

/* 从 Bing 的搜索结果页里抠标题和链接 */
static int parse_search(const char *html, char *out, int cap) {
  const char *p = html;
  int n = 0, used = 0;
  if (cap > 0) out[0] = 0;

  while ((p = strstr(p, "class=\"b_algo\"")) != NULL) {
    const char *h2 = strstr(p, "<h2");
    const char *hk, *ue, *t, *te;
    if (!h2) break;
    hk = strstr(h2, "href=\"");
    if (!hk) { p += 14; continue; }
    ue = strchr(hk + 6, '"');
    t = ue ? strchr(ue, '>') : NULL;
    te = t ? strstr(t, "</a>") : NULL;
    if (ue && t && te) {
      char title[300];
      int ti = 0, ul = (int)(ue - (hk + 6));
      const char *sp = t + 1;
      while (sp < te && ti < (int)sizeof title - 1) {
        if (*sp == '<') { while (sp < te && *sp != '>') sp++; if (sp < te) sp++; continue; }
        if (*sp == '&') { while (sp < te && *sp != ';') sp++; if (sp < te) sp++; if (ti < 298) title[ti++] = ' '; continue; }
        title[ti++] = *sp++;
      }
      while (ti > 0 && title[ti - 1] == ' ') ti--;
      title[ti] = 0;
      if (ul > 5 && ul < 900 && ti > 0) {
        char line[1300];
        int w = snprintf(line, sizeof line, "%d. %s\n   %.*s\n", ++n, title, ul, hk + 6);
        if (used + w < cap - 1) {
          memcpy(out + used, line, (size_t)w);
          used += w;
          out[used] = 0;
        }
      }
    }
    p = (h2 > p) ? h2 : p + 14;
    if (n >= 8) break;
  }
  return n;
}

/* ---------------------------------------------------------------- 执行 */

static void run_tool(const char *name, const char *args, char *out, int cap, EmitFn emit) {
  char path[512], cmd[1024], content[8192];
  char header[600];

  out[0] = 0;

  if (!strcmp(name, "run_cmd")) {
    if (!json_get_str(args, "command", cmd, sizeof cmd)) {
      snprintf(out, cap, "error: 缺少 command 参数");
      return;
    }
    snprintf(header, sizeof header, "  $ %s", cmd);
    emit(EV_TOOL, header);

    if (looks_dangerous(cmd)) {
      snprintf(out, cap, "refused: 命令包含危险操作，已拒绝执行");
      emit(EV_OUT, "  ! 该命令被本地安全规则拒绝");
      return;
    }
    {
      int code = -1;
      static char buf[MAX_TOOL_OUT + 1];
      exec_cmd(cmd, buf, sizeof buf, &code, 30000);
      if (!buf[0]) snprintf(buf, sizeof buf, "(无输出)");
      snprintf(out, cap, "%s\n[exit %d]", buf, code);

      {
        char line[300];
        const char *p = buf;
        int shown = 0;
        while (*p && shown < 12) {
          const char *nl = strchr(p, '\n');
          int n = nl ? (int)(nl - p) : (int)strlen(p);
          if (n > (int)sizeof line - 4) n = (int)sizeof line - 4;
          memcpy(line, p, (size_t)n);
          line[n] = 0;
          if (line[n - 1] == '\r') line[n - 1] = 0;
          emit(EV_OUT, line);
          shown++;
          if (!nl) break;
          p = nl + 1;
        }
        if (*p) emit(EV_OUT, "  ...");
      }
    }
    return;
  }

  if (!strcmp(name, "read_file")) {
    if (!json_get_str(args, "path", path, sizeof path)) {
      snprintf(out, cap, "error: 缺少 path 参数");
      return;
    }
    snprintf(header, sizeof header, "  . read  %s", path);
    emit(EV_TOOL, header);
    {
      static char buf[16384];
      int size = 0;
      if (is_image_path(path)) {
        int iw = 0, ih = 0;
        char *pv;
        image_size_of(path, &iw, &ih);
        snprintf(out, cap, "ok: 这是图片 %s（%d×%d）。它已显示在侧边栏预览里，你看不到像素内容，"
                           "需要处理可以用 run_cmd 调用系统工具。", path, iw, ih);
        snprintf(header, sizeof header, "  . 预览图片  %d×%d", iw, ih);
        emit(EV_OUT, header);
        pv = (char *)malloc(strlen(path) + 64);
        if (pv) { sprintf(pv, "%d %d\n%s", iw, ih, path); emit(EV_IMG, pv); free(pv); }
        return;
      }
      if (!exec_read_file(path, buf, sizeof buf, &size)) {
        snprintf(out, cap, "error: 读不到 %s（不存在或是二进制文件）", path);
        emit(EV_OUT, "  ! 读取失败");
      } else {
        char *pv = (char *)malloc(strlen(path) + strlen(buf) + 4);
        snprintf(out, cap, "%s", buf);
        emit(EV_OUT, "  ...(内容已发给模型)");
        if (pv) {
          sprintf(pv, "%s\n%s", path, buf);
          emit(EV_FILE, pv);
          free(pv);
        }
      }
    }
    return;
  }

  if (!strcmp(name, "run_ps")) {
    if (!json_get_str(args, "command", cmd, sizeof cmd)) {
      snprintf(out, cap, "error: 缺少 command 参数");
      return;
    }
    snprintf(header, sizeof header, "  PS> %s", cmd);
    emit(EV_TOOL, header);
    if (looks_dangerous(cmd)) {
      snprintf(out, cap, "refused: 命令包含危险操作，已拒绝执行");
      emit(EV_OUT, "  ! 该命令被本地安全规则拒绝");
      return;
    }
    {
      int code = -1;
      static char buf[MAX_TOOL_OUT + 1];
      if (!exec_ps(cmd, buf, sizeof buf, &code, 40000)) {
        snprintf(out, cap, "%s", buf[0] ? buf : "powershell 不可用");
        emit(EV_OUT, "  ! 执行失败");
        return;
      }
      if (!buf[0]) snprintf(buf, sizeof buf, "(无输出)");
      snprintf(out, cap, "%s\n[exit %d]", buf, code);
      {
        char line2[300];
        const char *p2 = buf;
        int shown = 0;
        while (*p2 && shown < 12) {
          const char *nl = strchr(p2, '\n');
          int n = nl ? (int)(nl - p2) : (int)strlen(p2);
          if (n > (int)sizeof line2 - 4) n = (int)sizeof line2 - 4;
          memcpy(line2, p2, (size_t)n);
          line2[n] = 0;
          if (n > 0 && line2[n - 1] == '\r') line2[n - 1] = 0;
          emit(EV_OUT, line2);
          shown++;
          if (!nl) break;
          p2 = nl + 1;
        }
        if (*p2) emit(EV_OUT, "  ...");
      }
    }
    return;
  }

  if (!strcmp(name, "web_search")) {
    char q[512], enc[1600], url[2048], body[16384], err[256];
    snprintf(header, sizeof header, "  . search  %s", q);
    if (!json_get_str(args, "query", q, sizeof q)) {
      snprintf(out, cap, "error: 缺少 query");
      return;
    }
    snprintf(header, sizeof header, "  . search  %s", q);
    emit(EV_TOOL, header);
    url_encode(q, enc, sizeof enc);
    snprintf(url, sizeof url, "https://cn.bing.com/search?q=%s&count=10", enc);
    if (tls_http_get_h(url,
                       "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)\r\n",
                       body, sizeof body, err, sizeof err) != 200) {
      snprintf(out, cap, "error: 搜索失败 %s", err);
      emit(EV_OUT, "  ! 搜索请求失败");
      return;
    }
    {
      int n = parse_search(body, out, cap);
      char line[160];
      if (n <= 0) {
        snprintf(out, cap, "没有搜到结果（可能被挡了）");
        emit(EV_OUT, "  ! 没有结果");
      } else {
        snprintf(line, sizeof line, "  找到 %d 条结果", n);
        emit(EV_OUT, line);
      }
    }
    return;
  }

  if (!strcmp(name, "download")) {
    char u[1024], path2[512], err[256];
    int saved = 0;
    if (!json_get_str(args, "url", u, sizeof u) || !json_get_str(args, "path", path2, sizeof path2)) {
      snprintf(out, cap, "error: 缺少 url 或 path");
      return;
    }
    snprintf(header, sizeof header, "  ↓ 下载  %.90s", u);
    emit(EV_TOOL, header);
    {
      int st = tls_download(u,
                            "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)\r\n",
                            path2, &saved, err, sizeof err);
      if (st == 200) {
        snprintf(out, cap, "ok: 已保存 %s（%d 字节）", path2, saved);
        snprintf(header, sizeof header, "  已保存 %d 字节", saved);
        emit(EV_OUT, header);
      } else {
        snprintf(out, cap, "error: 下载失败（%s）", err[0] ? err : "非 200");
        emit(EV_OUT, "  ! 下载失败");
      }
    }
    return;
  }

  if (!strcmp(name, "write_file")) {
    if (!json_get_str(args, "path", path, sizeof path) ||
        !json_get_str(args, "content", content, sizeof content)) {
      snprintf(out, cap, "error: 缺少 path 或 content");
      return;
    }
    snprintf(header, sizeof header, "  ~ write %s  (%d 字节)", path, (int)strlen(content));
    emit(EV_TOOL, header);
    if (exec_write_file(path, content, (int)strlen(content))) {
      char *pv = (char *)malloc(strlen(path) + strlen(content) + 4);
      if (pv) {
        sprintf(pv, "%s\n%s", path, content);
        emit(EV_FILE, pv);
        free(pv);
      }
      snprintf(out, cap, "ok: 已写入 %s", path);
    }
    else
      snprintf(out, cap, "error: 写不进 %s", path);
    emit(EV_OUT, strstr(out, "error") ? "  ! 写入失败" : "  已保存");
    return;
  }

  snprintf(out, cap, "error: 未知工具 %s", name);
}

/* 从头构建：system +（可选摘要）+ 本轮问题。返回用到的长度 */
static int build_turn(Buf *m, char *mem, int cap, const char *user_gbk, const char *summary) {
  buf_init(m, mem, cap);
  buf_add(m, "{\"role\":\"system\",\"content\":\"");
  push_escaped(m, SYS_PROMPT);
  buf_add(m, "\"}");
  if (summary && summary[0]) {
    buf_add(m, ",{\"role\":\"user\",\"content\":\"【之前的进展摘要】\\n");
    push_escaped(m, summary);
    buf_add(m, "\"}");
  }
  buf_add(m, ",{\"role\":\"user\",\"content\":\"");
  push_escaped(m, user_gbk);
  buf_add(m, "\"}");
  return m->len;
}

/* ---------------------------------------------------------------- 压缩 */

/* 让模型把之前的过程压成要点，成功后用要点替换历史，继续干活 */
static int compress_history(const char *url, const char *hdr,
                            const char *text, int tlen,
                            char *out, int cap, char *err, int ecap) {
  static char esc[512 * 1024];
  int st, n;

  if (tlen > (int)sizeof esc / 2) tlen = (int)sizeof esc / 2;
  json_escape(text, esc, sizeof esc);

  n = snprintf(sbody, sizeof sbody,
               "{\"model\":\"%s\",\"stream\":false,"
               "\"thinking\":{\"type\":\"disabled\"},"
               "\"messages\":[{\"role\":\"system\",\"content\":\""
               "把下面这段操作记录压缩成简洁的要点，保留：用户的目标、已经改过或创建的文件、"
               "关键结论、还没做完的事。不要复述命令输出细节，控制在 800 字以内。\"},"
               "{\"role\":\"user\",\"content\":\"%s\"}]}",
               settings_model(), esc);

  if (n >= (int)sizeof sbody - 1) {
    snprintf(err, ecap, "历史太长，压缩请求本身就放不下");
    return 0;
  }

  st = tls_http_post(url, hdr, sbody, sresp, sizeof sresp, err, ecap);
  if (st != 200) {
    if (!err[0]) snprintf(err, ecap, "HTTP %d", st);
    return 0;
  }
  {
    static char g[MAX_RESP];
    utf8_to_gbk(sresp, g, sizeof g);
    if (!json_get_raw(g, "message", g, sizeof g)) return 0;   /* 原地解析 */
    if (!json_get_str(g, "content", out, cap)) return 0;
  }
  return out[0] ? 1 : 0;
}

/* ---------------------------------------------------------------- 自检 */

/* 粗略检查：引号成对、括号配平。返回 1 表示看起来正常 */
static int json_balanced(const char *s) {
  int depth = 0, in_str = 0, esc = 0;
  for (; *s; s++) {
    char c = *s;
    if (in_str) {
      if (esc) { esc = 0; continue; }
      if (c == '\\') { esc = 1; continue; }
      if (c == '"') in_str = 0;
      continue;
    }
    if (c == '"') in_str = 1;
    else if (c == '{' || c == '[') depth++;
    else if (c == '}' || c == ']') { depth--; if (depth < 0) return 0; }
  }
  return depth == 0 && !in_str && !esc;
}

/* ---------------------------------------------------------------- 主循环 */

int agent_run(const char *user_gbk, EmitFn emit) {
  static char body[MAX_BODY];
  static char resp[MAX_RESP];
  static char u8[MAX_RESP];
  static char msgobj[131072];   /* 思维链可能很长，小了会截断出坏 JSON */
  static char msg_u8[131072];
  static char calls[131072];
  static char toolout[8192];
  Buf m;

  char url[512], hdr[700];
  int variant = 0;
  int prefix_len = 0;
  int cleared = 0;
  static char tools_u8[8192];
  const char *base = settings_base();
  int round, use_tools;

  if (!settings_ready()) return 0;

  g_abort = 0;
  use_tools = settings_tools_enabled();

  snprintf(url, sizeof url, "%s/chat/completions", base);
  gbk_to_utf8(TOOLS_JSON, tools_u8, sizeof tools_u8);
  snprintf(hdr, sizeof hdr,
           "Content-Type: application/json\r\nAuthorization: Bearer %s\r\n",
           settings_key());

  /* 接着上一轮继续；第一次提问才建 system */
  if (g_conv_len == 0) {
    prefix_len = build_turn(&m, g_conv, sizeof g_conv, user_gbk, NULL);
    g_conv_len = prefix_len;
  } else {
    /* 注意：这里不能用 buf_init——它会把 mem[0] 置 0，
       整段历史就被截成空字符串，请求体变成 messages:[]，
       服务端报 Empty input messages */
    m.p = g_conv;
    m.cap = (int)sizeof g_conv;
    m.len = g_conv_len;
    g_conv[g_conv_len] = 0;
    prefix_len = m.len;
    buf_add(&m, ",{\"role\":\"user\",\"content\":\"");
    push_escaped(&m, user_gbk);
    buf_add(&m, "\"}");
    g_conv_len = m.len;
  }
  hist_add(g_hist, &g_hist_len, sizeof g_hist, user_gbk, 4000);

  for (round = 0; ; round++) {
    char err[256] = "";
    int status;

    if (g_abort) return 1;

    if (m.len > CTX_SOFT && g_hist_len > 300) {
      char sum[4096], cerr[256];
      if (compress_history(url, hdr, g_hist, g_hist_len, sum, sizeof sum, cerr, sizeof cerr)) {
        prefix_len = build_turn(&m, g_conv, sizeof g_conv, user_gbk, sum);
        g_conv_len = prefix_len;
        g_hist_len = 0;
        hist_add(g_hist, &g_hist_len, sizeof g_hist, "【摘要】", 8);
        hist_add(g_hist, &g_hist_len, sizeof g_hist, sum, 4000);
        emit(EV_OUT, "  [上下文已压缩：保留了目标、改动和待办]");
      } else {
        m.len = prefix_len;
        g_conv[prefix_len] = 0;
        g_conv_len = prefix_len;
        emit(EV_OUT, "  [压缩失败，已丢弃中间记录继续]");
      }
    }

    if (variant == 0 && use_tools)
      snprintf(body, sizeof body,
               "{\"model\":\"%s\",\"stream\":false,"
               "\"messages\":[%s],\"tools\":%s,\"tool_choice\":\"auto\"}",
               settings_model(), g_conv, tools_u8);
    else {
      const char *eff = settings_effort();
      if (!strcmp(eff, "off"))
        snprintf(body, sizeof body,
                 "{\"model\":\"%s\",\"stream\":false,\"messages\":[%s]}",
                 settings_model(), g_conv);
      else
        snprintf(body, sizeof body,
                 "{\"model\":\"%s\",\"stream\":false,"
                 "\"thinking\":{\"type\":\"enabled\"},"
                 "\"reasoning_effort\":\"%s\",\"messages\":[%s]}",
                 settings_model(), eff, g_conv);
    }

    if (m.len >= m.cap - 1) {
      /* 装满了就丢掉中间的工具记录，保留开场的人设和问题，接着做 */
      m.len = prefix_len;
      g_conv[prefix_len] = 0;
      g_conv_len = prefix_len;
      emit(EV_OUT, "  [上下文满了，已丢弃前面的工具记录继续]");
    }
    if ((int)strlen(body) >= (int)sizeof body - 1) {
      emit(EV_ERR, "请求太长（附件或历史太多），请减少附件后重试");
      return 1;
    }
    /* body 里各段内容在 push_escaped 里已经转成 UTF-8，这里直接用，
       再转一次会变成双重编码（乱码），服务端必然解析失败 */
    status = tls_http_post(url, hdr, body, resp, sizeof resp, err, sizeof err);

    if (status < 0) {
      emit(EV_ERR, err);
      return 1;
    }

    if (status != 200) {
      char msg[512];
      char g[1024];
      FILE *lf;

      utf8_to_gbk(resp, g, sizeof g);
      if (json_get_str(g, "message", msg, sizeof msg) && msg[0])
        snprintf(err, sizeof err, "HTTP %d: %s", status, msg);
      else
        snprintf(err, sizeof err, "HTTP %d: %.200s", status, g);

      /* 上下文超限：丢掉中间的工具记录，回卷重试 */
      if ((status == 400 || status == 413) && round > 0 &&
          (strstr(err, "context") || strstr(err, "maximum") || strstr(err, "tokens"))) {
        char sum[4096], cerr[256];
        if (g_hist_len > 300 &&
            compress_history(url, hdr, g_hist, g_hist_len, sum, sizeof sum, cerr, sizeof cerr)) {
          prefix_len = build_turn(&m, g_conv, sizeof g_conv, user_gbk, sum);
          g_conv_len = prefix_len;
          g_hist_len = 0;
          hist_add(g_hist, &g_hist_len, sizeof g_hist, "【摘要】", 8);
          hist_add(g_hist, &g_hist_len, sizeof g_hist, sum, 4000);
          emit(EV_OUT, "  [上下文超限，已压缩历史后重试]");
        } else {
          m.len = prefix_len;
          g_conv[prefix_len] = 0;
          g_conv_len = prefix_len;
          emit(EV_OUT, "  [服务端提示上下文超限，已丢弃前面的工具记录重试]");
        }
        round--;
        continue;
      }

      /* 历史被污染（缺思维链 / tool_call_id 对不上）：清空历史、同样请求再来一次 */
      if (status == 400 && round == 0 && !cleared &&
          (strstr(err, "reasoning") || strstr(err, "tool_call") ||
           strstr(err, "messages[") || strstr(err, "tool_calls"))) {
        cleared = 1;
        prefix_len = build_turn(&m, g_conv, sizeof g_conv, user_gbk, NULL);
        g_conv_len = prefix_len;
        emit(EV_OUT, "  历史消息有问题（缺思维链或工具结果对不上），已清空历史重试 ...");
        continue;
      }

      /* 400 时逐级降级：带工具 -> 普通 -> 最简 */
      if (status == 400 && round == 0 && variant < 1) {
        char why[600];
        snprintf(why, sizeof why, "  被拒原因：%.180s", err);
        emit(EV_OUT, why);
        if (variant == 0) emit(EV_OUT, "  工具请求被拒，改用普通对话重试 ...");
        else emit(EV_OUT, "  普通请求也被拒，改发最简请求试一次 ...");
        variant = 2;              /* 只降一级，不再发伪造的 hi */
        use_tools = 0;
        round--;
        continue;
      }

      emit(EV_ERR, err);
      if (variant == 2)
        emit(EV_OUT, "  连最简请求都失败，先检查：模型名是否有效、Key 是否欠费、接口地址是否正确");
      {
        char b2[700];
        char head[220];
        utf8_to_gbk(body, b2, sizeof b2);
        snprintf(head, sizeof head, "  请求体 %d 字节，开头：%.80s", (int)strlen(body), b2);
        emit(EV_OUT, head);
      }
      lf = fopen("xpwork.log", "a");
      if (lf) {
        fprintf(lf, "== HTTP %d\n--- 请求头 ---\n%s--- 请求体 (%d 字节) ---\n%s\n"
                    "--- 响应 ---\n%s\n\n",
                status, hdr, (int)strlen(body), body, g);
        fclose(lf);
      }
      return 1;
    }

    /* 响应转成 GBK 再解析 */
    utf8_to_gbk(resp, u8, sizeof u8);

    /* 记今日消耗 */
    {
      char usage[512];
      long it = 0, ot = 0;
      if (json_get_raw(u8, "usage", usage, sizeof usage)) {
        json_get_int(usage, "prompt_tokens", &it);
        json_get_int(usage, "completion_tokens", &ot);
        if (it || ot) cost_add(it, ot);
      }
    }
    g_conv[sizeof g_conv - 1] = 0;

    if (!json_get_raw(u8, "message", msgobj, sizeof msgobj)) {
      emit(EV_ERR, "响应里找不到 message");
      return 1;
    }

    if (use_tools && json_get_raw(msgobj, "tool_calls", calls, sizeof calls) && calls[0] == '[') {
      const char *p = calls;
      char obj[8192];
      int got = 0;

      /* 回声 assistant 消息：用响应里的 UTF-8 原文，别用 GBK 副本 */
      buf_add(&m, ",");
      {
        int mlen = json_get_raw(resp, "message", msg_u8, sizeof msg_u8);
        if (mlen >= (int)sizeof msg_u8 - 1) {
          emit(EV_ERR, "助手消息太长（思维链超过 128 KB），无法安全回传，已停止本轮");
          return 1;
        }
        if (mlen > 0) {
          sanitize_json(msg_u8);
          buf_add(&m, msg_u8);
        }
        else
          buf_add(&m, msgobj);
      }

      while (next_obj(&p, obj, sizeof obj)) {
        char id[128], name[64], args[8192];
        if (!json_get_str(obj, "id", id, sizeof id)) break;
        if (!json_get_str(obj, "name", name, sizeof name)) break;
        if (!json_get_str(obj, "arguments", args, sizeof args)) strcpy(args, "{}");

        run_tool(name, args, toolout, sizeof toolout, emit);
        got++;
        {
          char rec[512];
          snprintf(rec, sizeof rec, "工具 %s -> %.360s", name, toolout);
          hist_add(g_hist, &g_hist_len, sizeof g_hist, rec, 500);
        }

        buf_add(&m, ",{\"role\":\"tool\",\"tool_call_id\":\"");
        buf_add(&m, id);
        buf_add(&m, "\",\"content\":\"");
        push_escaped(&m, toolout);
        buf_add(&m, "\"}");

        if (g_abort) return 1;

    if (m.len > CTX_SOFT && g_hist_len > 300) {
      char sum[4096], cerr[256];
      if (compress_history(url, hdr, g_hist, g_hist_len, sum, sizeof sum, cerr, sizeof cerr)) {
        prefix_len = build_turn(&m, g_conv, sizeof g_conv, user_gbk, sum);
        g_conv_len = prefix_len;
        g_hist_len = 0;
        hist_add(g_hist, &g_hist_len, sizeof g_hist, "【摘要】", 8);
        hist_add(g_hist, &g_hist_len, sizeof g_hist, sum, 4000);
        emit(EV_OUT, "  [上下文已压缩：保留了目标、改动和待办]");
      } else {
        m.len = prefix_len;
        g_conv[prefix_len] = 0;
        g_conv_len = prefix_len;
        emit(EV_OUT, "  [压缩失败，已丢弃中间记录继续]");
      }
    }
      }

      if (!got) {
        emit(EV_ERR, "解析 tool_calls 失败");
        return 1;
      }
      continue;
    }

    {
      char content[16384];
      if (json_get_str(msgobj, "content", content, sizeof content) && content[0]) {
        /* 存原始 message（带 reasoning_content）：开了思考的对话，
           历史里的 assistant 消息必须带思维链，否则下一次请求会被 400 */
        {
          int mlen = json_get_raw(resp, "message", msg_u8, sizeof msg_u8);
          if (mlen > 0 && mlen < (int)sizeof msg_u8 - 1) {
            sanitize_json(msg_u8);
            buf_add(&m, ",");
            buf_add(&m, msg_u8);
          } else {
            buf_add(&m, ",{\"role\":\"assistant\",\"content\":\"");
            push_escaped(&m, content);
            buf_add(&m, "\"}");
          }
        }
        g_conv_len = m.len;
        hist_add(g_hist, &g_hist_len, sizeof g_hist, content, 2000);
        emit(EV_SAY, content);
      } else {
        emit(EV_SAY, "(模型没有返回内容)");
      }
    }
    return 1;
  }

  return 1;
}
